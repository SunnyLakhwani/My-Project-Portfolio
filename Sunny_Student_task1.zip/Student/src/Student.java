package gradtracker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Represents a student with a name and a list of subject grades.
 */
public class Student {

    private final String name;
    private final String studentId;
    private final List<SubjectGrade> grades;

    public Student(String name, String studentId) {
        this.name = name;
        this.studentId = studentId;
        this.grades = new ArrayList<>();
    }

    public void addGrade(SubjectGrade sg) {
        grades.add(sg);
    }

    public String getName()      { return name; }
    public String getStudentId() { return studentId; }
    public List<SubjectGrade> getGrades() { return Collections.unmodifiableList(grades); }

    /** Returns average across all recorded subjects, or 0 if none. */
    public double getAverage() {
        if (grades.isEmpty()) return 0.0;
        double sum = 0;
        for (SubjectGrade sg : grades) sum += sg.getScore();
        return sum / grades.size();
    }

    public double getHighest() {
        return grades.stream().mapToDouble(SubjectGrade::getScore).max().orElse(0);
    }

    public double getLowest() {
        return grades.stream().mapToDouble(SubjectGrade::getScore).min().orElse(0);
    }

    /** Converts numeric average to a letter grade. */
    public String getLetterGrade() {
        double avg = getAverage();
        if (avg >= 90) return "A+";
        if (avg >= 80) return "A";
        if (avg >= 70) return "B";
        if (avg >= 60) return "C";
        if (avg >= 50) return "D";
        return "F";
    }

    /** Returns GPA on a 4.0 scale. */
    public double getGPA() {
        double avg = getAverage();
        if (avg >= 90) return 4.0;
        if (avg >= 80) return 3.5;
        if (avg >= 70) return 3.0;
        if (avg >= 60) return 2.0;
        if (avg >= 50) return 1.0;
        return 0.0;
    }

    @Override
    public String toString() {
        return String.format("Student[%s | %s | Avg: %.2f | Grade: %s]",
                studentId, name, getAverage(), getLetterGrade());
    }
}