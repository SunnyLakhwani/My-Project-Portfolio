package gradtracker;

/**
 * Stores a single subject name and its numeric score (0–100).
 */
public class SubjectGrade {

    private final String subject;
    private double score;

    public SubjectGrade(String subject, double score) {
        if (score < 0 || score > 100)
            throw new IllegalArgumentException("Score must be between 0 and 100.");
        this.subject = subject;
        this.score   = score;
    }

    public String getSubject() { return subject; }
    public double getScore()   { return score;   }

    public void setScore(double score) {
        if (score < 0 || score > 100)
            throw new IllegalArgumentException("Score must be between 0 and 100.");
        this.score = score;
    }

    @Override
    public String toString() {
        return String.format("%-20s : %6.2f", subject, score);
    }
}