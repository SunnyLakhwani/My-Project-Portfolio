package gradtracker;

import java.io.*;
import java.util.*;

/**
 * Manages the in-memory roster of students and handles CSV persistence.
 * File format (one line per subject grade):
 *   studentId,name,subject,score
 */
public class GradeManager {

    private final Map<String, Student> roster = new LinkedHashMap<>();
    private final String dataFile;

    public GradeManager(String dataFile) {
        this.dataFile = dataFile;
        loadFromFile();
    }

    // ──────────────────────────────────────────
    //  CRUD helpers
    // ──────────────────────────────────────────

    public boolean addStudent(String id, String name) {
        if (roster.containsKey(id)) return false;
        roster.put(id, new Student(name, id));
        return true;
    }

    public boolean removeStudent(String id) {
        return roster.remove(id) != null;
    }

    public Optional<Student> findStudent(String id) {
        return Optional.ofNullable(roster.get(id));
    }

    public Collection<Student> getAllStudents() {
        return Collections.unmodifiableCollection(roster.values());
    }

    /**
     * Adds or updates a grade for the given student.
     * If the subject already exists the score is overwritten.
     */
    public boolean addOrUpdateGrade(String studentId, String subject, double score) {
        Student s = roster.get(studentId);
        if (s == null) return false;

        for (SubjectGrade sg : s.getGrades()) {
            if (sg.getSubject().equalsIgnoreCase(subject)) {
                sg.setScore(score);
                saveToFile();
                return true;
            }
        }
        s.addGrade(new SubjectGrade(subject, score));
        saveToFile();
        return true;
    }

    // ──────────────────────────────────────────
    //  Statistics across all students
    // ──────────────────────────────────────────

    public OptionalDouble classAverage() {
        return roster.values().stream()
                .filter(s -> !s.getGrades().isEmpty())
                .mapToDouble(Student::getAverage)
                .average();
    }

    /** Student with the highest average. */
    public Optional<Student> topStudent() {
        return roster.values().stream()
                .filter(s -> !s.getGrades().isEmpty())
                .max(Comparator.comparingDouble(Student::getAverage));
    }

    /** Student with the lowest average. */
    public Optional<Student> bottomStudent() {
        return roster.values().stream()
                .filter(s -> !s.getGrades().isEmpty())
                .min(Comparator.comparingDouble(Student::getAverage));
    }

    /** Pass rate: % of students with average >= 50. */
    public double passRate() {
        long total = roster.values().stream().filter(s -> !s.getGrades().isEmpty()).count();
        if (total == 0) return 0;
        long passed = roster.values().stream()
                .filter(s -> !s.getGrades().isEmpty() && s.getAverage() >= 50)
                .count();
        return (passed * 100.0) / total;
    }

    // ──────────────────────────────────────────
    //  Persistence
    // ──────────────────────────────────────────

    public void saveToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(dataFile))) {
            for (Student s : roster.values()) {
                for (SubjectGrade sg : s.getGrades()) {
                    pw.printf("%s,%s,%s,%.2f%n",
                            s.getStudentId(), s.getName(),
                            sg.getSubject(), sg.getScore());
                }
                // Save student even if no grades yet
                if (s.getGrades().isEmpty()) {
                    pw.printf("%s,%s,,%n", s.getStudentId(), s.getName());
                }
            }
        } catch (IOException e) {
            System.err.println("[WARN] Could not save data: " + e.getMessage());
        }
    }

    private void loadFromFile() {
        File f = new File(dataFile);
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",", -1);
                if (parts.length < 2) continue;
                String id   = parts[0].trim();
                String name = parts[1].trim();
                roster.putIfAbsent(id, new Student(name, id));
                if (parts.length == 4 && !parts[2].trim().isEmpty()) {
                    try {
                        double score = Double.parseDouble(parts[3].trim());
                        Student s = roster.get(id);
                        // Avoid duplicate subjects
                        boolean found = s.getGrades().stream()
                                .anyMatch(sg -> sg.getSubject().equalsIgnoreCase(parts[2].trim()));
                        if (!found)
                            s.addGrade(new SubjectGrade(parts[2].trim(), score));
                    } catch (NumberFormatException ignored) { }
                }
            }
        } catch (IOException e) {
            System.err.println("[WARN] Could not load data: " + e.getMessage());
        }
    }
}