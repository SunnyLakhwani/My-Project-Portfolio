package gradtracker;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Responsible for all formatted console output — keeps UI concerns
 * cleanly separated from data logic.
 */
public class ReportPrinter {

    // ANSI colour codes (disabled on Windows cmd without ANSI support)
    private static final String RESET  = "\u001B[0m";
    private static final String BOLD   = "\u001B[1m";
    private static final String CYAN   = "\u001B[36m";
    private static final String GREEN  = "\u001B[32m";
    private static final String YELLOW = "\u001B[33m";
    private static final String RED    = "\u001B[31m";
    private static final String BLUE   = "\u001B[34m";
    private static final String DIM    = "\u001B[2m";

    private static final int LINE_WIDTH = 60;

    // ──────────────────────────────────────────
    //  Decorative helpers
    // ──────────────────────────────────────────

    public static void divider() {
        System.out.println(DIM + "─".repeat(LINE_WIDTH) + RESET);
    }

    public static void header(String title) {
        System.out.println();
        divider();
        System.out.printf(BOLD + CYAN + "  %s%n" + RESET, title.toUpperCase());
        divider();
    }

    public static void success(String msg) {
        System.out.println(GREEN + "  ✔  " + msg + RESET);
    }

    public static void warn(String msg) {
        System.out.println(YELLOW + "  ⚠  " + msg + RESET);
    }

    public static void error(String msg) {
        System.out.println(RED + "  ✘  " + msg + RESET);
    }

    public static void info(String msg) {
        System.out.println(BLUE + "  ℹ  " + msg + RESET);
    }

    // ──────────────────────────────────────────
    //  Student detail card
    // ──────────────────────────────────────────

    public static void printStudentCard(Student s) {
        header("Student Report — " + s.getName());
        System.out.printf("  ID       : %s%n", s.getStudentId());
        System.out.printf("  Name     : %s%n", s.getName());
        divider();
        if (s.getGrades().isEmpty()) {
            warn("No grades recorded yet.");
        } else {
            System.out.println(BOLD + "  Subject              Score" + RESET);
            for (SubjectGrade sg : s.getGrades()) {
                String bar = gradeBar(sg.getScore());
                System.out.printf("  %-22s %6.2f  %s%n",
                        sg.getSubject(), sg.getScore(), bar);
            }
            divider();
            System.out.printf("  Average  : " + BOLD + "%.2f%s  (%s)%n" + RESET,
                    s.getAverage(), RESET, s.getLetterGrade());
            System.out.printf("  Highest  : %.2f%n", s.getHighest());
            System.out.printf("  Lowest   : %.2f%n", s.getLowest());
            System.out.printf("  GPA      : %.1f / 4.0%n", s.getGPA());
        }
        divider();
    }

    // ──────────────────────────────────────────
    //  Full class summary report
    // ──────────────────────────────────────────

    public static void printClassSummary(GradeManager mgr) {
        Collection<Student> students = mgr.getAllStudents();
        header("Full Class Summary Report");

        if (students.isEmpty()) {
            warn("No students enrolled.");
            return;
        }

        // Table header
        System.out.printf(BOLD + "  %-10s %-20s %7s %7s %7s  %-5s  %s%n" + RESET,
                "ID", "Name", "Avg", "High", "Low", "Grade", "GPA");
        divider();

        // Sort by average descending for readability
        List<Student> sorted = students.stream()
                .sorted(Comparator.comparingDouble(Student::getAverage).reversed())
                .collect(Collectors.toList());

        for (Student s : sorted) {
            if (s.getGrades().isEmpty()) {
                System.out.printf("  %-10s %-20s %7s %7s %7s  %-5s  %s%n",
                        s.getStudentId(), truncate(s.getName(), 20),
                        "—", "—", "—", "—", "—");
            } else {
                String color = s.getAverage() >= 70 ? GREEN
                        : s.getAverage() >= 50 ? YELLOW : RED;
                System.out.printf("  %-10s %-20s " + color + "%7.2f %7.2f %7.2f  %-5s  %.1f" + RESET + "%n",
                        s.getStudentId(), truncate(s.getName(), 20),
                        s.getAverage(), s.getHighest(), s.getLowest(),
                        s.getLetterGrade(), s.getGPA());
            }
        }

        divider();

        // Class-wide stats
        mgr.classAverage().ifPresent(avg ->
                System.out.printf("  Class Average : " + BOLD + "%.2f%n" + RESET, avg));
        mgr.topStudent().ifPresent(t ->
                System.out.printf("  Top Student   : %s (%s)  —  %.2f avg%n",
                        t.getName(), t.getStudentId(), t.getAverage()));
        mgr.bottomStudent().ifPresent(b ->
                System.out.printf("  Needs Support : %s (%s)  —  %.2f avg%n",
                        b.getName(), b.getStudentId(), b.getAverage()));
        System.out.printf("  Pass Rate     : %.1f%%%n", mgr.passRate());
        System.out.printf("  Total Enrolled: %d student(s)%n", students.size());
        divider();
    }

    // ──────────────────────────────────────────
    //  Private helpers
    // ──────────────────────────────────────────

    /** Simple ASCII bar representing a score out of 100. */
    private static String gradeBar(double score) {
        int filled = (int) (score / 10);
        String color = score >= 70 ? GREEN : score >= 50 ? YELLOW : RED;
        StringBuilder sb = new StringBuilder(color + "[");
        for (int i = 0; i < 10; i++) sb.append(i < filled ? "█" : "░");
        sb.append("]" + RESET);
        return sb.toString();
    }

    private static String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }
}