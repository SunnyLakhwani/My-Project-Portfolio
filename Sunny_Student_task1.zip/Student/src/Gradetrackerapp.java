package gradtracker;

import java.util.Optional;
import java.util.Scanner;

/**
 * ╔══════════════════════════════════════════╗
 * ║      STUDENT GRADE TRACKER v1.0          ║
 * ║      CodeAlpha Internship — Task 1       ║
 * ╚══════════════════════════════════════════╝
 *
 * Console-based grade management tool. Grades are
 * automatically persisted to grades_data.csv on every change.
 *
 * Usage: compile all .java files in this package and run
 *        gradtracker.GradeTrackerApp
 */
class GradeTrackerApp {

    private static final String DATA_FILE = "grades_data.csv";

    private final GradeManager manager;
    private final Scanner       scanner;

    public GradeTrackerApp() {
        manager = new GradeManager(DATA_FILE);
        scanner = new Scanner(System.in);
    }

    // ──────────────────────────────────────────
    //  Main loop
    // ──────────────────────────────────────────

    public void run() {
        printWelcome();
        boolean running = true;
        while (running) {
            printMenu();
            String choice = prompt("Enter choice").trim();
            switch (choice) {
                case "1" -> addStudent();
                case "2" -> addOrUpdateGrade();
                case "3" -> viewStudent();
                case "4" -> ReportPrinter.printClassSummary(manager);
                case "5" -> removeStudent();
                case "6" -> searchStudent();
                case "0" -> running = false;
                default  -> ReportPrinter.warn("Unknown option. Please try again.");
            }
        }
        System.out.println("\n  Goodbye! Data saved to " + DATA_FILE + ".\n");
    }

    // ──────────────────────────────────────────
    //  Menu actions
    // ──────────────────────────────────────────

    private void addStudent() {
        ReportPrinter.header("Add New Student");
        String id   = prompt("  Student ID  ").trim().toUpperCase();
        String name = prompt("  Full Name   ").trim();
        if (id.isEmpty() || name.isEmpty()) {
            ReportPrinter.error("ID and name cannot be empty.");
            return;
        }
        if (manager.addStudent(id, name)) {
            manager.saveToFile();
            ReportPrinter.success("Student " + name + " (" + id + ") enrolled.");
        } else {
            ReportPrinter.warn("A student with ID " + id + " already exists.");
        }
    }

    private void addOrUpdateGrade() {
        ReportPrinter.header("Add / Update Grade");
        String id = prompt("  Student ID  ").trim().toUpperCase();
        Optional<Student> opt = manager.findStudent(id);
        if (opt.isEmpty()) {
            ReportPrinter.error("No student found with ID: " + id);
            return;
        }
        String subject = prompt("  Subject     ").trim();
        if (subject.isEmpty()) { ReportPrinter.error("Subject cannot be empty."); return; }

        double score = readDouble("  Score (0-100) ", 0, 100);
        if (manager.addOrUpdateGrade(id, subject, score)) {
            ReportPrinter.success("Grade recorded: " + subject + " = " + score
                    + " for " + opt.get().getName());
        }
    }

    private void viewStudent() {
        String id = prompt("  Student ID  ").trim().toUpperCase();
        Optional<Student> opt = manager.findStudent(id);
        if (opt.isPresent()) {
            ReportPrinter.printStudentCard(opt.get());
        } else {
            ReportPrinter.error("No student found with ID: " + id);
        }
    }

    private void removeStudent() {
        ReportPrinter.header("Remove Student");
        String id = prompt("  Student ID to remove ").trim().toUpperCase();
        Optional<Student> opt = manager.findStudent(id);
        if (opt.isEmpty()) { ReportPrinter.error("Student not found."); return; }
        String confirm = prompt("  Remove " + opt.get().getName() + "? (yes/no) ").trim();
        if (confirm.equalsIgnoreCase("yes")) {
            manager.removeStudent(id);
            manager.saveToFile();
            ReportPrinter.success("Student removed.");
        } else {
            ReportPrinter.info("Cancelled.");
        }
    }

    private void searchStudent() {
        ReportPrinter.header("Search Students");
        String query = prompt("  Search by name or ID ").trim().toLowerCase();
        long found = manager.getAllStudents().stream()
                .filter(s -> s.getName().toLowerCase().contains(query)
                        || s.getStudentId().toLowerCase().contains(query))
                .peek(ReportPrinter::printStudentCard)
                .count();
        if (found == 0) ReportPrinter.warn("No students matched \"" + query + "\".");
    }

    // ──────────────────────────────────────────
    //  UI helpers
    // ──────────────────────────────────────────

    private void printWelcome() {
        System.out.println("\u001B[36m");
        System.out.println("  ╔══════════════════════════════════════════╗");
        System.out.println("  ║        STUDENT GRADE TRACKER v1.0        ║");
        System.out.println("  ║        CodeAlpha Java Internship          ║");
        System.out.println("  ╚══════════════════════════════════════════╝");
        System.out.println("\u001B[0m");
        ReportPrinter.info("Data file: " + DATA_FILE);
        long count = manager.getAllStudents().size();
        if (count > 0) ReportPrinter.info(count + " student(s) loaded from saved data.");
    }

    private void printMenu() {
        System.out.println();
        System.out.println("\u001B[1m  ──────── MAIN MENU ────────\u001B[0m");
        System.out.println("  1  Add new student");
        System.out.println("  2  Add / update grade");
        System.out.println("  3  View student report card");
        System.out.println("  4  Full class summary");
        System.out.println("  5  Remove student");
        System.out.println("  6  Search students");
        System.out.println("  0  Exit");
    }

    private String prompt(String label) {
        System.out.print("\u001B[33m" + label + " › \u001B[0m");
        return scanner.nextLine();
    }

    /**
     * Reads a double from the user, re-prompting on invalid input or out-of-range values.
     */
    private double readDouble(String label, double min, double max) {
        while (true) {
            String raw = prompt(label).trim();
            try {
                double val = Double.parseDouble(raw);
                if (val >= min && val <= max) return val;
                ReportPrinter.warn("Please enter a value between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                ReportPrinter.error("Invalid number. Try again.");
            }
        }
    }

    // ──────────────────────────────────────────
    //  Entry point
    // ──────────────────────────────────────────

    public static void main(String[] args) {
        new GradeTrackerApp().run();
    }
}