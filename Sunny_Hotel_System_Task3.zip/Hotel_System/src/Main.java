package hotel;

import hotel.ui.MainUI;

public class Main {
    public static void main(String[] args) {
        new MainUI().run();
    }
}