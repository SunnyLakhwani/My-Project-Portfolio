package hotel.ui;

import hotel.model.*;
import hotel.model.Booking.*;
import hotel.model.Room.*;
import hotel.service.HotelService;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import static hotel.util.ConsoleUtils.*;

public class MainUI {

    private final HotelService service;
    private final Scanner      sc;
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public MainUI() {
        this.service = new HotelService();
        this.sc      = new Scanner(System.in);
    }

    // ====================================================================
    //  ENTRY POINT
    // ====================================================================

    public void run() {
        printBanner();
        boolean running = true;
        while (running) {
            printMainMenu();
            String choice = prompt(sc, "Select option").toLowerCase();
            switch (choice) {
                case "1" -> searchAndBook();
                case "2" -> manageReservation();
                case "3" -> guestManagement();
                case "4" -> viewRooms();
                case "5" -> reportsMenu();
                case "6" -> adminMenu();
                case "0", "q", "quit", "exit" -> running = false;
                default  -> printError("Invalid option. Please try again.");
            }
        }
        printHeader("  Thank you for using Grandview HMS. Goodbye!  ");
    }

    // ====================================================================
    //  MAIN MENU
    // ====================================================================

    private void printBanner() {
        System.out.println(BOLD + CYAN);
        System.out.println("  ╔══════════════════════════════════════════════════════════════════╗");
        System.out.println("  ║                                                                  ║");
        System.out.println("  ║          ★  G R A N D V I E W   H O T E L  ★                  ║");
        System.out.println("  ║              Hotel Reservation Management System                 ║");
        System.out.println("  ║                                                                  ║");
        System.out.println("  ╚══════════════════════════════════════════════════════════════════╝");
        System.out.println(RESET);
        printDashboard();
    }

    private void printDashboard() {
        System.out.printf(DIM + "  Today: %-20s  Occupancy: %5.1f%%   Revenue: $%,.2f   Check-ins Today: %d%n" + RESET,
                LocalDate.now(),
                service.getOccupancyRate(),
                service.getTotalRevenue(),
                service.getTodayCheckIns());
    }

    private void printMainMenu() {
        System.out.println();
        printDoubleLine();
        System.out.println(BOLD + CYAN + "  MAIN MENU" + RESET);
        printLine();
        System.out.println("  " + BOLD + "1." + RESET + "  🔍  Search Rooms & Book");
        System.out.println("  " + BOLD + "2." + RESET + "  📋  Manage Reservation  (check-in / check-out / cancel / pay)");
        System.out.println("  " + BOLD + "3." + RESET + "  👤  Guest Management    (register / view / search)");
        System.out.println("  " + BOLD + "4." + RESET + "  🏨  View All Rooms");
        System.out.println("  " + BOLD + "5." + RESET + "  📊  Reports & Analytics");
        System.out.println("  " + BOLD + "6." + RESET + "  🔧  Admin Tools");
        System.out.println("  " + BOLD + "0." + RESET + "  ❌  Exit");
        printLine();
    }

    // ====================================================================
    //  1. SEARCH & BOOK
    // ====================================================================

    private void searchAndBook() {
        printHeader("SEARCH & BOOK A ROOM");

        printSectionTitle("Room Type");
        System.out.println("  0. Any type");
        RoomType[] types = RoomType.values();
        for (int i = 0; i < types.length; i++) {
            System.out.printf("  %d. %-14s  $%.2f/night  —  %s%n",
                    i + 1, types[i].getLabel(), types[i].getBasePrice(), types[i].getAmenities());
        }
        int typeChoice = promptInt(sc, "Enter type number (0 for any)");
        RoomType selectedType = (typeChoice > 0 && typeChoice <= types.length)
                ? types[typeChoice - 1] : null;

        printSectionTitle("Stay Dates");
        LocalDate checkIn  = promptDate("Check-in date  (yyyy-MM-dd)");
        LocalDate checkOut = promptDate("Check-out date (yyyy-MM-dd)");
        if (!checkOut.isAfter(checkIn)) {
            printError("Check-out must be after check-in.");
            return;
        }

        List<Room> available = service.getAvailableRooms(selectedType, checkIn, checkOut);
        if (available.isEmpty()) {
            printWarning("No rooms available for your criteria. Please try different dates or type.");
            pause(sc);
            return;
        }

        printSectionTitle("Available Rooms");
        for (int i = 0; i < available.size(); i++) {
            System.out.printf("  %2d.  %s%n", i + 1, available.get(i));
        }

        int roomChoice = promptInt(sc, "Select room number (0 to cancel)");
        if (roomChoice < 1 || roomChoice > available.size()) return;
        Room chosen = available.get(roomChoice - 1);

        printSectionTitle("Guest Details");
        System.out.println("  1. Existing guest (enter ID or email)");
        System.out.println("  2. New guest");
        String gChoice = prompt(sc, "Choice");
        Guest guest;
        if ("1".equals(gChoice)) {
            String query = prompt(sc, "Guest ID or Email");
            guest = service.findGuestById(query)
                    .or(() -> service.findGuestByEmail(query))
                    .orElse(null);
            if (guest == null) { printError("Guest not found."); return; }
        } else {
            guest = registerNewGuest();
            if (guest == null) return;
        }
        printInfo("Guest: " + guest.getName() + " | Loyalty Points: " + String.format("%.1f", guest.getLoyaltyPoints()));

        int guestsCount = promptInt(sc, "Number of guests staying");
        String special  = prompt(sc, "Special requests (or press Enter to skip)");

        double redeemPoints = 0;
        if (guest.getLoyaltyPoints() >= 100) {
            printInfo(String.format("You have %.1f loyalty points. Every 100 pts = $10 discount.", guest.getLoyaltyPoints()));
            String redeem = prompt(sc, "Points to redeem (0 to skip)");
            try { redeemPoints = Double.parseDouble(redeem); } catch (NumberFormatException e) { redeemPoints = 0; }
        }

        long nights     = checkIn.until(checkOut).getDays();
        double subtotal = chosen.getPricePerNight() * nights;
        double discount = guest.getLoyaltyDiscount(redeemPoints);
        double tax      = (subtotal - discount) * 0.12;
        double total    = subtotal - discount + tax;

        printSectionTitle("Booking Summary");
        printReceiptRow("Room:              ", String.format("Room %03d — %s", chosen.getRoomNumber(), chosen.getType().getLabel()));
        printReceiptRow("Check-in:          ", checkIn.toString());
        printReceiptRow("Check-out:         ", checkOut.toString());
        printReceiptRow("Nights:            ", String.valueOf(nights));
        printReceiptRow("Price/night:       ", String.format("$%.2f", chosen.getPricePerNight()));
        printReceiptRow("Subtotal:          ", String.format("$%.2f", subtotal));
        if (discount > 0)
            printReceiptRow("Loyalty Discount:  ", String.format("-$%.2f", discount));
        printReceiptRow("Tax (12%):         ", String.format("$%.2f", tax));
        printLine();
        printReceiptRowColored("TOTAL AMOUNT:      ", String.format("$%.2f", total), GREEN);

        String confirm = prompt(sc, "Confirm booking? (yes/no)");
        if (!"yes".equalsIgnoreCase(confirm) && !"y".equalsIgnoreCase(confirm)) {
            printInfo("Booking cancelled."); return;
        }

        Booking booking = service.makeReservation(
                guest.getGuestId(), chosen.getRoomNumber(),
                checkIn, checkOut, guestsCount, special, redeemPoints);

        if (booking == null) {
            printError("Failed to create booking. Room may have been taken."); return;
        }

        printSuccess("Booking confirmed! ID: " + BOLD + booking.getBookingId());
        printInfo("Please proceed to payment to secure your reservation.");

        String payNow = prompt(sc, "Pay now? (yes/no)");
        if ("yes".equalsIgnoreCase(payNow) || "y".equalsIgnoreCase(payNow)) {
            processPaymentFlow(booking.getBookingId());
        }

        pause(sc);
    }

    // ====================================================================
    //  2. MANAGE RESERVATION
    // ====================================================================

    private void manageReservation() {
        printHeader("MANAGE RESERVATION");
        String bid = prompt(sc, "Enter Booking ID");
        Optional<Booking> opt = service.getBooking(bid.toUpperCase());
        if (opt.isEmpty()) { printError("Booking not found."); pause(sc); return; }
        Booking b = opt.get();

        printBookingDetails(b);
        printSectionTitle("Actions");
        System.out.println("  1. Pay for booking");
        System.out.println("  2. Check In");
        System.out.println("  3. Check Out");
        System.out.println("  4. Cancel Reservation");
        System.out.println("  0. Back");

        String choice = prompt(sc, "Select action");
        switch (choice) {
            case "1" -> processPaymentFlow(b.getBookingId());
            case "2" -> {
                if (service.checkIn(b.getBookingId())) printSuccess("Checked in successfully.");
                else printError("Check-in failed. Ensure booking is CONFIRMED and PAID.");
            }
            case "3" -> {
                if (service.checkOut(b.getBookingId())) printSuccess("Checked out. Thank you for staying with us!");
                else printError("Check-out failed. Ensure booking is in CHECKED_IN status.");
            }
            case "4" -> {
                String confirm = prompt(sc, "Are you sure you want to cancel? (yes/no)");
                if ("yes".equalsIgnoreCase(confirm) || "y".equalsIgnoreCase(confirm)) {
                    if (service.cancelReservation(b.getBookingId())) {
                        printSuccess("Reservation cancelled." + (b.getPaymentStatus() == Booking.PaymentStatus.PAID
                                ? " Refund will be processed." : ""));
                    } else printError("Could not cancel reservation.");
                }
            }
        }
        pause(sc);
    }

    private void processPaymentFlow(String bookingId) {
        printSectionTitle("Payment");
        PaymentMethod[] methods = PaymentMethod.values();
        for (int i = 0; i < methods.length; i++) {
            System.out.printf("  %d. %s%n", i + 1, methods[i].getLabel());
        }
        int m = promptInt(sc, "Select payment method");
        if (m < 1 || m > methods.length) { printError("Invalid selection."); return; }
        PaymentMethod method = methods[m - 1];

        if (method == PaymentMethod.CREDIT_CARD || method == PaymentMethod.DEBIT_CARD) {
            String cardNum = prompt(sc, "Card number (16 digits)");
            if (cardNum.replaceAll("\\s", "").length() != 16) {
                printError("Invalid card number."); return;
            }
            prompt(sc, "Expiry (MM/YY)");
            prompt(sc, "CVV");
            printInfo("Processing payment...");
            simulateDelay(1200);
        }

        if (service.processPayment(bookingId, method)) {
            printSuccess("Payment successful via " + method.getLabel() + "!");
            service.getBooking(bookingId).ifPresent(this::printInvoice);
        } else {
            printError("Payment failed or booking already paid.");
        }
    }

    // ====================================================================
    //  3. GUEST MANAGEMENT
    // ====================================================================

    private void guestManagement() {
        printHeader("GUEST MANAGEMENT");
        System.out.println("  1. Register New Guest");
        System.out.println("  2. View Guest Profile");
        System.out.println("  3. List All Guests");
        System.out.println("  0. Back");

        String choice = prompt(sc, "Select option");
        switch (choice) {
            case "1" -> {
                Guest g = registerNewGuest();
                if (g != null) printSuccess("Guest registered! ID: " + g.getGuestId());
            }
            case "2" -> {
                String query = prompt(sc, "Guest ID or Email");
                Optional<Guest> g = service.findGuestById(query)
                        .or(() -> service.findGuestByEmail(query));
                g.ifPresentOrElse(this::printGuestProfile,
                        () -> printError("Guest not found."));
            }
            case "3" -> {
                printSectionTitle("All Registered Guests");
                service.getAllGuests().forEach(g -> System.out.println("  " + g));
            }
        }
        pause(sc);
    }

    private Guest registerNewGuest() {
        printSectionTitle("New Guest Registration");
        String name    = prompt(sc, "Full name");
        String email   = prompt(sc, "Email address");
        String phone   = prompt(sc, "Phone number");
        String idProof = prompt(sc, "Passport / National ID number");
        if (name.isEmpty() || email.isEmpty()) {
            printError("Name and email are required."); return null;
        }
        if (service.findGuestByEmail(email).isPresent()) {
            printWarning("A guest with this email already exists.");
            return service.findGuestByEmail(email).get();
        }
        return service.registerGuest(name, email, phone, idProof);
    }

    private void printGuestProfile(Guest g) {
        printSectionTitle("Guest Profile");
        printReceiptRow("ID:             ", g.getGuestId());
        printReceiptRow("Name:           ", g.getName());
        printReceiptRow("Email:          ", g.getEmail());
        printReceiptRow("Phone:          ", g.getPhone());
        printReceiptRow("ID Proof:       ", g.getIdProof());
        printReceiptRowColored("Loyalty Points: ", String.format("%.1f pts", g.getLoyaltyPoints()), YELLOW);

        List<Booking> history = service.getBookingsByGuest(g.getGuestId());
        if (!history.isEmpty()) {
            printSectionTitle("Booking History");
            history.forEach(b -> System.out.println("  " + b));
        }
    }

    // ====================================================================
    //  4. VIEW ROOMS
    // ====================================================================

    private void viewRooms() {
        printHeader("ALL ROOMS");
        System.out.println("  Filter: 1=Standard  2=Deluxe  3=Suite  4=Presidential  0=All");
        int f = promptInt(sc, "Filter");
        RoomType filter = (f >= 1 && f <= 4) ? RoomType.values()[f - 1] : null;

        service.getAllRooms().stream()
                .filter(r -> filter == null || r.getType() == filter)
                .sorted(Comparator.comparingInt(Room::getRoomNumber))
                .forEach(r -> {
                    String line = "  " + r;
                    if (r.isUnderMaintenance())  System.out.println(YELLOW + line + RESET);
                    else if (!r.isAvailable())   System.out.println(DIM    + line + RESET);
                    else                         System.out.println(GREEN  + line + RESET);
                });
        pause(sc);
    }

    // ====================================================================
    //  5. REPORTS
    // ====================================================================

    private void reportsMenu() {
        printHeader("REPORTS & ANALYTICS");
        System.out.println("  1. Revenue Summary");
        System.out.println("  2. Occupancy Report");
        System.out.println("  3. All Bookings");
        System.out.println("  4. Active Bookings (Confirmed / Checked-in)");
        System.out.println("  0. Back");

        String choice = prompt(sc, "Select report");
        switch (choice) {
            case "1" -> revenueReport();
            case "2" -> occupancyReport();
            case "3" -> {
                printSectionTitle("All Bookings");
                service.getAllBookings().stream()
                        .sorted(Comparator.comparing(Booking::getBookedAt).reversed())
                        .forEach(b -> System.out.println("  " + b));
            }
            case "4" -> {
                printSectionTitle("Active Bookings");
                service.getAllBookings().stream()
                        .filter(b -> b.getStatus() == BookingStatus.CONFIRMED
                                || b.getStatus() == BookingStatus.CHECKED_IN)
                        .forEach(b -> System.out.println("  " + b));
            }
        }
        pause(sc);
    }

    private void revenueReport() {
        printSectionTitle("Revenue Summary");
        double total = service.getTotalRevenue();
        Map<String, Double> byType = new LinkedHashMap<>();
        for (RoomType t : RoomType.values()) byType.put(t.getLabel(), 0.0);

        service.getAllBookings().stream()
                .filter(b -> b.getPaymentStatus() == PaymentStatus.PAID
                        || b.getPaymentStatus() == PaymentStatus.REFUNDED)
                .forEach(b -> service.getRoom(b.getRoomNumber()).ifPresent(r ->
                        byType.merge(r.getType().getLabel(), b.getTotalAmount(), Double::sum)));

        byType.forEach((type, rev) ->
                printReceiptRow("  " + type + ":", String.format("$%,.2f", rev)));
        printLine();
        printReceiptRowColored("  TOTAL REVENUE:", String.format("$%,.2f", total), GREEN);
    }

    private void occupancyReport() {
        printSectionTitle("Occupancy Report");
        long total      = service.getAllRooms().size();
        long checkedIn  = service.getAllBookings().stream()
                .filter(b -> b.getStatus() == BookingStatus.CHECKED_IN).count();
        long maintenance = service.getAllRooms().stream()
                .filter(Room::isUnderMaintenance).count();
        long available  = total - checkedIn - maintenance;

        printReceiptRow("  Total Rooms:   ", String.valueOf(total));
        printReceiptRowColored("  Occupied:      ", String.valueOf(checkedIn), RED);
        printReceiptRowColored("  Available:     ", String.valueOf(available), GREEN);
        printReceiptRowColored("  Maintenance:   ", String.valueOf(maintenance), YELLOW);
        printLine();
        printReceiptRowColored("  Occupancy Rate:", String.format("%.1f%%", service.getOccupancyRate()), CYAN);
    }

    // ====================================================================
    //  6. ADMIN
    // ====================================================================

    private void adminMenu() {
        printHeader("ADMIN TOOLS");
        System.out.println("  1. Set Room Maintenance Status");
        System.out.println("  2. View Bookings by Guest");
        System.out.println("  0. Back");

        String choice = prompt(sc, "Select option");
        switch (choice) {
            case "1" -> {
                int roomNum = promptInt(sc, "Room number");
                String s = prompt(sc, "Set maintenance? (yes/no)");
                boolean maint = "yes".equalsIgnoreCase(s) || "y".equalsIgnoreCase(s);
                service.setRoomMaintenance(roomNum, maint);
                printSuccess("Room " + roomNum + " maintenance status updated.");
            }
            case "2" -> {
                String gid = prompt(sc, "Guest ID");
                List<Booking> list = service.getBookingsByGuest(gid);
                if (list.isEmpty()) printWarning("No bookings found.");
                else list.forEach(b -> System.out.println("  " + b));
            }
        }
        pause(sc);
    }

    // ====================================================================
    //  HELPERS
    // ====================================================================

    private void printBookingDetails(Booking b) {
        printSectionTitle("Booking Details");
        printReceiptRow("Booking ID:      ", b.getBookingId());
        printReceiptRow("Guest ID:        ", b.getGuestId());
        printReceiptRow("Room:            ", String.format("%03d", b.getRoomNumber()));
        printReceiptRow("Check-in:        ", b.getCheckIn().toString());
        printReceiptRow("Check-out:       ", b.getCheckOut().toString());
        printReceiptRow("Nights:          ", String.valueOf(b.getNights()));
        printReceiptRow("Guests:          ", String.valueOf(b.getGuestsCount()));
        printReceiptRow("Total Amount:    ", String.format("$%.2f", b.getTotalAmount()));
        printReceiptRow("Status:          ", colorStatus(b.getStatus().name()));
        printReceiptRow("Payment:         ", colorStatus(b.getPaymentStatus().name()));
        if (b.getPaymentMethod() != null)
            printReceiptRow("Pay Method:      ", b.getPaymentMethod().getLabel());
        if (b.getSpecialRequests() != null && !b.getSpecialRequests().isBlank())
            printReceiptRow("Special Req:     ", b.getSpecialRequests());
    }

    private void printInvoice(Booking b) {
        printDoubleLine();
        System.out.println(BOLD + CYAN + "              GRANDVIEW HOTEL — INVOICE" + RESET);
        printDoubleLine();
        printReceiptRow("Booking ID:", b.getBookingId());
        printReceiptRow("Date Issued:", LocalDate.now().toString());
        printLine();
        printReceiptRow("Room:", String.format("Room %03d", b.getRoomNumber()));
        printReceiptRow("Check-in:", b.getCheckIn().toString());
        printReceiptRow("Check-out:", b.getCheckOut().toString());
        printReceiptRow("Nights:", String.valueOf(b.getNights()));
        printReceiptRow("Rate/night:", String.format("$%.2f", b.getPricePerNight()));
        printLine();
        printReceiptRow("Subtotal:", String.format("$%.2f", b.getSubtotal()));
        if (b.getDiscountAmount() > 0)
            printReceiptRow("Discount:", String.format("-$%.2f", b.getDiscountAmount()));
        printReceiptRow("Tax (12%):", String.format("$%.2f", b.getTax()));
        printLine();
        printReceiptRowColored("TOTAL PAID:", String.format("$%.2f", b.getTotalAmount()), GREEN);
        printReceiptRow("Payment Method:", b.getPaymentMethod() != null ? b.getPaymentMethod().getLabel() : "N/A");
        printDoubleLine();
    }

    private LocalDate promptDate(String label) {
        while (true) {
            String raw = prompt(sc, label);
            try {
                return LocalDate.parse(raw, DATE_FMT);
            } catch (DateTimeParseException e) {
                printError("Invalid date format. Use yyyy-MM-dd (e.g. 2025-12-25)");
            }
        }
    }

    private void simulateDelay(int ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}