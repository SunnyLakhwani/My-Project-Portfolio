package hotel.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Guest implements Serializable {

    private static final long serialVersionUID = 1L;

    private final String guestId;
    private String name;
    private String email;
    private String phone;
    private String idProof;
    private final List<String> bookingIds;
    private double loyaltyPoints;

    public Guest(String guestId, String name, String email, String phone, String idProof) {
        this.guestId       = guestId;
        this.name          = name;
        this.email         = email;
        this.phone         = phone;
        this.idProof       = idProof;
        this.bookingIds    = new ArrayList<>();
        this.loyaltyPoints = 0.0;
    }

    public void addLoyaltyPoints(double amount) {
        this.loyaltyPoints += amount / 10.0;
    }

    public boolean redeemLoyaltyPoints(double points) {
        if (loyaltyPoints >= points) {
            loyaltyPoints -= points;
            return true;
        }
        return false;
    }

    public double getLoyaltyDiscount(double pointsToRedeem) {
        double redeemable = Math.min(pointsToRedeem, loyaltyPoints);
        return (redeemable / 100.0) * 10.0;
    }

    public void addBookingId(String id)    { bookingIds.add(id); }
    public void removeBookingId(String id) { bookingIds.remove(id); }

    public String       getGuestId()       { return guestId; }
    public String       getName()          { return name; }
    public String       getEmail()         { return email; }
    public String       getPhone()         { return phone; }
    public String       getIdProof()       { return idProof; }
    public List<String> getBookingIds()    { return bookingIds; }
    public double       getLoyaltyPoints() { return loyaltyPoints; }

    public void setName(String name)         { this.name = name; }
    public void setEmail(String email)       { this.email = email; }
    public void setPhone(String phone)       { this.phone = phone; }
    public void setIdProof(String id)        { this.idProof = id; }
    public void setLoyaltyPoints(double p)   { this.loyaltyPoints = p; }

    @Override
    public String toString() {
        return String.format("Guest [%s] %s | Email: %s | Phone: %s | Points: %.1f",
                guestId, name, email, phone, loyaltyPoints);
    }
}