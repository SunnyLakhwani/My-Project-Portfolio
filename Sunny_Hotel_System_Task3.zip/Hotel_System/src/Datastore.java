package hotel.data;

import hotel.model.Booking;
import hotel.model.Guest;
import hotel.model.Room;

import java.io.*;
import java.util.*;

/**
 * File-based persistence layer using Java Serialization.
 * BUG FIXED: class was named "Datastore" but referenced as "DataStore" everywhere.
 * BUG FIXED: rooms were saved/loaded as Map<String,Room> but used as Map<Integer,Room>;
 *            now stored directly as Map<Integer,Room> to avoid key-type mismatch.
 */
public class Datastore {

    private static final String DATA_DIR      = "hotel_data";
    private static final String ROOMS_FILE    = DATA_DIR + "/rooms.dat";
    private static final String GUESTS_FILE   = DATA_DIR + "/guests.dat";
    private static final String BOOKINGS_FILE = DATA_DIR + "/bookings.dat";

    static {
        new File(DATA_DIR).mkdirs();
    }

    // ---- Generic Save / Load ----

    @SuppressWarnings("unchecked")
    private static <K, V> Map<K, V> loadMap(String path) {
        File f = new File(path);
        if (!f.exists()) return new LinkedHashMap<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            return (Map<K, V>) ois.readObject();
        } catch (Exception e) {
            System.err.println("[DataStore] Warning: could not load " + path + " — " + e.getMessage());
            return new LinkedHashMap<>();
        }
    }

    private static <K, V> void saveMap(String path, Map<K, V> map) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(map);
        } catch (IOException e) {
            System.err.println("[DataStore] Error saving " + path + ": " + e.getMessage());
        }
    }

    // ---- Rooms ----

    public static Map<Integer, Room> loadRooms() {
        return loadMap(ROOMS_FILE);
    }

    public static void saveRooms(Map<Integer, Room> rooms) {
        saveMap(ROOMS_FILE, rooms);
    }

    // ---- Guests ----

    public static Map<String, Guest> loadGuests() {
        return loadMap(GUESTS_FILE);
    }

    public static void saveGuests(Map<String, Guest> guests) {
        saveMap(GUESTS_FILE, guests);
    }

    // ---- Bookings ----

    public static Map<String, Booking> loadBookings() {
        return loadMap(BOOKINGS_FILE);
    }

    public static void saveBookings(Map<String, Booking> bookings) {
        saveMap(BOOKINGS_FILE, bookings);
    }

    // ---- Utility ----

    public static void clearAll() {
        new File(ROOMS_FILE).delete();
        new File(GUESTS_FILE).delete();
        new File(BOOKINGS_FILE).delete();
    }
}