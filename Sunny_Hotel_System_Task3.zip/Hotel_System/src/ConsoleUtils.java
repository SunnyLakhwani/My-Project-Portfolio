package hotel.util;

import java.util.Scanner;

/**
 * Utility class for console formatting and input helpers.
 * BUG FIXED: class was package-private (missing "public"), so MainUI's static import failed.
 */
public class ConsoleUtils {

    public static final String RESET  = "\u001B[0m";
    public static final String BOLD   = "\u001B[1m";
    public static final String DIM    = "\u001B[2m";

    public static final String BLACK  = "\u001B[30m";
    public static final String RED    = "\u001B[31m";
    public static final String GREEN  = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String BLUE   = "\u001B[34m";
    public static final String PURPLE = "\u001B[35m";
    public static final String CYAN   = "\u001B[36m";
    public static final String WHITE  = "\u001B[37m";

    public static final String BG_BLUE   = "\u001B[44m";
    public static final String BG_GREEN  = "\u001B[42m";
    public static final String BG_RED    = "\u001B[41m";
    public static final String BG_YELLOW = "\u001B[43m";
    public static final String BG_CYAN   = "\u001B[46m";

    private static final int WIDTH = 70;

    public static void printLine() {
        System.out.println(DIM + "─".repeat(WIDTH) + RESET);
    }

    public static void printDoubleLine() {
        System.out.println(CYAN + "═".repeat(WIDTH) + RESET);
    }

    public static void printHeader(String title) {
        System.out.println();
        printDoubleLine();
        int padding = (WIDTH - title.length()) / 2;
        System.out.println(BOLD + CYAN +
                " ".repeat(Math.max(0, padding)) + title + RESET);
        printDoubleLine();
    }

    public static void printSectionTitle(String title) {
        System.out.println();
        System.out.println(BOLD + YELLOW + "  ▸ " + title + RESET);
        System.out.println(DIM + "  " + "─".repeat(WIDTH - 4) + RESET);
    }

    public static void printSuccess(String msg) {
        System.out.println(BOLD + GREEN + "  ✔  " + msg + RESET);
    }

    public static void printError(String msg) {
        System.out.println(BOLD + RED + "  ✘  " + msg + RESET);
    }

    public static void printInfo(String msg) {
        System.out.println(CYAN + "  ℹ  " + msg + RESET);
    }

    public static void printWarning(String msg) {
        System.out.println(YELLOW + "  ⚠  " + msg + RESET);
    }

    public static String prompt(Scanner sc, String label) {
        System.out.print(BOLD + "  › " + label + ": " + RESET);
        return sc.nextLine().trim();
    }

    public static int promptInt(Scanner sc, String label) {
        while (true) {
            try {
                return Integer.parseInt(prompt(sc, label));
            } catch (NumberFormatException e) {
                printError("Please enter a valid number.");
            }
        }
    }

    public static double promptDouble(Scanner sc, String label) {
        while (true) {
            try {
                return Double.parseDouble(prompt(sc, label));
            } catch (NumberFormatException e) {
                printError("Please enter a valid number.");
            }
        }
    }

    public static void printReceiptRow(String label, String value) {
        int pad = WIDTH - 4 - label.length() - value.length();
        System.out.println("  " + label + " ".repeat(Math.max(1, pad)) + BOLD + value + RESET);
    }

    public static void printReceiptRowColored(String label, String value, String color) {
        int pad = WIDTH - 4 - label.length() - value.length();
        System.out.println("  " + label + " ".repeat(Math.max(1, pad)) + BOLD + color + value + RESET);
    }

    public static void pause(Scanner sc) {
        System.out.print(DIM + "\n  Press Enter to continue..." + RESET);
        sc.nextLine();
    }

    public static String colorStatus(String status) {
        return switch (status) {
            case "CONFIRMED"   -> BLUE   + status + RESET;
            case "CHECKED_IN"  -> GREEN  + status + RESET;
            case "CHECKED_OUT" -> DIM    + status + RESET;
            case "CANCELLED"   -> RED    + status + RESET;
            case "PAID"        -> GREEN  + status + RESET;
            case "PENDING"     -> YELLOW + status + RESET;
            case "REFUNDED"    -> PURPLE + status + RESET;
            default            -> status;
        };
    }
}