package hotel.model;

import java.io.Serializable;

public class Room implements Serializable {

    private static final long serialVersionUID = 1L;

    public enum RoomType {
        STANDARD("Standard", 80.00, "Queen bed, TV, Wi-Fi, private bathroom"),
        DELUXE("Deluxe", 140.00, "King bed, Smart TV, Mini-bar, City view"),
        SUITE("Suite", 250.00, "2-room suite, Jacuzzi, Lounge area, Butler service"),
        PRESIDENTIAL("Presidential", 500.00, "Penthouse, Private pool, Personal chef, Panoramic view");

        private final String label;
        private final double basePrice;
        private final String amenities;

        RoomType(String label, double basePrice, String amenities) {
            this.label = label;
            this.basePrice = basePrice;
            this.amenities = amenities;
        }

        public String getLabel()     { return label; }
        public double getBasePrice() { return basePrice; }
        public String getAmenities() { return amenities; }
    }

    private final int roomNumber;
    private final RoomType type;
    private final int floor;
    private boolean available;
    private boolean underMaintenance;

    public Room(int roomNumber, RoomType type, int floor) {
        this.roomNumber       = roomNumber;
        this.type             = type;
        this.floor            = floor;
        this.available        = true;
        this.underMaintenance = false;
    }

    public int      getRoomNumber()      { return roomNumber; }
    public RoomType getType()            { return type; }
    public int      getFloor()           { return floor; }
    public boolean  isAvailable()        { return available && !underMaintenance; }
    public boolean  isUnderMaintenance() { return underMaintenance; }

    public void setAvailable(boolean available)          { this.available = available; }
    public void setUnderMaintenance(boolean maintenance) { this.underMaintenance = maintenance; }

    public double getPricePerNight() { return type.getBasePrice(); }

    @Override
    public String toString() {
        String status = underMaintenance ? "Maintenance" : (available ? "Available" : "Booked");
        return String.format("Room %03d | %-14s | Floor %d | $%-7.2f/night | %s",
                roomNumber, type.getLabel(), floor, getPricePerNight(), status);
    }
}