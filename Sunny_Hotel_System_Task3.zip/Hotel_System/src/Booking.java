package hotel.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Booking implements Serializable {

    private static final long serialVersionUID = 1L;

    public enum BookingStatus {
        CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED
    }

    public enum PaymentMethod {
        CREDIT_CARD("Credit Card"),
        DEBIT_CARD("Debit Card"),
        CASH("Cash"),
        LOYALTY_POINTS("Loyalty Points"),
        ONLINE_TRANSFER("Online Transfer");

        private final String label;
        PaymentMethod(String label) { this.label = label; }
        public String getLabel() { return label; }
    }

    public enum PaymentStatus {
        PENDING, PAID, PARTIALLY_PAID, REFUNDED
    }

    private final String    bookingId;
    private final String    guestId;
    private final int       roomNumber;
    private final LocalDate checkIn;
    private final LocalDate checkOut;
    private final long      nights;

    private final double pricePerNight;
    private double       discountAmount;
    private double       taxRate;
    private double       totalAmount;

    private BookingStatus status;
    private PaymentStatus paymentStatus;
    private PaymentMethod paymentMethod;

    private final String bookedAt;
    private String       specialRequests;
    private int          guestsCount;

    public Booking(String bookingId, String guestId, int roomNumber,
                   LocalDate checkIn, LocalDate checkOut,
                   double pricePerNight, int guestsCount) {
        this.bookingId      = bookingId;
        this.guestId        = guestId;
        this.roomNumber     = roomNumber;
        this.checkIn        = checkIn;
        this.checkOut       = checkOut;
        this.nights         = ChronoUnit.DAYS.between(checkIn, checkOut);
        this.pricePerNight  = pricePerNight;
        this.discountAmount = 0.0;
        this.taxRate        = 0.12;
        this.guestsCount    = guestsCount;
        this.status         = BookingStatus.CONFIRMED;
        this.paymentStatus  = PaymentStatus.PENDING;
        this.bookedAt       = java.time.LocalDateTime.now().toString();
        this.specialRequests = "";
        recalcTotal();
    }

    private void recalcTotal() {
        double subtotal     = pricePerNight * nights;
        double afterDiscount = subtotal - discountAmount;
        double tax          = afterDiscount * taxRate;
        this.totalAmount    = afterDiscount + tax;
    }

    public void applyDiscount(double discount) {
        this.discountAmount = discount;
        recalcTotal();
    }

    public double getSubtotal() { return pricePerNight * nights; }
    public double getTax()      { return (getSubtotal() - discountAmount) * taxRate; }

    public String        getBookingId()       { return bookingId; }
    public String        getGuestId()         { return guestId; }
    public int           getRoomNumber()      { return roomNumber; }
    public LocalDate     getCheckIn()         { return checkIn; }
    public LocalDate     getCheckOut()        { return checkOut; }
    public long          getNights()          { return nights; }
    public double        getPricePerNight()   { return pricePerNight; }
    public double        getDiscountAmount()  { return discountAmount; }
    public double        getTaxRate()         { return taxRate; }
    public double        getTotalAmount()     { return totalAmount; }
    public BookingStatus getStatus()          { return status; }
    public PaymentStatus getPaymentStatus()   { return paymentStatus; }
    public PaymentMethod getPaymentMethod()   { return paymentMethod; }
    public String        getBookedAt()        { return bookedAt; }
    public String        getSpecialRequests() { return specialRequests; }
    public int           getGuestsCount()     { return guestsCount; }

    public void setStatus(BookingStatus s)         { this.status = s; }
    public void setPaymentStatus(PaymentStatus ps) { this.paymentStatus = ps; }
    public void setPaymentMethod(PaymentMethod pm) { this.paymentMethod = pm; }
    public void setSpecialRequests(String r)       { this.specialRequests = r; }
    public void setTaxRate(double rate)            { this.taxRate = rate; recalcTotal(); }

    @Override
    public String toString() {
        return String.format(
                "Booking [%s] Room %03d | Guest: %s | %s → %s (%d nights) | $%.2f | %s | %s",
                bookingId, roomNumber, guestId,
                checkIn, checkOut, nights,
                totalAmount, status, paymentStatus);
    }
}