package hotel.service;

import hotel.model.*;
import hotel.model.Booking.BookingStatus;
import hotel.model.Booking.PaymentMethod;
import hotel.model.Booking.PaymentStatus;
import hotel.model.Room.RoomType;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class HotelService {

    private final Map<Integer, Room>   rooms;
    private final Map<String, Guest>   guests;
    private final Map<String, Booking> bookings;

    private int bookingCounter;
    private int guestCounter;

    public HotelService() {
        this.rooms    = hotel.data.Datastore.loadRooms();
        this.guests   = hotel.data.Datastore.loadGuests();
        this.bookings = hotel.data.Datastore.loadBookings();
        this.bookingCounter = bookings.size();
        this.guestCounter   = guests.size();

        if (rooms.isEmpty()) seedRooms();
    }

    // ====================================================================
    //  ROOM MANAGEMENT
    // ====================================================================

    private void seedRooms() {
        int num = 101;
        for (int floor = 1; floor <= 6; floor++) {
            for (int i = 0; i < 4; i++) rooms.put(num, new Room(num++, RoomType.STANDARD, floor));
            for (int i = 0; i < 3; i++) rooms.put(num, new Room(num++, RoomType.DELUXE,   floor));
            for (int i = 0; i < 2; i++) rooms.put(num, new Room(num++, RoomType.SUITE,     floor));
        }
        rooms.put(num, new Room(num++, RoomType.PRESIDENTIAL, 7));
        rooms.put(num, new Room(num,   RoomType.PRESIDENTIAL, 7));
        persist();
    }

    public Collection<Room> getAllRooms() { return rooms.values(); }

    public List<Room> getAvailableRooms(RoomType type, LocalDate checkIn, LocalDate checkOut) {
        Set<Integer> bookedNums = getBookedRoomNumbers(checkIn, checkOut);
        return rooms.values().stream()
                .filter(r -> (type == null || r.getType() == type))
                .filter(r -> r.isAvailable())
                .filter(r -> !bookedNums.contains(r.getRoomNumber()))
                .sorted(Comparator.comparingInt(Room::getRoomNumber))
                .collect(Collectors.toList());
    }

    private Set<Integer> getBookedRoomNumbers(LocalDate ci, LocalDate co) {
        return bookings.values().stream()
                .filter(b -> b.getStatus() != BookingStatus.CANCELLED &&
                        b.getStatus() != BookingStatus.CHECKED_OUT)
                .filter(b -> dateOverlaps(b.getCheckIn(), b.getCheckOut(), ci, co))
                .map(Booking::getRoomNumber)
                .collect(Collectors.toSet());
    }

    private boolean dateOverlaps(LocalDate existIn, LocalDate existOut,
                                 LocalDate newIn,   LocalDate newOut) {
        return newIn.isBefore(existOut) && newOut.isAfter(existIn);
    }

    public Optional<Room> getRoom(int roomNumber) {
        return Optional.ofNullable(rooms.get(roomNumber));
    }

    public void setRoomMaintenance(int roomNumber, boolean status) {
        getRoom(roomNumber).ifPresent(r -> {
            r.setUnderMaintenance(status);
            persist();
        });
    }

    // ====================================================================
    //  GUEST MANAGEMENT
    // ====================================================================

    public Guest registerGuest(String name, String email, String phone, String idProof) {
        String id = String.format("G%04d", ++guestCounter);
        Guest g = new Guest(id, name, email, phone, idProof);
        guests.put(id, g);
        persist();
        return g;
    }

    public Optional<Guest> findGuestById(String id) {
        return Optional.ofNullable(guests.get(id));
    }

    public Optional<Guest> findGuestByEmail(String email) {
        return guests.values().stream()
                .filter(g -> g.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }

    public Collection<Guest> getAllGuests() { return guests.values(); }

    // ====================================================================
    //  RESERVATION MANAGEMENT
    // ====================================================================

    public Booking makeReservation(String guestId, int roomNumber,
                                   LocalDate checkIn, LocalDate checkOut,
                                   int guestsCount, String specialRequests,
                                   double loyaltyPointsToRedeem) {

        if (checkIn.isAfter(checkOut) || checkIn.equals(checkOut)) return null;

        Set<Integer> bookedNums = getBookedRoomNumbers(checkIn, checkOut);
        if (bookedNums.contains(roomNumber)) return null;

        Room room = rooms.get(roomNumber);
        if (room == null || !room.isAvailable()) return null;

        Guest guest = guests.get(guestId);
        if (guest == null) return null;

        String bid = String.format("BK%05d", ++bookingCounter);
        Booking booking = new Booking(bid, guestId, roomNumber,
                checkIn, checkOut, room.getPricePerNight(), guestsCount);
        booking.setSpecialRequests(specialRequests);

        if (loyaltyPointsToRedeem > 0) {
            double discount = guest.getLoyaltyDiscount(loyaltyPointsToRedeem);
            if (guest.redeemLoyaltyPoints(loyaltyPointsToRedeem)) {
                booking.applyDiscount(discount);
            }
        }

        bookings.put(bid, booking);
        guest.addBookingId(bid);
        persist();
        return booking;
    }

    public boolean processPayment(String bookingId, PaymentMethod method) {
        Booking b = bookings.get(bookingId);
        if (b == null || b.getPaymentStatus() == PaymentStatus.PAID) return false;

        b.setPaymentMethod(method);
        b.setPaymentStatus(PaymentStatus.PAID);

        Guest g = guests.get(b.getGuestId());
        if (g != null) g.addLoyaltyPoints(b.getTotalAmount());

        persist();
        return true;
    }

    public boolean checkIn(String bookingId) {
        Booking b = bookings.get(bookingId);
        if (b == null || b.getStatus() != BookingStatus.CONFIRMED) return false;
        if (b.getPaymentStatus() != PaymentStatus.PAID) return false;
        b.setStatus(BookingStatus.CHECKED_IN);
        rooms.get(b.getRoomNumber()).setAvailable(false);
        persist();
        return true;
    }

    public boolean checkOut(String bookingId) {
        Booking b = bookings.get(bookingId);
        if (b == null || b.getStatus() != BookingStatus.CHECKED_IN) return false;
        b.setStatus(BookingStatus.CHECKED_OUT);
        rooms.get(b.getRoomNumber()).setAvailable(true);
        persist();
        return true;
    }

    public boolean cancelReservation(String bookingId) {
        Booking b = bookings.get(bookingId);
        if (b == null || b.getStatus() == BookingStatus.CANCELLED
                || b.getStatus() == BookingStatus.CHECKED_OUT) return false;

        b.setStatus(BookingStatus.CANCELLED);
        if (b.getPaymentStatus() == PaymentStatus.PAID) {
            b.setPaymentStatus(PaymentStatus.REFUNDED);
            Guest g = guests.get(b.getGuestId());
            if (g != null) {
                double pts = b.getTotalAmount() / 10.0;
                g.setLoyaltyPoints(Math.max(0, g.getLoyaltyPoints() - pts));
            }
        }
        rooms.get(b.getRoomNumber()).setAvailable(true);
        persist();
        return true;
    }

    public Optional<Booking> getBooking(String id) {
        return Optional.ofNullable(bookings.get(id));
    }

    public List<Booking> getBookingsByGuest(String guestId) {
        return bookings.values().stream()
                .filter(b -> b.getGuestId().equals(guestId))
                .sorted(Comparator.comparing(Booking::getBookedAt).reversed())
                .collect(Collectors.toList());
    }

    public Collection<Booking> getAllBookings() { return bookings.values(); }

    // ====================================================================
    //  REPORTING
    // ====================================================================

    public double getTotalRevenue() {
        return bookings.values().stream()
                .filter(b -> b.getPaymentStatus() == PaymentStatus.PAID
                        || b.getPaymentStatus() == PaymentStatus.REFUNDED)
                .mapToDouble(Booking::getTotalAmount)
                .sum();
    }

    public double getOccupancyRate() {
        long occupied = bookings.values().stream()
                .filter(b -> b.getStatus() == BookingStatus.CHECKED_IN)
                .count();
        return rooms.isEmpty() ? 0 : (double) occupied / rooms.size() * 100;
    }

    public long getTodayCheckIns() {
        LocalDate today = LocalDate.now();
        return bookings.values().stream()
                .filter(b -> b.getCheckIn().equals(today)
                        && b.getStatus() == BookingStatus.CONFIRMED)
                .count();
    }

    // ====================================================================
    //  INTERNAL
    // ====================================================================

    private void persist() {
        hotel.data.Datastore.saveRooms(rooms);
        hotel.data.Datastore.saveGuests(guests);
        hotel.data.Datastore.saveBookings(bookings);
    }
}