import os
import socket
import datetime
from flask import Flask, jsonify, render_template

app = Flask(__name__)

BUILD_ID  = os.getenv("BUILD_ID", "local")
ENV       = os.getenv("ENVIRONMENT", "development")
START_TIME = datetime.datetime.utcnow()


@app.route("/")
def index():
    return render_template("index.html", build_id=BUILD_ID, env=ENV)


@app.route("/health")
def health():
    """Health endpoint consumed by Azure App Service and the pipeline gate."""
    uptime = (datetime.datetime.utcnow() - START_TIME).seconds
    return jsonify({
        "status": "healthy",
        "build_id": BUILD_ID,
        "environment": ENV,
        "hostname": socket.gethostname(),
        "uptime_seconds": uptime,
        "timestamp": datetime.datetime.utcnow().isoformat() + "Z"
    }), 200


@app.route("/info")
def info():
    return jsonify({
        "app": "CodeAlpha DevOps Demo — Task 1",
        "version": BUILD_ID,
        "environment": ENV,
        "python_version": os.popen("python --version").read().strip()
    })


if __name__ == "__main__":
    port = int(os.getenv("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=(ENV != "production"))