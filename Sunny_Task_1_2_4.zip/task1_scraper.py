import csv
import time
import threading
import http.server
import textwrap
from io import StringIO
from bs4 import BeautifulSoup
import urllib.request
import urllib.error
import urllib.parse

# ── Local mock server ────────────────────────────────────────────────────────

MOCK_HTML = """
<!DOCTYPE html>
<html>
<head><title>Books to Scrape — Catalogue</title></head>
<body>
<div class="page_inner">

<section>
  <div id="messages"></div>
  <div class="row">
    <section>
      <div class="row">
        <ol class="row">

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Five"><i class="icon-star"></i></p>
              <h3><a href="#" title="A Light in the Attic">A Light in the Attic</a></h3>
              <p class="price_color">£51.77</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Four"><i class="icon-star"></i></p>
              <h3><a href="#" title="Tipping the Velvet">Tipping the Velvet</a></h3>
              <p class="price_color">£53.74</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating One"><i class="icon-star"></i></p>
              <h3><a href="#" title="Soumission">Soumission</a></h3>
              <p class="price_color">£50.10</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating One"><i class="icon-star"></i></p>
              <h3><a href="#" title="Sharp Objects">Sharp Objects</a></h3>
              <p class="price_color">£47.82</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating One"><i class="icon-star"></i></p>
              <h3><a href="#" title="Sapiens: A Brief History of Humankind">Sapiens: A Brief History of Humankind</a></h3>
              <p class="price_color">£54.23</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Four"><i class="icon-star"></i></p>
              <h3><a href="#" title="The Requiem Red">The Requiem Red</a></h3>
              <p class="price_color">£22.65</p>
              <p class="availability">Out of stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Five"><i class="icon-star"></i></p>
              <h3><a href="#" title="The Boys in the Boat">The Boys in the Boat</a></h3>
              <p class="price_color">£22.60</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Five"><i class="icon-star"></i></p>
              <h3><a href="#" title="The Black Maria">The Black Maria</a></h3>
              <p class="price_color">£52.15</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating One"><i class="icon-star"></i></p>
              <h3><a href="#" title="Starving Hearts">Starving Hearts</a></h3>
              <p class="price_color">£13.99</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Two"><i class="icon-star"></i></p>
              <h3><a href="#" title="Mesaerion: The Best Science Fiction Stories">Mesaerion</a></h3>
              <p class="price_color">£37.59</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating One"><i class="icon-star"></i></p>
              <h3><a href="#" title="Libertarianism for Beginners">Libertarianism for Beginners</a></h3>
              <p class="price_color">£51.33</p>
              <p class="availability">Out of stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Three"><i class="icon-star"></i></p>
              <h3><a href="#" title="It's Only the Himalayas">It's Only the Himalayas</a></h3>
              <p class="price_color">£45.17</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Two"><i class="icon-star"></i></p>
              <h3><a href="#" title="How Music Works">How Music Works</a></h3>
              <p class="price_color">£37.32</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Three"><i class="icon-star"></i></p>
              <h3><a href="#" title="Fooled by Randomness">Fooled by Randomness</a></h3>
              <p class="price_color">£30.52</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Five"><i class="icon-star"></i></p>
              <h3><a href="#" title="Booked">Booked</a></h3>
              <p class="price_color">£37.35</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating One"><i class="icon-star"></i></p>
              <h3><a href="#" title="Black Dust">Black Dust</a></h3>
              <p class="price_color">£34.53</p>
              <p class="availability">Out of stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Three"><i class="icon-star"></i></p>
              <h3><a href="#" title="Birdsong: A Story in Pictures">Birdsong: A Story in Pictures</a></h3>
              <p class="price_color">£54.64</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Three"><i class="icon-star"></i></p>
              <h3><a href="#" title="America's War for the Greater Middle East">America's War for the Greater Middle East</a></h3>
              <p class="price_color">£57.03</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Three"><i class="icon-star"></i></p>
              <h3><a href="#" title="Aladdin and the Enchanted Lamp">Aladdin and the Enchanted Lamp</a></h3>
              <p class="price_color">£53.13</p>
              <p class="availability">In stock</p>
            </article>
          </li>

          <li class="col-xs-6 col-sm-4 col-md-3 col-lg-3">
            <article class="product_pod">
              <p class="star-rating Four"><i class="icon-star"></i></p>
              <h3><a href="#" title="Worlds Elsewhere: Journeys Around Shakespeare's Globe">Worlds Elsewhere</a></h3>
              <p class="price_color">£40.30</p>
              <p class="availability">In stock</p>
            </article>
          </li>

        </ol>
      </div>
    </section>
  </div>
</div>
</section>
</body>
</html>
"""


class MockHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        self.wfile.write(MOCK_HTML.encode())

    def log_message(self, *args):
        pass  # suppress server logs


def start_mock_server(port=8765):
    server = http.server.HTTPServer(("127.0.0.1", port), MockHandler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    return server


# ── Scraper ──────────────────────────────────────────────────────────────────

RATING_MAP = {
    "One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5
}


def fetch_html(url: str, retries: int = 3, delay: float = 1.0) -> str:
    """Fetch a URL with basic retry logic."""
    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "Mozilla/5.0 (CodeAlpha-Scraper/1.0)"}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except Exception as exc:
            print(f"  Attempt {attempt} failed: {exc}")
            if attempt < retries:
                time.sleep(delay)
    raise RuntimeError(f"Could not fetch {url} after {retries} attempts.")


def parse_books(html: str) -> list[dict]:
    """Parse book cards from catalogue HTML."""
    soup = BeautifulSoup(html, "html.parser")
    books = []

    for article in soup.select("article.product_pod"):
        # Title — stored in the <a> tag's title attribute for full name
        title_tag = article.select_one("h3 > a")
        title = title_tag["title"] if title_tag and title_tag.has_attr("title") else title_tag.text.strip()

        # Price — strip the £ symbol and convert to float
        price_tag = article.select_one("p.price_color")
        price_text = price_tag.text.strip().replace("£", "").replace(",", "") if price_tag else "0"
        price = float(price_text)

        # Star rating — encoded as a CSS class word
        rating_tag = article.select_one("p.star-rating")
        rating_word = rating_tag["class"][1] if rating_tag else "Zero"
        rating = RATING_MAP.get(rating_word, 0)

        # Availability
        avail_tag = article.select_one("p.availability")
        availability = avail_tag.text.strip() if avail_tag else "Unknown"

        books.append({
            "title": title,
            "price_gbp": price,
            "rating": rating,
            "availability": availability,
        })

    return books


def save_csv(books: list[dict], path: str) -> None:
    """Write scraped data to a CSV file."""
    fieldnames = ["title", "price_gbp", "rating", "availability"]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(books)
    print(f"  Saved {len(books)} records → {path}")


def print_summary(books: list[dict]) -> None:
    """Quick console summary of what was scraped."""
    prices = [b["price_gbp"] for b in books]
    ratings = [b["rating"] for b in books]
    in_stock = sum(1 for b in books if "In stock" in b["availability"])

    print(f"\n{'─'*50}")
    print(f"  Total books scraped : {len(books)}")
    print(f"  Price range         : £{min(prices):.2f} – £{max(prices):.2f}")
    print(f"  Average price       : £{sum(prices)/len(prices):.2f}")
    print(f"  Average rating      : {sum(ratings)/len(ratings):.1f} / 5")
    print(f"  In stock            : {in_stock} / {len(books)}")
    print(f"{'─'*50}\n")

    print("  Sample records:")
    for b in books[:5]:
        print(f"    {'★'*b['rating']}{'☆'*(5-b['rating'])}  £{b['price_gbp']:.2f}  {b['title'][:45]}")
    print()


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    print("=" * 50)
    print("               Web Scraping                  ")
    print("  Target: books.toscrape.com (catalogue page)")
    print("=" * 50)

    # For live scraping, replace LOCAL_URL with:
    # TARGET_URL = "https://books.toscrape.com/catalogue/page-1.html"
    print("\n[*] Starting local mock server (mirrors books.toscrape.com structure)…")
    start_mock_server(8765)
    time.sleep(0.3)
    TARGET_URL = "http://127.0.0.1:8765/"

    print(f"[*] Fetching: {TARGET_URL}")
    html = fetch_html(TARGET_URL)
    print(f"[*] Received {len(html):,} bytes of HTML")

    print("[*] Parsing book listings…")
    books = parse_books(html)
    print(f"[*] Extracted {len(books)} book records")

    print_summary(books)

    output_path = "books_scraped.csv"
    save_csv(books, output_path)

    print("[✓] Task 1 complete.\n")
    return output_path


if __name__ == "__main__":
    main()
