set -euo pipefail

# ── Configuration (edit these) ──────────────────────────────
RESOURCE_GROUP="codealpha-rg"
LOCATION="eastus"
ACR_NAME="codealphacr"
APP_SERVICE_PLAN="codealpha-plan"
APP_SERVICE_NAME="codealpha-webapp-prod"
SKU_PLAN="B1"   # Basic tier — free-tier eligible for demo

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
log()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC}  $*"; }
err()  { echo -e "${RED}[ERR]${NC}   $*"; exit 1; }

# ────────────────────────────────────────────────────────────
setup_infrastructure() {
    log "Creating resource group: $RESOURCE_GROUP"
    az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output table

    log "Creating Azure Container Registry: $ACR_NAME"
    az acr create \
        --resource-group "$RESOURCE_GROUP" \
        --name "$ACR_NAME" \
        --sku Basic \
        --admin-enabled true \
        --output table

    log "Creating App Service Plan: $APP_SERVICE_PLAN"
    az appservice plan create \
        --name "$APP_SERVICE_PLAN" \
        --resource-group "$RESOURCE_GROUP" \
        --sku "$SKU_PLAN" \
        --is-linux \
        --output table

    log "Creating Web App: $APP_SERVICE_NAME"
    ACR_SERVER="${ACR_NAME}.azurecr.io"
    az webapp create \
        --name "$APP_SERVICE_NAME" \
        --resource-group "$RESOURCE_GROUP" \
        --plan "$APP_SERVICE_PLAN" \
        --deployment-container-image-name "${ACR_SERVER}/codealpha-webapp:latest" \
        --output table

    log "Enabling continuous deployment from ACR"
    az webapp deployment container config \
        --name "$APP_SERVICE_NAME" \
        --resource-group "$RESOURCE_GROUP" \
        --enable-cd true \
        --output table

    log "Configuring ACR credentials in App Service"
    ACR_PASSWORD=$(az acr credential show --name "$ACR_NAME" --query "passwords[0].value" -o tsv)
    az webapp config container set \
        --name "$APP_SERVICE_NAME" \
        --resource-group "$RESOURCE_GROUP" \
        --docker-registry-server-url "https://${ACR_SERVER}" \
        --docker-registry-server-user "$ACR_NAME" \
        --docker-registry-server-password "$ACR_PASSWORD" \
        --output table

    log "Infrastructure ready!"
    echo ""
    echo "  ACR Login Server : ${ACR_SERVER}"
    echo "  App URL          : https://${APP_SERVICE_NAME}.azurewebsites.net"
}

# ────────────────────────────────────────────────────────────
monitor_pipeline() {
    log "Fetching latest pipeline run status..."
    APP_URL="https://${APP_SERVICE_NAME}.azurewebsites.net"

    echo ""
    log "Health check: ${APP_URL}/health"
    HTTP_CODE=$(curl -s -o /tmp/health_resp.json -w "%{http_code}" "${APP_URL}/health" || echo "000")

    if [[ "$HTTP_CODE" == "200" ]]; then
        log "App is healthy (HTTP 200)"
        cat /tmp/health_resp.json | python3 -m json.tool 2>/dev/null || cat /tmp/health_resp.json
    else
        warn "⚠ App returned HTTP $HTTP_CODE. Check Azure portal logs."
    fi

    echo ""
    log "App Service logs (last 50 lines):"
    az webapp log tail \
        --name "$APP_SERVICE_NAME" \
        --resource-group "$RESOURCE_GROUP" \
        --timeout 10 2>/dev/null || warn "Could not stream logs — try 'az webapp log download'"

    echo ""
    log "ACR repositories:"
    az acr repository list --name "$ACR_NAME" --output table

    log "Recent ACR tags:"
    az acr repository show-tags \
        --name "$ACR_NAME" \
        --repository codealpha-webapp \
        --orderby time_desc \
        --top 5 \
        --output table
}

# ────────────────────────────────────────────────────────────
cleanup() {
    warn "This will DELETE the resource group '$RESOURCE_GROUP' and ALL resources inside it."
    read -rp "Type 'yes' to confirm: " CONFIRM
    if [[ "$CONFIRM" == "yes" ]]; then
        az group delete --name "$RESOURCE_GROUP" --yes --no-wait
        log "Deletion triggered (runs in background)."
    else
        log "Cleanup cancelled."
    fi
}

# ────────────────────────────────────────────────────────────
COMMAND="${1:-help}"
case "$COMMAND" in
    setup)   setup_infrastructure ;;
    monitor) monitor_pipeline ;;
    cleanup) cleanup ;;
    *)
        echo "Usage: $0 {setup|monitor|cleanup}"
        echo ""
        echo "  setup   — provisions ACR, App Service Plan, and Web App"
        echo "  monitor — health-checks the live app and tails App Service logs"
        echo "  cleanup — deletes all provisioned Azure resources"
        ;;
esac