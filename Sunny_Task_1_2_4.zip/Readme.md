# Task 1 — CI/CD Pipeline using Azure

**CodeAlpha DevOps Internship**

## What this does

This project sets up a complete CI/CD pipeline on Azure that automatically builds, tests, containerises, and deploys a Python Flask web application whenever code is pushed to the `main` branch.

```
Developer pushes code
       │
       ▼
Azure Pipelines triggered
       │
  ┌────┴────┐
  │ Stage 1 │  Unit tests (pytest) + Lint (flake8) + Security scan (bandit)
  └────┬────┘
       │ passes
  ┌────▼────┐
  │ Stage 2 │  Docker build → Trivy image scan → Push to Azure Container Registry
  └────┬────┘
       │ on main branch only
  ┌────▼────┐
  │ Stage 3 │  Deploy container to Azure App Service → Health gate check
  └────┬────┘
       │
  ┌────▼────┐
  │ Stage 4 │  Post-deploy notification & summary
  └─────────┘
```

## Project structure

```
CodeAlpha_Task1_CICD/
├── azure-pipelines/
│   └── azure-pipelines.yml    # Full 4-stage pipeline definition
├── webapp/
│   ├── app.py                 # Flask app with /health and /info endpoints
│   ├── requirements.txt
│   └── tests/
│       └── test_app.py        # Pytest unit tests
├── Dockerfile                 # Multi-stage build (slim production image)
└── scripts/
    └── setup_azure.sh         # Infra provisioning + monitoring helper
```

## Setup steps

### 1 — Prerequisites
- Azure CLI (`az`) installed and logged in (`az login`)
- Azure DevOps organisation with a project
- Docker installed locally (for testing builds)

### 2 — Provision Azure infrastructure
```bash
bash scripts/setup_azure.sh setup
```
This creates the resource group, ACR, App Service Plan, and Web App in one shot.

### 3 — Create Azure DevOps pipeline
1. Go to your Azure DevOps project → Pipelines → New Pipeline
2. Select your GitHub repo
3. Choose "Existing Azure Pipelines YAML file"
4. Point to `azure-pipelines/azure-pipelines.yml`
5. Add a service connection named `CodeAlphaACRConnection` (Docker Registry → Azure Container Registry)
6. Add a service connection named `CodeAlphaAzureSubscription` (Azure Resource Manager)

### 4 — Push code and watch it run
```bash
git add .
git commit -m "feat: initial deployment"
git push origin main
```

### 5 — Monitor
```bash
bash scripts/setup_azure.sh monitor
```

## Running locally
```bash
pip install -r webapp/requirements.txt
cd webapp
python app.py
# Visit http://localhost:5000/health
```

## Key DevOps concepts demonstrated
- **Trigger-based automation** — pipeline fires on every push to `main`
- **Multi-stage pipeline** — separate build, push, deploy, and notify stages
- **Immutable container tags** — every build gets a unique `BUILD_ID` tag
- **Security scanning** — Trivy scans the image before it reaches production
- **Health gating** — deployment is only considered successful if `/health` returns HTTP 200
- **Least-privilege containers** — app runs as a non-root user inside Docker