import random
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import sys
print(sys.executable)

import seaborn as sns
import warnings

warnings.filterwarnings("ignore")
random.seed(42)
np.random.seed(42)


# ── 1. Generate realistic dataset ────────────────────────────────────────────

def build_dataset(n: int = 1200) -> pd.DataFrame:
   
    categories  = ["Electronics", "Clothing", "Books", "Home & Garden", "Sports", "Toys"]
    regions     = ["North", "South", "East", "West"]
    cat_weights = [0.28, 0.24, 0.14, 0.16, 0.10, 0.08]

    months = np.random.choice(range(1, 13), size=n,
                              p=[0.06, 0.06, 0.07, 0.07, 0.08, 0.07,
                                 0.07, 0.07, 0.08, 0.09, 0.11, 0.17])

    chosen_cats = np.random.choice(categories, size=n, p=cat_weights)

    base_prices = {
        "Electronics": 180, "Clothing": 55, "Books": 22,
        "Home & Garden": 75, "Sports": 90, "Toys": 40
    }
    prices = np.array([
        max(5, np.random.lognormal(math.log(base_prices[c]), 0.45))
        for c in chosen_cats
    ])

    quantities = np.random.choice([1, 2, 3, 4, 5], size=n, p=[0.45, 0.30, 0.14, 0.07, 0.04])

    # Discounts slightly higher for expensive categories
    discount_means = {
        "Electronics": 0.12, "Clothing": 0.15, "Books": 0.05,
        "Home & Garden": 0.08, "Sports": 0.10, "Toys": 0.07
    }
    discounts = np.clip(
        [np.random.normal(discount_means[c], 0.05) for c in chosen_cats], 0, 0.40
    )

    revenue = prices * quantities * (1 - discounts)

    customer_ids = np.random.randint(1, 701, size=n)   # ~700 unique customers → repeat buyers
    is_returning = np.array([customer_ids.tolist().count(cid) > 1 for cid in customer_ids])

    df = pd.DataFrame({
        "order_id":       range(1001, 1001 + n),
        "month":          months,
        "category":       chosen_cats,
        "region":         np.random.choice(regions, size=n),
        "unit_price":     prices.round(2),
        "quantity":       quantities,
        "discount_rate":  discounts.round(3),
        "revenue":        revenue.round(2),
        "customer_id":    customer_ids,
        "returning":      is_returning,
    })

    # Inject a small handful of nulls to make cleaning realistic
    null_idx = np.random.choice(df.index, size=18, replace=False)
    df.loc[null_idx[:9],  "discount_rate"] = np.nan
    df.loc[null_idx[9:],  "unit_price"]    = np.nan

    return df


# ── 2. Data cleaning ──────────────────────────────────────────────────────────

def clean(df: pd.DataFrame) -> pd.DataFrame:
    print(f"  Rows before cleaning : {len(df)}")
    print(f"  Missing values       :\n{df.isnull().sum()[df.isnull().sum() > 0].to_string()}")

    # Fill discount_rate nulls with category median (better than global mean)
    df["discount_rate"] = df.groupby("category")["discount_rate"].transform(
        lambda s: s.fillna(s.median())
    )
    # Fill unit_price nulls with category median
    df["unit_price"] = df.groupby("category")["unit_price"].transform(
        lambda s: s.fillna(s.median())
    )
    # Recalculate revenue for rows that had null unit_price
    mask = df["revenue"].isnull()
    df.loc[mask, "revenue"] = (
        df.loc[mask, "unit_price"] * df.loc[mask, "quantity"] *
        (1 - df.loc[mask, "discount_rate"])
    ).round(2)

    print(f"  Missing after fix    : {df.isnull().sum().sum()}")
    print(f"  Rows after cleaning  : {len(df)}\n")
    return df


# ── 3. Statistical summary ────────────────────────────────────────────────────

def describe(df: pd.DataFrame) -> None:
    print("── Descriptive Statistics ──")
    stats = df[["unit_price", "quantity", "discount_rate", "revenue"]].describe().round(2)
    print(stats.to_string())

    print(f"\n  Total revenue         : £{df['revenue'].sum():,.2f}")
    print(f"  Median order value    : £{df['revenue'].median():.2f}")
    print(f"  Skewness (revenue)    : {df['revenue'].skew():.2f}  (right-skewed, as expected)")
    print(f"  Returning customers   : {df['returning'].mean()*100:.1f}%")

    print("\n── Revenue by Category ──")
    cat_rev = df.groupby("category")["revenue"].agg(["sum", "mean", "count"])
    cat_rev.columns = ["total_revenue", "avg_order", "num_orders"]
    cat_rev = cat_rev.sort_values("total_revenue", ascending=False)
    print(cat_rev.round(2).to_string())
    print()


# ── 4. Visualisations ─────────────────────────────────────────────────────────

PALETTE = {
    "Electronics":   "#2563eb",
    "Clothing":      "#7c3aed",
    "Books":         "#059669",
    "Home & Garden": "#d97706",
    "Sports":        "#dc2626",
    "Toys":          "#db2777",
}

def plot_all(df: pd.DataFrame, out_dir: str) -> None:
    plt.rcParams.update({
        "font.family":   "DejaVu Sans",
        "axes.spines.top":   False,
        "axes.spines.right": False,
        "axes.grid":         True,
        "grid.alpha":        0.3,
        "figure.facecolor":  "#f8f9fa",
        "axes.facecolor":    "#f8f9fa",
    })

    fig = plt.figure(figsize=(18, 14), facecolor="#f8f9fa")
    fig.suptitle(
        "E-Commerce Orders — Exploratory Data Analysis",
        fontsize=18, fontweight="bold", y=0.98, color="#1e293b"
    )
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)

    colors = list(PALETTE.values())

    # ── Plot 1: Revenue distribution ──────────────────────────────────────────
    ax1 = fig.add_subplot(gs[0, :2])
    ax1.hist(df["revenue"], bins=50, color="#2563eb", alpha=0.8, edgecolor="white", linewidth=0.4)
    ax1.axvline(df["revenue"].median(), color="#dc2626", lw=1.8, ls="--", label=f"Median £{df['revenue'].median():.0f}")
    ax1.axvline(df["revenue"].mean(),   color="#d97706", lw=1.8, ls="--", label=f"Mean £{df['revenue'].mean():.0f}")
    ax1.set_title("Revenue Distribution (log-normal tail)", fontweight="bold")
    ax1.set_xlabel("Revenue (£)")
    ax1.set_ylabel("Number of Orders")
    ax1.legend(framealpha=0)

    # ── Plot 2: Revenue by category (bar) ─────────────────────────────────────
    ax2 = fig.add_subplot(gs[0, 2])
    cat_rev = df.groupby("category")["revenue"].sum().sort_values(ascending=True)
    bars = ax2.barh(cat_rev.index, cat_rev.values / 1000,
                    color=[PALETTE[c] for c in cat_rev.index], alpha=0.85)
    ax2.set_title("Total Revenue by Category", fontweight="bold")
    ax2.set_xlabel("Revenue (£ thousands)")
    ax2.bar_label(bars, fmt="£%.0fk", padding=3, fontsize=8)

    # ── Plot 3: Monthly revenue trend ─────────────────────────────────────────
    ax3 = fig.add_subplot(gs[1, :2])
    monthly = df.groupby("month")["revenue"].sum()
    month_labels = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    ax3.plot(monthly.index, monthly.values / 1000, marker="o",
             color="#2563eb", linewidth=2, markersize=6, markerfacecolor="white", markeredgewidth=2)
    ax3.fill_between(monthly.index, monthly.values / 1000, alpha=0.12, color="#2563eb")
    ax3.set_xticks(range(1, 13))
    ax3.set_xticklabels(month_labels)
    ax3.set_title("Monthly Revenue Trend (Q4 holiday spike visible)", fontweight="bold")
    ax3.set_ylabel("Revenue (£ thousands)")

    # ── Plot 4: Discount vs Revenue scatter ───────────────────────────────────
    ax4 = fig.add_subplot(gs[1, 2])
    cat_list = list(PALETTE.keys())
    for cat in cat_list:
        sub = df[df["category"] == cat]
        ax4.scatter(sub["discount_rate"] * 100, sub["revenue"],
                    alpha=0.35, s=14, color=PALETTE[cat], label=cat)
    # Trend line
    z = np.polyfit(df["discount_rate"] * 100, df["revenue"], 1)
    p = np.poly1d(z)
    x_line = np.linspace(0, 40, 100)
    ax4.plot(x_line, p(x_line), color="#dc2626", lw=1.5, ls="--", label="Trend")
    ax4.set_title("Discount Rate vs Revenue", fontweight="bold")
    ax4.set_xlabel("Discount (%)")
    ax4.set_ylabel("Revenue (£)")
    ax4.legend(fontsize=6.5, framealpha=0, ncol=2)

    # ── Plot 5: Returning vs. new customer count by region ────────────────────
    ax5 = fig.add_subplot(gs[2, 0])
    ret_region = df.groupby(["region", "returning"]).size().unstack(fill_value=0)
    ret_region.columns = ["New", "Returning"]
    ret_region.plot(kind="bar", ax=ax5, color=["#7c3aed", "#059669"], alpha=0.85,
                    edgecolor="white", linewidth=0.4)
    ax5.set_title("New vs Returning Customers\nby Region", fontweight="bold")
    ax5.set_xlabel("")
    ax5.set_ylabel("Number of Orders")
    ax5.set_xticklabels(ax5.get_xticklabels(), rotation=0)
    ax5.legend(framealpha=0)

    # ── Plot 6: Average order value by category ───────────────────────────────
    ax6 = fig.add_subplot(gs[2, 1])
    avg_order = df.groupby("category")["revenue"].mean().sort_values(ascending=False)
    ax6.bar(range(len(avg_order)), avg_order.values,
            color=[PALETTE[c] for c in avg_order.index], alpha=0.85, edgecolor="white")
    ax6.set_xticks(range(len(avg_order)))
    ax6.set_xticklabels(avg_order.index, rotation=20, ha="right", fontsize=8)
    ax6.set_title("Average Order Value\nby Category", fontweight="bold")
    ax6.set_ylabel("Avg Revenue (£)")

    # ── Plot 7: Correlation heatmap ───────────────────────────────────────────
    ax7 = fig.add_subplot(gs[2, 2])
    corr_cols = ["unit_price", "quantity", "discount_rate", "revenue"]
    corr = df[corr_cols].corr()
    mask = np.triu(np.ones_like(corr, dtype=bool), k=1)
    sns.heatmap(corr, ax=ax7, annot=True, fmt=".2f", cmap="RdYlGn",
                center=0, linewidths=0.5, square=True,
                cbar_kws={"shrink": 0.75}, annot_kws={"size": 9})
    ax7.set_title("Correlation Matrix", fontweight="bold")
    ax7.tick_params(axis="x", rotation=30, labelsize=8)
    ax7.tick_params(axis="y", rotation=0, labelsize=8)

    out_path = f"{out_dir}/eda_dashboard.png"
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#f8f9fa")
    plt.close()
    print(f"  Plot saved → {out_path}")
    return out_path


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    print("=" * 55)
    print("             Exploratory Data Analysis            ")
    print("  Dataset: E-Commerce Customer Orders (1 200 rows)")
    print("=" * 55)

    print("\n[1] Generating dataset…")
    df = build_dataset(1200)
    print(f"  Shape: {df.shape}  |  Columns: {list(df.columns)}")

    print("\n[2] Cleaning data…")
    df = clean(df)

    csv_path = "orders_cleaned.csv"
    df.to_csv(csv_path, index=False)
    print(f"  Cleaned dataset saved → {csv_path}")

    print("\n[3] Statistical summary…\n")
    describe(df)

    print("[4] Generating visualisation dashboard…")
    plot_all(df, "output_plots")
    print("\n[✓] Task 2 complete.\n")


if __name__ == "__main__":
    main() 