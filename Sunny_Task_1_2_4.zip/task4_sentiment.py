import re
import csv
import random
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from collections import Counter
import warnings

warnings.filterwarnings("ignore")
random.seed(42)
np.random.seed(42)


# ── Lexicon ──────────────────────────────────────────────────────────────────
# A focused, high-precision subset. Real deployments use VADER or SentiWordNet,
# but this self-contained version is transparent and easy to audit.

POSITIVE_WORDS = {
    # Quality / experience
    "excellent", "outstanding", "superb", "fantastic", "brilliant", "amazing",
    "wonderful", "great", "good", "solid", "perfect", "flawless", "premium",
    "impressive", "exceptional", "incredible", "phenomenal", "remarkable",
    # Delivery / service
    "fast", "quick", "prompt", "timely", "reliable", "responsive", "helpful",
    "efficient", "seamless", "smooth",
    # Value
    "affordable", "bargain", "worth", "value", "recommend", "recommended",
    # Feeling
    "love", "loved", "enjoy", "enjoyed", "happy", "satisfied", "pleased",
    "delighted", "thrilled", "excited", "impressed",
    # Product-specific
    "durable", "sturdy", "comfortable", "accurate", "easy", "simple",
    "stylish", "attractive", "beautiful", "clean",
}

NEGATIVE_WORDS = {
    # Quality / experience
    "terrible", "awful", "horrible", "dreadful", "appalling", "atrocious",
    "poor", "bad", "cheap", "flimsy", "broken", "defective", "faulty",
    "disappointing", "disappointed", "useless", "worthless", "inferior",
    # Delivery / service
    "slow", "late", "delayed", "rude", "unhelpful", "unresponsive", "missing",
    "lost", "damaged", "wrong",
    # Feeling
    "hate", "hated", "regret", "frustrated", "annoyed", "angry", "upset",
    "dissatisfied", "unhappy", "disgusted",
    # Value
    "overpriced", "expensive", "waste", "wasted", "scam", "fraud",
    # Product-specific
    "uncomfortable", "inaccurate", "difficult", "complicated", "ugly",
    "dirty", "smells", "loud", "noisy", "leaking",
}

NEGATION_WORDS = {"not", "no", "never", "neither", "nobody", "nothing",
                  "nowhere", "nor", "cannot", "can't", "won't", "don't",
                  "doesn't", "didn't", "isn't", "wasn't", "aren't", "weren't"}

INTENSIFIERS = {"very", "really", "extremely", "absolutely", "incredibly",
                "highly", "completely", "totally", "utterly", "super"}


# ── Review corpus ─────────────────────────────────────────────────────────────

REVIEW_TEMPLATES = {
    "positive": [
        "This {product} is absolutely fantastic. Arrived quickly and works perfectly. Highly recommend!",
        "Outstanding quality for the price. Very impressed with the build and comfort. Will buy again.",
        "Great product. Easy to set up and works exactly as described. Fast shipping too.",
        "I love this {product}! Superb design and really durable. Delighted with my purchase.",
        "Excellent value. The quality is premium and delivery was prompt. Very satisfied.",
        "Works brilliantly. Solid construction and looks stylish. Happy with this buy.",
        "Amazing product. Comfortable to use every day and the price is very affordable.",
        "Perfect in every way. Reliable, simple to use, and arrived in great condition.",
        "Really good quality. Does exactly what it says and feels sturdy. Impressed.",
        "Incredible purchase. Fast dispatch, excellent packaging, and the product is wonderful.",
        "Smooth experience from ordering to delivery. The {product} itself is outstanding.",
        "Simple, effective and well-priced. This {product} exceeded my expectations entirely.",
    ],
    "negative": [
        "Terrible quality. Broke after two days of use. Complete waste of money.",
        "Very disappointed. The {product} arrived damaged and customer service was unhelpful.",
        "Awful experience. Slow shipping, wrong item delivered, and nobody responded to my complaint.",
        "Poor build quality. Feels very cheap and flimsy. Definitely overpriced for what it is.",
        "Do not buy this. Faulty from the start and impossible to return. Total scam.",
        "Horrible product. Doesn't work as advertised. Very frustrated with this purchase.",
        "Worst purchase I've made this year. Defective, noisy and uncomfortable to use.",
        "Cheap and nasty. Fell apart within a week. Save your money and buy elsewhere.",
        "Regret buying this. The quality is bad and the smell is disgusting. Very unhappy.",
        "Useless {product}. Stopped working after one use. Angry and disappointed.",
        "Late delivery, wrong colour, and the product is completely inferior to the photos shown.",
        "Not worth it at all. Faulty right out of the box and returning it was a nightmare.",
    ],
    "neutral": [
        "It's okay. Does the job but nothing special. Delivery was on time.",
        "Average product. Not bad, not great. Exactly what you'd expect at this price.",
        "Works fine so far. A bit difficult to set up initially but manageable.",
        "Decent enough. Not as impressive as the photos but functional. We'll see how it lasts.",
        "Neither great nor terrible. Standard quality. Arrived on time with no issues.",
        "Fairly average. Does what it's supposed to but I've seen better at a similar price.",
        "It's alright. No complaints, no praise. Just an ordinary {product}.",
        "Reasonable value. Nothing outstanding but it gets the job done without any fuss.",
        "Got what I expected. Not amazing, not disappointing. Just a solid, average buy.",
        "Mid-range quality. Acceptable but won't blow your mind. Delivery was prompt.",
    ],
}

PRODUCTS = {
    "Electronics":   ["wireless headphones", "bluetooth speaker", "laptop stand",
                      "USB hub", "phone charger", "webcam"],
    "Clothing":      ["running shoes", "waterproof jacket", "gym leggings",
                      "cotton t-shirt", "wool jumper"],
    "Home & Garden": ["air purifier", "coffee maker", "robot vacuum",
                      "kitchen knife set", "plant pot"],
    "Books":         ["notebook", "planner", "desk organiser", "reading lamp"],
    "Sports":        ["yoga mat", "resistance bands", "water bottle",
                      "cycling helmet", "jump rope"],
}


def make_corpus(n: int = 900) -> pd.DataFrame:
    rows = []
    categories = list(PRODUCTS.keys())
    sentiments = ["positive", "negative", "neutral"]
    # Realistic imbalance: more positive reviews on e-commerce platforms
    weights    = [0.52, 0.28, 0.20]

    for i in range(n):
        sentiment = random.choices(sentiments, weights=weights)[0]
        category  = random.choice(categories)
        product   = random.choice(PRODUCTS[category])
        template  = random.choice(REVIEW_TEMPLATES[sentiment])
        text      = template.replace("{product}", product)

        # Star rating correlates with sentiment but has natural noise
        if sentiment == "positive":
            stars = random.choices([3, 4, 5], weights=[0.05, 0.25, 0.70])[0]
        elif sentiment == "negative":
            stars = random.choices([1, 2, 3], weights=[0.60, 0.30, 0.10])[0]
        else:
            stars = random.choices([2, 3, 4], weights=[0.15, 0.65, 0.20])[0]

        rows.append({
            "review_id":         i + 1,
            "category":          category,
            "product":           product,
            "review_text":       text,
            "star_rating":       stars,
            "true_sentiment":    sentiment,   # ground truth for evaluation
        })

    return pd.DataFrame(rows)


# ── Text preprocessing ────────────────────────────────────────────────────────

def preprocess(text: str) -> list[str]:
    """Lowercase, strip punctuation, return token list."""
    text = text.lower()
    text = re.sub(r"[^a-z\s']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text.split()


# ── Scoring ───────────────────────────────────────────────────────────────────

def score_review(text: str) -> tuple[float, str]:
    """
    Lexicon-based sentiment score with negation & intensifier handling.
    Returns (compound_score, label).
    """
    tokens = preprocess(text)
    score = 0.0
    negated = False
    intensify = 1.0

    for i, token in enumerate(tokens):
        if token in NEGATION_WORDS:
            negated = True
            continue
        if token in INTENSIFIERS:
            intensify = 1.5
            continue

        word_score = 0.0
        if token in POSITIVE_WORDS:
            word_score = +1.0 * intensify
        elif token in NEGATIVE_WORDS:
            word_score = -1.0 * intensify

        if negated and word_score != 0.0:
            word_score = -word_score * 0.75   # flip and dampen (negation softens)

        score += word_score
        negated  = False
        intensify = 1.0

    # Normalise to [-1, 1]
    word_count = max(len(tokens), 1)
    norm_score = math.tanh(score / math.sqrt(word_count))

    if norm_score > 0.10:
        label = "positive"
    elif norm_score < -0.10:
        label = "negative"
    else:
        label = "neutral"

    return round(norm_score, 4), label


# ── Evaluation ────────────────────────────────────────────────────────────────

def evaluate(df: pd.DataFrame) -> dict:
    correct = (df["predicted"] == df["true_sentiment"]).sum()
    total   = len(df)
    acc     = correct / total

    print(f"  Accuracy : {acc*100:.1f}%  ({correct}/{total} correct)")

    # Per-class stats
    classes = ["positive", "negative", "neutral"]
    print(f"\n  {'Class':<12} {'Precision':>10} {'Recall':>10} {'F1':>8}")
    print(f"  {'─'*42}")
    results = {}
    for cls in classes:
        tp = ((df["predicted"] == cls) & (df["true_sentiment"] == cls)).sum()
        fp = ((df["predicted"] == cls) & (df["true_sentiment"] != cls)).sum()
        fn = ((df["predicted"] != cls) & (df["true_sentiment"] == cls)).sum()
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1        = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        print(f"  {cls:<12} {precision*100:>9.1f}% {recall*100:>9.1f}% {f1*100:>7.1f}%")
        results[cls] = {"precision": precision, "recall": recall, "f1": f1}
    print()
    return results


# ── Visualisations ────────────────────────────────────────────────────────────

SENT_COLORS = {"positive": "#059669", "negative": "#dc2626", "neutral": "#94a3b8"}

def plot_all(df: pd.DataFrame, out_dir: str) -> str:
    plt.rcParams.update({
        "font.family":       "DejaVu Sans",
        "axes.spines.top":   False,
        "axes.spines.right": False,
        "axes.grid":         True,
        "grid.alpha":        0.25,
        "figure.facecolor":  "#f8f9fa",
        "axes.facecolor":    "#f8f9fa",
    })

    fig = plt.figure(figsize=(18, 13), facecolor="#f8f9fa")
    fig.suptitle(
        "Sentiment Analysis — Amazon-Style Product Reviews",
        fontsize=18, fontweight="bold", y=0.98, color="#1e293b"
    )
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.50, wspace=0.35)

    # ── 1. Overall sentiment distribution (pie) ───────────────────────────────
    ax1 = fig.add_subplot(gs[0, 0])
    counts = df["predicted"].value_counts()
    colors = [SENT_COLORS[c] for c in counts.index]
    wedges, texts, autotexts = ax1.pie(
        counts.values, labels=counts.index,
        colors=colors, autopct="%1.1f%%",
        startangle=140, pctdistance=0.82,
        wedgeprops={"edgecolor": "white", "linewidth": 2}
    )
    for at in autotexts:
        at.set_fontsize(9)
    ax1.set_title("Overall Sentiment\nDistribution", fontweight="bold")

    # ── 2. Score distribution by sentiment ───────────────────────────────────
    ax2 = fig.add_subplot(gs[0, 1:])
    for sent in ["positive", "neutral", "negative"]:
        sub = df[df["predicted"] == sent]["score"]
        ax2.hist(sub, bins=30, alpha=0.65, label=sent.capitalize(),
                 color=SENT_COLORS[sent], edgecolor="white", linewidth=0.3)
    ax2.axvline(0, color="#1e293b", lw=1.2, ls="--", alpha=0.7)
    ax2.set_title("Sentiment Score Distribution by Class", fontweight="bold")
    ax2.set_xlabel("Compound Score")
    ax2.set_ylabel("Number of Reviews")
    ax2.legend(framealpha=0)

    # ── 3. Sentiment by category (stacked bar) ───────────────────────────────
    ax3 = fig.add_subplot(gs[1, :2])
    cross = df.groupby(["category", "predicted"]).size().unstack(fill_value=0)
    for col in ["positive", "neutral", "negative"]:
        if col not in cross:
            cross[col] = 0
    cross = cross[["positive", "neutral", "negative"]]
    cross_pct = cross.div(cross.sum(axis=1), axis=0) * 100

    bottom = np.zeros(len(cross_pct))
    cats = cross_pct.index.tolist()
    for sent in ["positive", "neutral", "negative"]:
        vals = cross_pct[sent].values
        bars = ax3.bar(cats, vals, bottom=bottom,
                       color=SENT_COLORS[sent], label=sent.capitalize(),
                       alpha=0.85, edgecolor="white", linewidth=0.4)
        # Label slices > 8%
        for rect, val, bot in zip(bars, vals, bottom):
            if val > 8:
                ax3.text(rect.get_x() + rect.get_width() / 2,
                         bot + val / 2, f"{val:.0f}%",
                         ha="center", va="center", fontsize=8, color="white", fontweight="bold")
        bottom += vals

    ax3.set_title("Sentiment Mix by Product Category (%)", fontweight="bold")
    ax3.set_ylabel("Percentage of Reviews")
    ax3.set_ylim(0, 102)
    ax3.set_xticklabels(cats, rotation=15, ha="right")
    ax3.legend(framealpha=0, loc="upper right")

    # ── 4. Sentiment vs. star rating heatmap ─────────────────────────────────
    ax4 = fig.add_subplot(gs[1, 2])
    cross2 = df.groupby(["star_rating", "predicted"]).size().unstack(fill_value=0)
    for col in ["positive", "neutral", "negative"]:
        if col not in cross2:
            cross2[col] = 0
    cross2 = cross2[["positive", "neutral", "negative"]]
    import seaborn as sns
    sns.heatmap(cross2, ax=ax4, cmap="YlGn", annot=True, fmt="d",
                linewidths=0.5, cbar_kws={"shrink": 0.8}, annot_kws={"size": 9})
    ax4.set_title("Star Rating vs\nPredicted Sentiment", fontweight="bold")
    ax4.set_ylabel("Star Rating")
    ax4.set_xlabel("")

    # ── 5. Average sentiment score by product category ────────────────────────
    ax5 = fig.add_subplot(gs[2, 0])
    avg_score = df.groupby("category")["score"].mean().sort_values(ascending=True)
    bar_colors = [SENT_COLORS["positive"] if v > 0.1 else
                  (SENT_COLORS["negative"] if v < -0.1 else SENT_COLORS["neutral"])
                  for v in avg_score.values]
    ax5.barh(avg_score.index, avg_score.values, color=bar_colors, alpha=0.85, edgecolor="white")
    ax5.axvline(0, color="#1e293b", lw=1.0, ls="--")
    ax5.set_title("Avg Sentiment Score\nby Category", fontweight="bold")
    ax5.set_xlabel("Mean Compound Score")

    # ── 6. Confusion matrix: true vs predicted ────────────────────────────────
    ax6 = fig.add_subplot(gs[2, 1])
    labels = ["positive", "neutral", "negative"]
    matrix = np.zeros((3, 3), dtype=int)
    for i, true in enumerate(labels):
        for j, pred in enumerate(labels):
            matrix[i, j] = ((df["true_sentiment"] == true) & (df["predicted"] == pred)).sum()

    sns.heatmap(matrix, ax=ax6,
                xticklabels=["Pred +", "Pred 0", "Pred −"],
                yticklabels=["True +", "True 0", "True −"],
                annot=True, fmt="d", cmap="Blues",
                linewidths=0.5, cbar_kws={"shrink": 0.8}, annot_kws={"size": 10})
    ax6.set_title("Confusion Matrix\n(True vs Predicted)", fontweight="bold")

    # ── 7. Top positive & negative words ─────────────────────────────────────
    ax7 = fig.add_subplot(gs[2, 2])
    pos_tokens = []
    neg_tokens = []
    for _, row in df.iterrows():
        tokens = preprocess(row["review_text"])
        if row["predicted"] == "positive":
            pos_tokens.extend([t for t in tokens if t in POSITIVE_WORDS])
        elif row["predicted"] == "negative":
            neg_tokens.extend([t for t in tokens if t in NEGATIVE_WORDS])

    top_pos = Counter(pos_tokens).most_common(5)
    top_neg = Counter(neg_tokens).most_common(5)

    words  = [w for w, _ in top_pos] + [w for w, _ in top_neg]
    counts = [c for _, c in top_pos] + [-c for _, c in top_neg]
    bcolors = [SENT_COLORS["positive"]] * 5 + [SENT_COLORS["negative"]] * 5

    y = range(len(words))
    ax7.barh(y, counts, color=bcolors, alpha=0.85, edgecolor="white")
    ax7.set_yticks(y)
    ax7.set_yticklabels(words, fontsize=8)
    ax7.axvline(0, color="#1e293b", lw=1.0)
    ax7.set_title("Top Sentiment Words\n(+ positive / − negative)", fontweight="bold")
    ax7.set_xlabel("Frequency")

    out_path = f"{out_dir}/sentiment_dashboard.png"
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#f8f9fa")
    plt.close()
    print(f"  Plot saved → {out_path}")
    return out_path


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    print("=" * 55)
    print("               Sentiment Analysis                 ")
    print("  Dataset: Amazon-style product reviews (900 rows)")
    print("=" * 55)

    print("\n[1] Building review corpus…")
    df = make_corpus(900)
    print(f"  Shape: {df.shape}")
    print(f"  True sentiment distribution:\n{df['true_sentiment'].value_counts().to_string()}\n")

    print("[2] Running lexicon-based sentiment scoring…")
    scores, labels = zip(*df["review_text"].map(score_review))
    df["score"]     = scores
    df["predicted"] = labels
    print(f"  Predicted distribution:\n{df['predicted'].value_counts().to_string()}\n")

    print("[3] Evaluating against ground truth…\n")
    evaluate(df)

    print("[4] Sample predictions:")
    sample = df.sample(5, random_state=1)[["review_text", "true_sentiment", "predicted", "score"]]
    for _, row in sample.iterrows():
        match = "✓" if row["true_sentiment"] == row["predicted"] else "✗"
        print(f"  {match} [{row['predicted']:8s}|{row['score']:+.3f}]  {row['review_text'][:70]}")

    print("\n[5] Generating visualisation dashboard…")
    plot_all(df, "output_plots")

    csv_path = "reviews_scored.csv"
    df.to_csv(csv_path, index=False)
    print(f"  Scored dataset saved → {csv_path}")

    print("\n[✓] Task 4 complete.\n")


if __name__ == "__main__":
    main()
