#!/usr/bin/env bash
# scripts/manage.sh — convenience wrapper for common Docker operations.
# Usage: ./scripts/manage.sh <command>

set -euo pipefail

IMAGE="codealpha-webserver"
CONTAINER="codealpha-webserver"
PORT=8080

case "${1:-help}" in

  build)
    echo "Building Docker image: $IMAGE"
    docker build -t "$IMAGE" .
    ;;

  run)
    echo "Starting container on http://localhost:$PORT"
    docker run -d \
      --name "$CONTAINER" \
      --restart unless-stopped \
      -p "$PORT:80" \
      "$IMAGE"
    echo "Container started. Open http://localhost:$PORT"
    ;;

  stop)
    echo "Stopping container: $CONTAINER"
    docker stop "$CONTAINER" && docker rm "$CONTAINER"
    ;;

  logs)
    docker logs -f "$CONTAINER"
    ;;

  health)
    echo "Checking container health..."
    STATUS=$(docker inspect --format='{{.State.Health.Status}}' "$CONTAINER" 2>/dev/null || echo "not running")
    echo "  Container health: $STATUS"
    curl -s http://localhost:$PORT/health && echo ""
    ;;

  shell)
    echo "Opening shell in running container..."
    docker exec -it "$CONTAINER" /bin/sh
    ;;

  stats)
    echo "Live container stats (Ctrl-C to exit):"
    docker stats "$CONTAINER"
    ;;

  compose-up)
    docker compose up --build -d
    echo "Stack running. Open http://localhost:$PORT"
    ;;

  compose-down)
    docker compose down
    ;;

  clean)
    echo "Removing stopped containers, dangling images, and unused networks..."
    docker system prune -f
    ;;

  help|*)
    echo ""
    echo "Usage: ./scripts/manage.sh <command>"
    echo ""
    echo "Commands:"
    echo "  build        Build the Docker image"
    echo "  run          Start the container (detached)"
    echo "  stop         Stop and remove the container"
    echo "  logs         Follow container logs"
    echo "  health       Check container health status"
    echo "  shell        Open a shell inside the container"
    echo "  stats        Show live resource usage"
    echo "  compose-up   Start full stack with Docker Compose"
    echo "  compose-down Stop the Compose stack"
    echo "  clean        Prune unused Docker resources"
    echo ""
    ;;
esac
