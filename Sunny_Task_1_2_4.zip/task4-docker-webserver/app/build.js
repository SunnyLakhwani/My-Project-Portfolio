/**
 * build.js — minimal asset builder.
 *
 * In a real project this would call Vite / Webpack / esbuild.
 * Here we just copy src/ → dist/ so the Dockerfile build stage works
 * without pulling in a full bundler as a dependency.
 */
const fs   = require('fs');
const path = require('path');

const SRC  = path.join(__dirname, 'src');
const DIST = path.join(__dirname, 'dist');

function copyDir(src, dest) {
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
        const srcPath  = path.join(src,  entry.name);
        const destPath = path.join(dest, entry.name);
        if (entry.isDirectory()) {
            copyDir(srcPath, destPath);
        } else {
            fs.copyFileSync(srcPath, destPath);
            console.log(`  copied: ${entry.name}`);
        }
    }
}

console.log('Building CodeAlpha web server assets...');
copyDir(SRC, DIST);
console.log(`Build complete → ${DIST}`);
