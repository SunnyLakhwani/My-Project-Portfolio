/**
 * app.js — minimal frontend script for the CodeAlpha Docker web server.
 *
 * Single responsibility: call the /health endpoint and display the result.
 * Kept as vanilla JS (no framework) since the page is purely static.
 */

async function checkHealth() {
    const btn    = document.getElementById('healthBtn');
    const result = document.getElementById('healthResult');

    btn.disabled    = true;
    btn.textContent = 'Checking…';
    result.className = 'health-result hidden';

    try {
        const start = Date.now();
        const res   = await fetch('/health');
        const ms    = Date.now() - start;
        const body  = await res.text();

        result.textContent = `HTTP ${res.status} — "${body.trim()}" (${ms} ms)`;
        result.className   = res.ok ? 'health-result ok' : 'health-result error';
    } catch (err) {
        // fetch() rejects on network errors (e.g. running the HTML locally
        // without the container) — show a helpful message instead of crashing.
        result.textContent = `Could not reach /health — are you running inside Docker? (${err.message})`;
        result.className   = 'health-result error';
    } finally {
        btn.disabled    = false;
        btn.textContent = 'Check /health';
    }
}
