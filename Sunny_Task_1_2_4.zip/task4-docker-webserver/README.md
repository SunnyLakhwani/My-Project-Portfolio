# CodeAlpha Docker Web Server — Task 4

![Docker CI/CD](https://github.com/YOUR_USERNAME/CodeAlpha_DockerWebServer/actions/workflows/docker-ci.yml/badge.svg)
![Nginx](https://img.shields.io/badge/Nginx-1.27-green)
![Docker](https://img.shields.io/badge/Docker-multi--stage-blue)

A hardened, production-ready Nginx web server running inside Docker.  
Built with a **multi-stage Dockerfile**, non-root execution, gzip compression, Docker health checks, and an automated CI/CD pipeline that builds and pushes to GitHub Container Registry.

---

## Quick Start

```bash
# clone
git clone https://github.com/YOUR_USERNAME/CodeAlpha_DockerWebServer.git
cd CodeAlpha_DockerWebServer

# build & run with the helper script
chmod +x scripts/manage.sh
./scripts/manage.sh build
./scripts/manage.sh run

# or use Docker Compose
docker compose up --build -d

# open in browser
open http://localhost:8080

# check container health
./scripts/manage.sh health
```

---

## Project Structure

```
├── Dockerfile                  ← multi-stage build (builder → runtime)
├── docker-compose.yml          ← local orchestration
├── .dockerignore               ← keeps context lean
├── nginx/
│   └── nginx.conf              ← custom Nginx config
├── app/
│   ├── package.json
│   ├── build.js                ← asset build script
│   └── src/
│       ├── index.html          ← web page
│       ├── style.css
│       └── app.js
├── scripts/
│   └── manage.sh               ← Docker helper commands
└── .github/workflows/
    └── docker-ci.yml           ← CI/CD pipeline
```

---

## Docker Concepts Covered

| Concept | Where |
|---------|-------|
| Multi-stage builds | `Dockerfile` — builder + runtime stages |
| Non-root execution | `Dockerfile` — `adduser appuser` + `USER appuser` |
| Health checks | `Dockerfile` `HEALTHCHECK` + `/health` endpoint |
| Image layering & cache | `COPY package.json` before source for cache efficiency |
| `.dockerignore` | Excludes `node_modules`, `.git`, env files |
| Docker Compose | `docker-compose.yml` with restart policies and logging |
| Container lifecycle | `manage.sh` — build, run, stop, logs, stats, shell |
| Registry push | GitHub Actions pushes to GHCR on every `main` merge |

---

## CI/CD Pipeline

Every push to `main` triggers three steps:

1. **Lint** — Hadolint checks the Dockerfile for best-practice violations.
2. **Build & Push** — Buildx builds the image with layer caching; pushes to GHCR with `latest` and `sha-<commit>` tags.
3. **Smoke test** — starts the container and calls `curl http://localhost:8080/health` to confirm it's serving traffic.

---

## Helper Script

```bash
./scripts/manage.sh <command>

  build        Build the Docker image
  run          Start the container (detached, port 8080)
  stop         Stop and remove the container
  logs         Follow container logs
  health       Check Docker health status + /health endpoint
  shell        Open a shell inside the running container
  stats        Live CPU/memory usage
  compose-up   Start the full Compose stack
  compose-down Tear down the Compose stack
  clean        Prune unused Docker resources
```

---

## Security Features

- Runs as **non-root user** (`appuser`) — limits blast radius if compromised.
- `server_tokens off` — hides Nginx version from error responses.
- Security headers: `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`.
- Aggressive static-asset caching (`Cache-Control: public, immutable, 1 year`).
- `.dockerignore` ensures secrets (`.env` files) never enter the image.
