package com.codealpha.taskmanager;

import com.codealpha.taskmanager.model.Task;
import com.codealpha.taskmanager.repository.TaskRepository;
import com.codealpha.taskmanager.service.TaskService;
import org.junit.jupiter.api.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.*;

/**
 * Unit tests for TaskService — all tests run in-memory, no I/O involved.
 * Test method names follow the pattern: methodName_scenario_expectedOutcome
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService(new TaskRepository());
    }

    // ── create ────────────────────────────────────────────────────────────

    @Test @Order(1)
    void createTask_validInput_taskPersistedWithTodoStatus() {
        Task task = service.createTask("Deploy app", "Push to prod",
                Task.Priority.HIGH, "Alice");

        assertThat(task).isNotNull();
        assertThat(task.getId()).isNotBlank();
        assertThat(task.getTitle()).isEqualTo("Deploy app");
        assertThat(task.getStatus()).isEqualTo(Task.Status.TODO);
        assertThat(task.getPriority()).isEqualTo(Task.Priority.HIGH);
    }

    @Test @Order(2)
    void createTask_blankTitle_throwsIllegalArgument() {
        assertThatThrownBy(() ->
                service.createTask("", "desc", Task.Priority.LOW, "Bob"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("title");
    }

    @Test @Order(3)
    void createTask_blankAssignee_throwsIllegalArgument() {
        assertThatThrownBy(() ->
                service.createTask("Title", "desc", Task.Priority.LOW, "  "))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Assignee");
    }

    // ── update ────────────────────────────────────────────────────────────

    @Test @Order(4)
    void updateStatus_existingTask_statusChanges() {
        Task task = service.createTask("Write tests", "", Task.Priority.MEDIUM, "Bob");
        service.updateStatus(task.getId(), Task.Status.IN_PROGRESS);

        assertThat(service.getById(task.getId()))
                .isPresent()
                .get()
                .extracting(Task::getStatus)
                .isEqualTo(Task.Status.IN_PROGRESS);
    }

    @Test @Order(5)
    void updateStatus_unknownId_throwsIllegalArgument() {
        assertThatThrownBy(() -> service.updateStatus("NOPE", Task.Status.DONE))
                .isInstanceOf(IllegalArgumentException.class);
    }

    // ── filtering ─────────────────────────────────────────────────────────

    @Test @Order(6)
    void getByAssignee_multipleOwners_returnsCorrectSubset() {
        service.createTask("Task A", "", Task.Priority.LOW, "Alice");
        service.createTask("Task B", "", Task.Priority.LOW, "Bob");
        service.createTask("Task C", "", Task.Priority.LOW, "Alice");

        List<Task> aliceTasks = service.getByAssignee("Alice");
        assertThat(aliceTasks).hasSize(2);
        assertThat(aliceTasks).allMatch(t -> "Alice".equals(t.getAssignee()));
    }

    @Test @Order(7)
    void getByStatus_afterUpdates_onlyMatchingReturned() {
        Task t1 = service.createTask("T1", "", Task.Priority.HIGH, "Dev");
        Task t2 = service.createTask("T2", "", Task.Priority.LOW,  "Dev");
        service.updateStatus(t1.getId(), Task.Status.DONE);

        assertThat(service.getByStatus(Task.Status.DONE)).containsExactly(t1);
        assertThat(service.getByStatus(Task.Status.TODO)).containsExactly(t2);
    }

    // ── analytics ─────────────────────────────────────────────────────────

    @Test @Order(8)
    void getStatusSummary_mixedStatuses_correctCounts() {
        service.createTask("A", "", Task.Priority.HIGH, "Dev");
        Task b = service.createTask("B", "", Task.Priority.LOW, "Dev");
        service.updateStatus(b.getId(), Task.Status.DONE);

        Map<Task.Status, Long> summary = service.getStatusSummary();
        assertThat(summary.get(Task.Status.TODO)).isEqualTo(1L);
        assertThat(summary.get(Task.Status.DONE)).isEqualTo(1L);
    }

    @Test @Order(9)
    void getOverdueTasks_pastDueDate_appearsInList() {
        Task task = service.createTask("Overdue task", "", Task.Priority.CRITICAL, "Alice");
        service.setDueDate(task.getId(), LocalDateTime.now().minusHours(1));

        assertThat(service.getOverdueTasks()).containsExactly(task);
    }

    @Test @Order(10)
    void getOverdueTasks_completedTaskWithPastDue_notIncluded() {
        Task task = service.createTask("Old done task", "", Task.Priority.LOW, "Bob");
        service.setDueDate(task.getId(), LocalDateTime.now().minusDays(3));
        service.updateStatus(task.getId(), Task.Status.DONE);

        assertThat(service.getOverdueTasks()).isEmpty();
    }

    // ── delete ────────────────────────────────────────────────────────────

    @Test @Order(11)
    void deleteTask_existingTask_removedSuccessfully() {
        Task task = service.createTask("To delete", "", Task.Priority.LOW, "Dev");
        boolean result = service.deleteTask(task.getId());

        assertThat(result).isTrue();
        assertThat(service.getById(task.getId())).isEmpty();
    }

    @Test @Order(12)
    void deleteTask_nonExistentId_returnsFalse() {
        assertThat(service.deleteTask("GHOST")).isFalse();
    }
}
