package com.codealpha.taskmanager.service;

import com.codealpha.taskmanager.model.Task;
import com.codealpha.taskmanager.repository.TaskRepository;
import com.codealpha.taskmanager.util.TaskValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Central service layer — all business logic lives here.
 * Controllers / the CLI talk to this class; they never touch the repo directly.
 */
public class TaskService {

    private static final Logger log = LoggerFactory.getLogger(TaskService.class);

    private final TaskRepository repo;

    public TaskService(TaskRepository repo) {
        this.repo = repo;
    }

    // ── create ────────────────────────────────────────────────────────────

    public Task createTask(String title, String description,
                           Task.Priority priority, String assignee) {
        TaskValidator.validateTitle(title);
        TaskValidator.validateAssignee(assignee);

        Task task = new Task(title, description, priority, assignee);
        repo.save(task);
        log.info("Created task [{}] '{}' assigned to {}", task.getId(), title, assignee);
        return task;
    }

    // ── read ──────────────────────────────────────────────────────────────

    public Optional<Task> getById(String id) {
        return repo.findById(id);
    }

    public List<Task> getAllTasks() {
        return repo.findAll();
    }

    public List<Task> getByStatus(Task.Status status) {
        return repo.findByStatus(status);
    }

    public List<Task> getByPriority(Task.Priority priority) {
        return repo.findByPriority(priority);
    }

    public List<Task> getByAssignee(String assignee) {
        return repo.findByAssignee(assignee);
    }

    // ── update ────────────────────────────────────────────────────────────

    public Task updateStatus(String id, Task.Status newStatus) {
        Task task = findOrThrow(id);
        Task.Status old = task.getStatus();
        task.setStatus(newStatus);
        repo.save(task);
        log.info("Task [{}] status changed: {} → {}", id, old, newStatus);
        return task;
    }

    public Task updatePriority(String id, Task.Priority newPriority) {
        Task task = findOrThrow(id);
        task.setPriority(newPriority);
        repo.save(task);
        log.info("Task [{}] priority updated to {}", id, newPriority);
        return task;
    }

    public Task setDueDate(String id, LocalDateTime dueDate) {
        Task task = findOrThrow(id);
        task.setDueDate(dueDate);
        repo.save(task);
        log.info("Task [{}] due-date set to {}", id, dueDate);
        return task;
    }

    // ── delete ────────────────────────────────────────────────────────────

    public boolean deleteTask(String id) {
        boolean removed = repo.delete(id);
        if (removed) log.info("Deleted task [{}]", id);
        else         log.warn("Tried to delete non-existent task [{}]", id);
        return removed;
    }

    // ── analytics ─────────────────────────────────────────────────────────

    /**
     * Returns a breakdown of task counts grouped by status.
     * Useful for a quick project health snapshot.
     */
    public Map<Task.Status, Long> getStatusSummary() {
        return repo.findAll().stream()
                .collect(Collectors.groupingBy(Task::getStatus, Collectors.counting()));
    }

    /**
     * Returns tasks that are overdue (due date in the past and not yet done/cancelled).
     */
    public List<Task> getOverdueTasks() {
        LocalDateTime now = LocalDateTime.now();
        return repo.findAll().stream()
                .filter(t -> t.getDueDate() != null)
                .filter(t -> t.getDueDate().isBefore(now))
                .filter(t -> t.getStatus() != Task.Status.DONE
                          && t.getStatus() != Task.Status.CANCELLED)
                .collect(Collectors.toList());
    }

    // ── helper ────────────────────────────────────────────────────────────

    private Task findOrThrow(String id) {
        return repo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "No task found with id: " + id));
    }
}
