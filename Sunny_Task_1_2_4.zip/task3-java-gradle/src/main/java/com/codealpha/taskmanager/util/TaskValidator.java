package com.codealpha.taskmanager.util;

/**
 * Lightweight validation helpers.
 * Throwing IllegalArgumentException keeps things simple —
 * no custom exception hierarchy needed for a project this size.
 */
public final class TaskValidator {

    private TaskValidator() { /* utility class */ }

    public static void validateTitle(String title) {
        if (title == null || title.isBlank()) {
            throw new IllegalArgumentException("Task title must not be blank.");
        }
        if (title.length() > 120) {
            throw new IllegalArgumentException(
                "Task title exceeds 120 characters (got " + title.length() + ").");
        }
    }

    public static void validateAssignee(String assignee) {
        if (assignee == null || assignee.isBlank()) {
            throw new IllegalArgumentException("Assignee name must not be blank.");
        }
    }
}
