package com.codealpha.taskmanager.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Represents a single task in the manager.
 * Immutable fields (id, createdAt) are set once at construction time;
 * mutable fields can be updated through the service layer.
 */
public class Task {

    public enum Priority { LOW, MEDIUM, HIGH, CRITICAL }
    public enum Status   { TODO, IN_PROGRESS, DONE, CANCELLED }

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    // ── identity ──────────────────────────────────────────────────────────
    private final String        id;
    private final LocalDateTime createdAt;

    // ── mutable state ─────────────────────────────────────────────────────
    private String        title;
    private String        description;
    private Priority      priority;
    private Status        status;
    private LocalDateTime dueDate;
    private String        assignee;

    public Task(String title, String description, Priority priority, String assignee) {
        this.id          = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.createdAt   = LocalDateTime.now();
        this.title       = title;
        this.description = description;
        this.priority    = priority;
        this.status      = Status.TODO;
        this.assignee    = assignee;
        this.dueDate     = null;
    }

    // ── getters ───────────────────────────────────────────────────────────
    public String        getId()          { return id; }
    public LocalDateTime getCreatedAt()   { return createdAt; }
    public String        getTitle()       { return title; }
    public String        getDescription() { return description; }
    public Priority      getPriority()    { return priority; }
    public Status        getStatus()      { return status; }
    public LocalDateTime getDueDate()     { return dueDate; }
    public String        getAssignee()    { return assignee; }

    // ── setters ───────────────────────────────────────────────────────────
    public void setTitle(String title)             { this.title = title; }
    public void setDescription(String description) { this.description = description; }
    public void setPriority(Priority priority)     { this.priority = priority; }
    public void setStatus(Status status)           { this.status = status; }
    public void setDueDate(LocalDateTime dueDate)  { this.dueDate = dueDate; }
    public void setAssignee(String assignee)       { this.assignee = assignee; }

    /** Human-readable summary for CLI output. */
    @Override
    public String toString() {
        String due = (dueDate != null) ? dueDate.format(FMT) : "none";
        return String.format(
            "[%s] %-30s | %-8s | %-11s | due: %-16s | assignee: %s",
            id, title, priority, status, due, assignee
        );
    }
}
