package com.codealpha.taskmanager;

import com.codealpha.taskmanager.model.Task;
import com.codealpha.taskmanager.repository.TaskRepository;
import com.codealpha.taskmanager.service.TaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Entry point — demonstrates the full task-manager lifecycle:
 *   create → read → update → filter → analytics → delete
 *
 * In a real product this would be wired to a REST controller or a proper CLI
 * framework (Picocli), but for this internship task a plain main() makes the
 * logic easy to follow and run.
 */
public class Main {

    private static final Logger log = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args) {

        log.info("=== CodeAlpha Task Manager starting up ===");

        // wire up the application
        TaskRepository repo    = new TaskRepository();
        TaskService    service = new TaskService(repo);

        // ── 1. create a handful of tasks ─────────────────────────────────
        Task t1 = service.createTask(
                "Set up CI/CD pipeline",
                "Configure GitHub Actions for automatic builds and deployments.",
                Task.Priority.HIGH, "Alice");

        Task t2 = service.createTask(
                "Write unit tests for service layer",
                "Achieve at least 80% line coverage using JUnit 5.",
                Task.Priority.MEDIUM, "Bob");

        Task t3 = service.createTask(
                "Dockerise the application",
                "Create a multi-stage Dockerfile; publish image to GHCR.",
                Task.Priority.HIGH, "Alice");

        Task t4 = service.createTask(
                "Update project README",
                "Add badge for build status and document Gradle tasks.",
                Task.Priority.LOW, "Charlie");

        Task t5 = service.createTask(
                "Fix login timeout bug",
                "Sessions expire too quickly on mobile browsers.",
                Task.Priority.CRITICAL, "Bob");

        // ── 2. set a past due-date on t1 so it shows up as overdue ───────
        service.setDueDate(t1.getId(), LocalDateTime.now().minusDays(1));

        // ── 3. move some tasks forward ────────────────────────────────────
        service.updateStatus(t1.getId(), Task.Status.IN_PROGRESS);
        service.updateStatus(t2.getId(), Task.Status.DONE);
        service.updateStatus(t5.getId(), Task.Status.IN_PROGRESS);

        // ── 4. print all tasks ────────────────────────────────────────────
        separator("ALL TASKS");
        service.getAllTasks().forEach(t -> System.out.println("  " + t));

        // ── 5. filter by assignee ─────────────────────────────────────────
        separator("ALICE'S TASKS");
        service.getByAssignee("Alice").forEach(t -> System.out.println("  " + t));

        // ── 6. filter by priority ─────────────────────────────────────────
        separator("HIGH / CRITICAL TASKS");
        service.getByPriority(Task.Priority.HIGH)
               .forEach(t -> System.out.println("  " + t));
        service.getByPriority(Task.Priority.CRITICAL)
               .forEach(t -> System.out.println("  " + t));

        // ── 7. status summary ─────────────────────────────────────────────
        separator("STATUS SUMMARY");
        Map<Task.Status, Long> summary = service.getStatusSummary();
        summary.forEach((status, count) ->
                System.out.printf("  %-12s : %d%n", status, count));

        // ── 8. overdue tasks ──────────────────────────────────────────────
        separator("OVERDUE TASKS");
        List<Task> overdue = service.getOverdueTasks();
        if (overdue.isEmpty()) {
            System.out.println("  No overdue tasks — nice!");
        } else {
            overdue.forEach(t -> System.out.println("  " + t));
        }

        // ── 9. delete a completed task ────────────────────────────────────
        separator("CLEANUP");
        boolean deleted = service.deleteTask(t2.getId());
        System.out.printf("  Deleted task [%s]: %s%n", t2.getId(), deleted);
        System.out.printf("  Tasks remaining: %d%n", repo.count());

        log.info("=== Task Manager demo complete ===");
    }

    private static void separator(String label) {
        System.out.println("\n──── " + label + " " + "─".repeat(50 - label.length()));
    }
}
