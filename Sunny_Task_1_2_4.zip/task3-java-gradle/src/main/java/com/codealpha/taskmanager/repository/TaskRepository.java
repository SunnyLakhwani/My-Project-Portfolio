package com.codealpha.taskmanager.repository;

import com.codealpha.taskmanager.model.Task;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Simple in-memory store for tasks.
 *
 * Using ConcurrentHashMap so the repository is thread-safe by default —
 * handy if we ever add a REST layer later.
 */
public class TaskRepository {

    private final Map<String, Task> store = new ConcurrentHashMap<>();

    /** Persist a new task (or overwrite an existing one with the same id). */
    public Task save(Task task) {
        store.put(task.getId(), task);
        return task;
    }

    /** Look up a task by its short id. Returns empty if not found. */
    public Optional<Task> findById(String id) {
        return Optional.ofNullable(store.get(id));
    }

    /** All tasks, ordered by creation time (oldest first). */
    public List<Task> findAll() {
        return store.values().stream()
                .sorted(Comparator.comparing(Task::getCreatedAt))
                .collect(Collectors.toList());
    }

    /** Tasks filtered by status. */
    public List<Task> findByStatus(Task.Status status) {
        return findAll().stream()
                .filter(t -> t.getStatus() == status)
                .collect(Collectors.toList());
    }

    /** Tasks filtered by priority. */
    public List<Task> findByPriority(Task.Priority priority) {
        return findAll().stream()
                .filter(t -> t.getPriority() == priority)
                .collect(Collectors.toList());
    }

    /** Tasks assigned to a specific person. */
    public List<Task> findByAssignee(String assignee) {
        return findAll().stream()
                .filter(t -> assignee.equalsIgnoreCase(t.getAssignee()))
                .collect(Collectors.toList());
    }

    /** Remove a task. Returns true if something was actually deleted. */
    public boolean delete(String id) {
        return store.remove(id) != null;
    }

    /** Number of tasks currently in the store. */
    public int count() {
        return store.size();
    }
}
