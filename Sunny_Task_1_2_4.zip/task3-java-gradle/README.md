# CodeAlpha Task Manager — Gradle Java App

![Build Status](https://github.com/YOUR_USERNAME/CodeAlpha_JavaGradleApp/actions/workflows/ci.yml/badge.svg)
![Java](https://img.shields.io/badge/Java-17%2B-orange)
![Gradle](https://img.shields.io/badge/Gradle-8.x-blue)

A focused, production-style task management CLI built with **Java 17** and **Gradle**.  
It demonstrates dependency management, layered architecture, unit testing with JUnit 5, code coverage with JaCoCo, and an automated CI/CD pipeline through GitHub Actions.

---

## Project Structure

```
src/
├── main/java/com/codealpha/taskmanager/
│   ├── Main.java                   ← entry point / demo runner
│   ├── model/Task.java             ← domain entity
│   ├── repository/TaskRepository.java  ← in-memory data store
│   ├── service/TaskService.java    ← all business logic
│   └── util/TaskValidator.java     ← input validation
└── test/java/com/codealpha/taskmanager/
    └── TaskServiceTest.java        ← 12 unit tests (JUnit 5 + AssertJ)
```

---

## Gradle Tasks

| Command | What it does |
|---------|-------------|
| `./gradlew run` | Compile and run the demo |
| `./gradlew test` | Run all unit tests |
| `./gradlew jacocoTestReport` | Generate HTML coverage report |
| `./gradlew jar` | Build a standalone fat-jar |
| `./gradlew fullBuild` | Clean → build → test in one shot |
| `./gradlew dependencies` | Print the full dependency tree |

---

## Running Locally

```bash
# clone
git clone https://github.com/YOUR_USERNAME/CodeAlpha_JavaGradleApp.git
cd CodeAlpha_JavaGradleApp

# run (Gradle downloads all dependencies automatically)
./gradlew run

# test
./gradlew test
# open build/reports/tests/test/index.html for the test report

# coverage
./gradlew jacocoTestReport
# open build/reports/jacoco/test/html/index.html
```

---

## CI/CD Pipeline (GitHub Actions)

Every push to `main` or `develop`:

1. **Build & Test** — runs on Java 17 *and* Java 21 in parallel.
2. **Coverage report** — JaCoCo HTML report uploaded as a workflow artifact.
3. **Package** — fat-jar built and stored as a downloadable artifact (14-day retention).

Pipeline config: [`.github/workflows/ci.yml`](.github/workflows/ci.yml)

---

## Key Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| Gson | 2.10.1 | JSON serialisation (ready for file persistence) |
| SLF4J + Logback | 2.0.9 / 1.4.11 | Structured logging |
| JUnit Jupiter | 5.10.0 | Unit testing |
| AssertJ | 3.24.2 | Fluent test assertions |
| Mockito | 5.5.0 | Mocking in tests |
| JaCoCo | (plugin) | Code coverage |
