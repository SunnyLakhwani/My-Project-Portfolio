package stocktrader;

import java.util.List;
import java.util.Map;

/**
 * All console rendering for the trading platform.
 */
class MarketDisplay {

    private static final String RESET  = "\u001B[0m";
    private static final String BOLD   = "\u001B[1m";
    private static final String GREEN  = "\u001B[32m";
    private static final String RED    = "\u001B[31m";
    private static final String YELLOW = "\u001B[33m";
    private static final String CYAN   = "\u001B[36m";
    private static final String BLUE   = "\u001B[34m";
    private static final String DIM    = "\u001B[2m";
    private static final int W = 72;

    public static void divider() {
        System.out.println(DIM + "─".repeat(W) + RESET);
    }

    public static void header(String title) {
        System.out.println();
        divider();
        System.out.printf(BOLD + CYAN + "  %s%n" + RESET, title.toUpperCase());
        divider();
    }

    public static void success(String m) { System.out.println(GREEN  + "  ✔  " + m + RESET); }
    public static void error(String m)   { System.out.println(RED    + "  ✘  " + m + RESET); }
    public static void warn(String m)    { System.out.println(YELLOW + "  ⚠  " + m + RESET); }
    public static void info(String m)    { System.out.println(BLUE   + "  ℹ  " + m + RESET); }

    // ──────────────────────────────────────────
    //  Market board
    // ──────────────────────────────────────────

    public static void printMarketBoard(Market market) {
        header("📈  Live Market Board  [ Tick #" + market.getTickCount() + " ]");
        System.out.printf(BOLD + "  %-6s  %-28s  %10s  %10s  %8s  %-14s%n" + RESET,
                "Sym", "Company", "Price", "Open", "Change", "Sector");
        divider();
        for (Stock s : market.getAllStocks().values()) {
            double chg = s.getDayChange();
            String col = chg >= 0 ? GREEN : RED;
            String bar = sparkBar(s.getPriceHistory());
            System.out.printf("  %-6s  %-28s  " + col + "%10.2f  %10.2f  %+7.2f%%%s  %s%n",
                    s.getSymbol(), truncate(s.getCompanyName(), 28),
                    s.getCurrentPrice(), s.getOpenPrice(), chg, RESET, bar);
        }
        divider();
    }

    // ──────────────────────────────────────────
    //  Portfolio display
    // ──────────────────────────────────────────

    public static void printPortfolio(Portfolio p, Market market) {
        header("💼  Portfolio Overview");
        double mv     = p.getMarketValue(market.getAllStocks());
        double total  = p.getTotalValue(market.getAllStocks());
        double uPnL   = p.getUnrealisedPnL(market.getAllStocks());
        double rPnL   = p.getRealisedPnL();

        System.out.printf("  Cash Balance    : $%,.2f%n", p.getCashBalance());
        System.out.printf("  Market Value    : $%,.2f%n", mv);
        System.out.printf("  Total Value     : " + BOLD + "$%,.2f%n" + RESET, total);

        String uCol = uPnL >= 0 ? GREEN : RED;
        String rCol = rPnL >= 0 ? GREEN : RED;
        System.out.printf("  Unrealised P&L  : " + uCol + "%+,.2f%n" + RESET, uPnL);
        System.out.printf("  Realised P&L    : " + rCol + "%+,.2f%n" + RESET, rPnL);
        divider();

        if (p.getHoldings().isEmpty()) {
            warn("You hold no positions.");
            return;
        }
        System.out.printf(BOLD + "  %-6s  %6s  %10s  %10s  %10s  %10s%n" + RESET,
                "Sym", "Shares", "Avg Cost", "Cur Price", "Mkt Val", "P&L");
        divider();
        for (Map.Entry<String, Integer> e : p.getHoldings().entrySet()) {
            String sym  = e.getKey();
            int    qty  = e.getValue();
            double avg  = p.getAvgCostBasis().getOrDefault(sym, 0.0);
            Stock  s    = market.getAllStocks().get(sym);
            if (s == null) continue;
            double mktVal = s.getCurrentPrice() * qty;
            double pnl    = (s.getCurrentPrice() - avg) * qty;
            String pnlCol = pnl >= 0 ? GREEN : RED;
            System.out.printf("  %-6s  %6d  %10.2f  %10.2f  %10.2f  " + pnlCol + "%+10.2f%n" + RESET,
                    sym, qty, avg, s.getCurrentPrice(), mktVal, pnl);
        }
        divider();
    }

    // ──────────────────────────────────────────
    //  Transaction history
    // ──────────────────────────────────────────

    public static void printTransactionHistory(Portfolio p) {
        header("📋  Transaction History");
        List<Transaction> txns = p.getTransactions();
        if (txns.isEmpty()) { warn("No transactions yet."); return; }
        System.out.printf(BOLD + "  %-19s  %-4s  %-6s  %6s  %10s  %12s%n" + RESET,
                "Timestamp", "Type", "Sym", "Qty", "Price", "Total");
        divider();
        for (Transaction t : txns) {
            String col = t.getType() == Transaction.Type.BUY ? GREEN : RED;
            System.out.printf("  %-19s  " + col + "%-4s" + RESET + "  %-6s  %6d  %10.2f  %12.2f%n",
                    t.toString().substring(1, 20),   // timestamp slice
                    t.getType(), t.getSymbol(),
                    t.getQuantity(), t.getPricePerShare(), t.getTotalValue());
        }
        divider();
        System.out.printf("  Total transactions: %d%n", txns.size());
        divider();
    }

    // ──────────────────────────────────────────
    //  Helpers
    // ──────────────────────────────────────────

    /** Braille-style spark bar from last 8 price points. */
    private static String sparkBar(java.util.List<Double> hist) {
        String[] blocks = {"▁","▂","▃","▄","▅","▆","▇","█"};
        int count = Math.min(8, hist.size());
        if (count < 2) return "        ";
        List<Double> slice = hist.subList(hist.size() - count, hist.size());
        double min = slice.stream().mapToDouble(Double::doubleValue).min().orElse(0);
        double max = slice.stream().mapToDouble(Double::doubleValue).max().orElse(1);
        double range = max - min;
        StringBuilder sb = new StringBuilder();
        for (double v : slice) {
            int idx = range == 0 ? 3 : (int) ((v - min) / range * 7);
            sb.append(blocks[Math.min(idx, 7)]);
        }
        return sb.toString();
    }

    private static String truncate(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }
}