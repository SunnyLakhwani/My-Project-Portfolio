package stocktrader;

import java.util.*;

/**
 * Represents a user's holdings and cash balance.
 * Tracks unrealised P&L, realised P&L, and cost basis per symbol.
 */
public class Portfolio {

    private double cashBalance;
    private final Map<String, Integer> holdings;         // symbol -> shares owned
    private final Map<String, Double>  avgCostBasis;     // symbol -> average cost per share
    private final List<Transaction>    transactions;
    private double realisedPnL;

    public Portfolio(double startingCash) {
        this.cashBalance  = startingCash;
        this.holdings     = new LinkedHashMap<>();
        this.avgCostBasis = new LinkedHashMap<>();
        this.transactions = new ArrayList<>();
        this.realisedPnL  = 0;
    }

    // ──────────────────────────────────────────
    //  Trading operations
    // ──────────────────────────────────────────

    /**
     * Buys `quantity` shares of `stock` at the current market price.
     * @return empty string on success, error message on failure.
     */
    public String buy(Stock stock, int quantity) {
        if (quantity <= 0) return "Quantity must be positive.";
        double cost = stock.getCurrentPrice() * quantity;
        if (cost > cashBalance)
            return String.format("Insufficient funds. Need $%.2f, have $%.2f.", cost, cashBalance);

        cashBalance -= cost;

        // Update weighted average cost basis
        int prev     = holdings.getOrDefault(stock.getSymbol(), 0);
        double prevCost = avgCostBasis.getOrDefault(stock.getSymbol(), 0.0);
        double newAvg = ((prevCost * prev) + (stock.getCurrentPrice() * quantity)) / (prev + quantity);
        holdings.put(stock.getSymbol(), prev + quantity);
        avgCostBasis.put(stock.getSymbol(), newAvg);

        transactions.add(new Transaction(Transaction.Type.BUY,
                stock.getSymbol(), quantity, stock.getCurrentPrice()));
        return "";
    }

    /**
     * Sells `quantity` shares of `stock`.
     * @return empty string on success, error message on failure.
     */
    public String sell(Stock stock, int quantity) {
        if (quantity <= 0) return "Quantity must be positive.";
        int owned = holdings.getOrDefault(stock.getSymbol(), 0);
        if (owned < quantity)
            return String.format("Not enough shares. Own %d, trying to sell %d.", owned, quantity);

        double proceeds = stock.getCurrentPrice() * quantity;
        double costBasis = avgCostBasis.getOrDefault(stock.getSymbol(), 0.0) * quantity;
        realisedPnL += (proceeds - costBasis);

        cashBalance += proceeds;
        int remaining = owned - quantity;
        if (remaining == 0) {
            holdings.remove(stock.getSymbol());
            avgCostBasis.remove(stock.getSymbol());
        } else {
            holdings.put(stock.getSymbol(), remaining);
        }

        transactions.add(new Transaction(Transaction.Type.SELL,
                stock.getSymbol(), quantity, stock.getCurrentPrice()));
        return "";
    }

    // ──────────────────────────────────────────
    //  Portfolio metrics
    // ──────────────────────────────────────────

    /**
     * Market value of all open positions using current prices.
     */
    public double getMarketValue(Map<String, Stock> market) {
        double total = 0;
        for (Map.Entry<String, Integer> e : holdings.entrySet()) {
            Stock s = market.get(e.getKey());
            if (s != null) total += s.getCurrentPrice() * e.getValue();
        }
        return total;
    }

    /** Total account value = cash + market value of holdings. */
    public double getTotalValue(Map<String, Stock> market) {
        return cashBalance + getMarketValue(market);
    }

    /** Unrealised P&L across all open positions. */
    public double getUnrealisedPnL(Map<String, Stock> market) {
        double pnl = 0;
        for (Map.Entry<String, Integer> e : holdings.entrySet()) {
            Stock s = market.get(e.getKey());
            if (s == null) continue;
            double basis = avgCostBasis.getOrDefault(e.getKey(), 0.0);
            pnl += (s.getCurrentPrice() - basis) * e.getValue();
        }
        return pnl;
    }

    // ──────────────────────────────────────────
    //  Getters
    // ──────────────────────────────────────────

    public double getCashBalance()                  { return cashBalance; }
    public Map<String, Integer> getHoldings()       { return Collections.unmodifiableMap(holdings); }
    public Map<String, Double> getAvgCostBasis()    { return Collections.unmodifiableMap(avgCostBasis); }
    public List<Transaction> getTransactions()      { return Collections.unmodifiableList(transactions); }
    public double getRealisedPnL()                  { return realisedPnL; }

    public int sharesOwned(String symbol)           { return holdings.getOrDefault(symbol, 0); }
}