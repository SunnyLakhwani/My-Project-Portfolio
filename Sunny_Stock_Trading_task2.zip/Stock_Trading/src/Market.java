package stocktrader;

import java.util.*;

/**
 * The simulated stock exchange.  Holds all listed stocks and advances
 * the clock by simulating price ticks.
 */
public class Market {

    private final Map<String, Stock> stocks = new LinkedHashMap<>();
    private int tickCount = 0;

    public Market() {
        // Seed with a realistic set of fictional / real-world-inspired tickers
        addStock(new Stock("AAPL",  "Apple Inc.",              "Technology",   182.50, 0.015));
        addStock(new Stock("MSFT",  "Microsoft Corporation",   "Technology",   415.20, 0.013));
        addStock(new Stock("GOOGL", "Alphabet Inc.",           "Technology",   175.80, 0.016));
        addStock(new Stock("AMZN",  "Amazon.com Inc.",         "E-Commerce",   195.40, 0.018));
        addStock(new Stock("TSLA",  "Tesla Inc.",              "Automotive",   225.00, 0.030));
        addStock(new Stock("NVDA",  "NVIDIA Corporation",      "Semiconductors",895.00, 0.025));
        addStock(new Stock("JPM",   "JPMorgan Chase & Co.",    "Finance",      200.30, 0.012));
        addStock(new Stock("META",  "Meta Platforms Inc.",     "Social Media", 520.10, 0.020));
        addStock(new Stock("BRK.B", "Berkshire Hathaway B",   "Finance",      408.00, 0.008));
        addStock(new Stock("XOM",   "Exxon Mobil Corp.",       "Energy",       121.50, 0.014));
    }

    private void addStock(Stock s) { stocks.put(s.getSymbol(), s); }

    /**
     * Advance all stock prices by one simulation tick.
     * Every 20 ticks, open prices are reset (new trading session).
     */
    public void tick() {
        tickCount++;
        stocks.values().forEach(Stock::simulateTick);
        if (tickCount % 20 == 0) stocks.values().forEach(Stock::resetOpenPrice);
    }

    public Optional<Stock> getStock(String symbol) {
        return Optional.ofNullable(stocks.get(symbol.toUpperCase()));
    }

    public Map<String, Stock> getAllStocks() { return Collections.unmodifiableMap(stocks); }

    public int getTickCount() { return tickCount; }

    /** Returns stocks sorted by day-change descending (top movers first). */
    public List<Stock> getTopMovers() {
        List<Stock> list = new ArrayList<>(stocks.values());
        list.sort(Comparator.comparingDouble(s -> -Math.abs(s.getDayChange())));
        return list;
    }
}