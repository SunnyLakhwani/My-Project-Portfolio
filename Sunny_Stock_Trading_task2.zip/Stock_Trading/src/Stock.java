package stocktrader;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Represents a publicly traded stock with live price simulation.
 */
public class Stock {

    private final String symbol;
    private final String companyName;
    private final String sector;
    private double currentPrice;
    private double openPrice;          // price at market open each session
    private final List<Double> priceHistory;  // last 30 data points
    private final Random rng;

    // Volatility: higher = more price swings (e.g. 0.02 = ±2% per tick)
    private final double volatility;

    private static final int MAX_HISTORY = 30;

    public Stock(String symbol, String companyName, String sector,
                 double initialPrice, double volatility) {
        this.symbol      = symbol;
        this.companyName = companyName;
        this.sector      = sector;
        this.currentPrice = initialPrice;
        this.openPrice    = initialPrice;
        this.volatility   = volatility;
        this.priceHistory = new ArrayList<>();
        this.rng          = new Random();
        priceHistory.add(initialPrice);
    }

    /**
     * Simulates one price tick using Geometric Brownian Motion (simplified).
     * Drift is slightly positive to mimic long-term market growth.
     */
    public void simulateTick() {
        double drift   = 0.0002;   // small upward bias
        double shock   = rng.nextGaussian() * volatility;
        double change  = currentPrice * (drift + shock);
        currentPrice   = Math.max(0.01, currentPrice + change);
        currentPrice   = Math.round(currentPrice * 100.0) / 100.0;

        if (priceHistory.size() >= MAX_HISTORY) priceHistory.remove(0);
        priceHistory.add(currentPrice);
    }

    /** Percentage change from open. */
    public double getDayChange() {
        return ((currentPrice - openPrice) / openPrice) * 100.0;
    }

    /** Simple moving average of price history. */
    public double getSMA() {
        return priceHistory.stream().mapToDouble(Double::doubleValue).average().orElse(0);
    }

    public void resetOpenPrice()      { this.openPrice = currentPrice; }

    public String getSymbol()         { return symbol; }
    public String getCompanyName()    { return companyName; }
    public String getSector()         { return sector; }
    public double getCurrentPrice()   { return currentPrice; }
    public double getOpenPrice()      { return openPrice; }
    public double getVolatility()     { return volatility; }
    public List<Double> getPriceHistory() { return priceHistory; }

    @Override
    public String toString() {
        return String.format("%-6s | %-28s | $%8.2f | %+6.2f%%",
                symbol, companyName, currentPrice, getDayChange());
    }
}