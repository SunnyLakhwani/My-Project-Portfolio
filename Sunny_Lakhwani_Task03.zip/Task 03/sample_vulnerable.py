import pickle
import hashlib
import random
import subprocess
import sqlite3

# S08 — hardcoded secret
api_key = "sk-9f2a1c8e3b7d4f6a0e5c2b1d9a8f3e7c"
password = "hunter2_supersecret"

# S01 — eval with user input
def run_user_formula(user_input):
    result = eval(user_input)          # dangerous: user controls execution
    return result

# S02 — shell injection surface
def list_files(directory):
    subprocess.run("ls " + directory, shell=True)  # injection risk

# S03 — insecure deserialization
def load_session(data: bytes):
    session = pickle.loads(data)       # arbitrary code exec on load
    return session

# S04 — broken hash
def hash_password(pw: str) -> str:
    return hashlib.new("md5", pw.encode()).hexdigest()

# S05 — weak PRNG for token generation
def generate_token():
    return str(random.randint(100000, 999999))

# S06 — assert used as a security gate
def admin_only(user_role):
    assert user_role == "admin"        # stripped by python -O
    return "admin panel"

# S09 — SQL injection via concatenation
def get_user(username: str):
    conn = sqlite3.connect("app.db")
    cur = conn.cursor()
    # regex pattern triggers here:
    cur.execute("SELECT * FROM users WHERE username = '" + username + "'")
    return cur.fetchone()

# S10 — SSL verification disabled
import requests
def fetch_data(url):
    return requests.get(url, verify=False)   # MITM risk

# S11 — debug mode on
from flask import Flask
app = Flask(__name__)
app.run(debug=True)                          # exposes debugger

# S12 — unresolved security comment
# TODO: fix auth token validation vulnerability here
