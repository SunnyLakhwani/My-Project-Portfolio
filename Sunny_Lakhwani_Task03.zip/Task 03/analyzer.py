import ast
import re
import sys
import hashlib
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional


# ── Severity levels ──────────────────────────────────────────────────────────

CRITICAL = "CRITICAL"
HIGH     = "HIGH"
MEDIUM   = "MEDIUM"
LOW      = "LOW"
INFO     = "INFO"

SEVERITY_ORDER = {CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3, INFO: 4}

SEVERITY_COLORS = {
    CRITICAL: "\033[91m",   # bright red
    HIGH:     "\033[31m",   # red
    MEDIUM:   "\033[33m",   # yellow
    LOW:      "\033[36m",   # cyan
    INFO:     "\033[37m",   # white
    "RESET":  "\033[0m",
    "BOLD":   "\033[1m",
    "DIM":    "\033[2m",
    "GREEN":  "\033[32m",
}


# ── Finding dataclass ─────────────────────────────────────────────────────────

@dataclass
class Finding:
    rule_id:     str
    severity:    str
    title:       str
    description: str
    line:        int
    col:         int = 0
    snippet:     str = ""
    remediation: str = ""

    def severity_rank(self):
        return SEVERITY_ORDER.get(self.severity, 99)


# ── Individual vulnerability checks ──────────────────────────────────────────

class ASTChecker(ast.NodeVisitor):
    """
    Walks the parsed AST and collects findings.
    Each visit_* method corresponds to a node type we care about.
    """

    def __init__(self, source_lines: list[str]):
        self.findings: list[Finding] = []
        self.source_lines = source_lines

    def _snippet(self, lineno: int) -> str:
        if 1 <= lineno <= len(self.source_lines):
            return self.source_lines[lineno - 1].rstrip()
        return ""

    # ── RULE S01: Use of eval() / exec() ─────────────────────────────────────
    def visit_Call(self, node: ast.Call):
        func_name = ""
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr

        if func_name in ("eval", "exec"):
            self.findings.append(Finding(
                rule_id="S01",
                severity=CRITICAL,
                title=f"Dangerous use of {func_name}()",
                description=(
                    f"`{func_name}()` executes arbitrary code at runtime. "
                    "If any part of the argument is user-controlled, this is a "
                    "Remote Code Execution (RCE) vulnerability."
                ),
                line=node.lineno,
                col=node.col_offset,
                snippet=self._snippet(node.lineno),
                remediation=(
                    f"Eliminate `{func_name}()` entirely. "
                    "If dynamic dispatch is needed, use a lookup dict of safe callables."
                ),
            ))

        # ── RULE S02: Subprocess with shell=True ──────────────────────────
        if func_name in ("run", "call", "Popen", "check_output", "check_call"):
            for kw in node.keywords:
                if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                    self.findings.append(Finding(
                        rule_id="S02",
                        severity=HIGH,
                        title="subprocess called with shell=True",
                        description=(
                            "shell=True passes the command through the OS shell, enabling "
                            "shell injection if any argument is user-supplied. "
                            "Attackers can append '; rm -rf /' or pipe commands."
                        ),
                        line=node.lineno,
                        col=node.col_offset,
                        snippet=self._snippet(node.lineno),
                        remediation=(
                            "Use shell=False (the default) and pass arguments as a list: "
                            "subprocess.run(['cmd', arg1, arg2]). "
                            "Validate and sanitize all external inputs first."
                        ),
                    ))

        # ── RULE S03: Use of pickle / marshal ────────────────────────────
        if func_name in ("loads", "load") and isinstance(node.func, ast.Attribute):
            module = self._resolve_attribute_module(node.func)
            if module in ("pickle", "marshal", "shelve", "dill"):
                self.findings.append(Finding(
                    rule_id="S03",
                    severity=HIGH,
                    title=f"Insecure deserialization via {module}.{func_name}()",
                    description=(
                        f"`{module}` deserializes arbitrary Python objects. "
                        "A crafted payload can execute code during deserialization — "
                        "no user interaction required beyond supplying the data."
                    ),
                    line=node.lineno,
                    col=node.col_offset,
                    snippet=self._snippet(node.lineno),
                    remediation=(
                        "Replace with a safe format like JSON or MessagePack. "
                        "If pickle is unavoidable, only deserialize data from "
                        "cryptographically signed and verified sources."
                    ),
                ))

        # ── RULE S04: MD5 / SHA1 used as cryptographic hash ──────────────
        if func_name == "new" and isinstance(node.func, ast.Attribute):
            if self._resolve_attribute_module(node.func) == "hashlib":
                for arg in node.args:
                    if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                        if arg.value.lower() in ("md5", "sha1"):
                            self.findings.append(Finding(
                                rule_id="S04",
                                severity=MEDIUM,
                                title=f"Weak hash algorithm: {arg.value.upper()}",
                                description=(
                                    f"{arg.value.upper()} is cryptographically broken. "
                                    "MD5 collisions can be generated in seconds; SHA-1 was "
                                    "formally broken in 2017 (SHAttered attack). "
                                    "Neither should be used for password hashing or signatures."
                                ),
                                line=node.lineno,
                                col=node.col_offset,
                                snippet=self._snippet(node.lineno),
                                remediation=(
                                    "Use SHA-256 or SHA-3 for general hashing. "
                                    "For passwords, use bcrypt, scrypt, or Argon2 via the "
                                    "`passlib` or `argon2-cffi` libraries."
                                ),
                            ))

        # ── RULE S05: Random used for security purposes ───────────────────
        if func_name in ("random", "randint", "choice", "shuffle", "randbytes"):
            if isinstance(node.func, ast.Attribute):
                module = self._resolve_attribute_module(node.func)
                if module == "random":
                    self.findings.append(Finding(
                        rule_id="S05",
                        severity=MEDIUM,
                        title="Non-cryptographic PRNG used (random module)",
                        description=(
                            "Python's `random` module uses Mersenne Twister — a PRNG that is "
                            "not cryptographically secure. Its state can be reconstructed from "
                            "624 consecutive outputs. Never use it for tokens, salts, or keys."
                        ),
                        line=node.lineno,
                        col=node.col_offset,
                        snippet=self._snippet(node.lineno),
                        remediation=(
                            "Use `secrets` for security-sensitive values: "
                            "secrets.token_hex(), secrets.token_urlsafe(), secrets.choice(). "
                            "Use `os.urandom()` for raw bytes."
                        ),
                    ))

        # ── RULE S06: assert used for security checks ─────────────────────
        # (covered in visit_Assert)

        self.generic_visit(node)

    def visit_Assert(self, node: ast.Assert):
        """RULE S06 — assert stripped by Python -O flag."""
        self.findings.append(Finding(
            rule_id="S06",
            severity=HIGH,
            title="Security check relies on assert statement",
            description=(
                "`assert` statements are removed entirely when Python runs with "
                "the `-O` (optimize) flag. Any authentication, authorization, or "
                "validation logic inside an assert is silently skipped in production."
            ),
            line=node.lineno,
            col=node.col_offset,
            snippet=self._snippet(node.lineno),
            remediation=(
                "Replace with explicit `if not condition: raise ValueError(...)` or "
                "a dedicated guard function. Never use assert for security enforcement."
            ),
        ))
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import):
        """RULE S07 — dangerous module imports."""
        dangerous = {
            "telnetlib": "Telnet transmits credentials in plaintext. Use paramiko (SSH).",
            "ftplib":    "FTP is unencrypted. Use ftplib with TLS or switch to SFTP/SCP.",
            "xmlrpc":    "XML-RPC has no built-in authentication. Expose carefully.",
        }
        for alias in node.names:
            if alias.name in dangerous:
                self.findings.append(Finding(
                    rule_id="S07",
                    severity=MEDIUM,
                    title=f"Import of insecure module: {alias.name}",
                    description=dangerous[alias.name],
                    line=node.lineno,
                    col=node.col_offset,
                    snippet=self._snippet(node.lineno),
                    remediation=dangerous[alias.name],
                ))
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign):
        """RULE S08 — hardcoded secrets in assignments."""
        secret_keywords = re.compile(
            r"(password|passwd|secret|api_?key|auth_?token|access_?token|private_?key)",
            re.IGNORECASE,
        )
        for target in node.targets:
            target_name = ""
            if isinstance(target, ast.Name):
                target_name = target.id
            elif isinstance(target, ast.Attribute):
                target_name = target.attr

            if secret_keywords.search(target_name):
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    val = node.value.value
                    if len(val) > 3:  # ignore empty/placeholder strings of 1-3 chars
                        self.findings.append(Finding(
                            rule_id="S08",
                            severity=CRITICAL,
                            title=f"Hardcoded secret in variable '{target_name}'",
                            description=(
                                "A secret value appears to be hardcoded directly in source. "
                                "Committing this to version control exposes the credential "
                                "permanently — even after deletion, it persists in git history."
                            ),
                            line=node.lineno,
                            col=node.col_offset,
                            snippet=self._snippet(node.lineno),
                            remediation=(
                                "Load secrets from environment variables (os.getenv) or a "
                                "secrets manager (AWS Secrets Manager, HashiCorp Vault, etc.). "
                                "If already committed, rotate the credential immediately."
                            ),
                        ))
        self.generic_visit(node)

    # ── Helper ────────────────────────────────────────────────────────────────

    def _resolve_attribute_module(self, node: ast.Attribute) -> str:
        """Best-effort extraction of the module name from an attribute call."""
        if isinstance(node.value, ast.Name):
            return node.value.id
        if isinstance(node.value, ast.Attribute):
            return self._resolve_attribute_module(node.value)
        return ""


# ── Regex-based checks (things the AST misses) ───────────────────────────────

REGEX_RULES: list[dict] = [
    {
        "rule_id": "S09",
        "severity": HIGH,
        "pattern": re.compile(r"SELECT\s+.+\s+FROM\s+.+\s+WHERE\s+.+\+", re.IGNORECASE),
        "title": "Potential SQL Injection — string concatenation in query",
        "description": (
            "SQL queries built by concatenating strings are vulnerable to injection. "
            "An attacker who controls any fragment can manipulate the query structure, "
            "bypass authentication, dump tables, or drop the database."
        ),
        "remediation": (
            "Use parameterised queries exclusively: "
            "cursor.execute('SELECT ... WHERE id = ?', (user_id,)). "
            "ORMs like SQLAlchemy handle this automatically."
        ),
    },
    {
        "rule_id": "S10",
        "severity": HIGH,
        "pattern": re.compile(r"(verify\s*=\s*False)", re.IGNORECASE),
        "title": "SSL certificate verification disabled",
        "description": (
            "verify=False disables TLS certificate validation, making every HTTPS "
            "connection vulnerable to man-in-the-middle attacks. Attackers on the "
            "same network can intercept or modify traffic silently."
        ),
        "remediation": (
            "Remove verify=False. If you have a self-signed cert, pass "
            "verify='/path/to/ca-bundle.crt' instead. "
            "Never disable verification in production."
        ),
    },
    {
        "rule_id": "S11",
        "severity": MEDIUM,
        "pattern": re.compile(r"debug\s*=\s*True", re.IGNORECASE),
        "title": "Debug mode enabled",
        "description": (
            "Running a web framework (Flask, Django, etc.) with debug=True exposes "
            "an interactive debugger and full tracebacks to anyone who triggers an error. "
            "Flask's Werkzeug debugger allows arbitrary code execution via the PIN."
        ),
        "remediation": (
            "Set debug=False in production. Control this via an environment variable: "
            "app.run(debug=os.getenv('FLASK_DEBUG', 'false').lower() == 'true')."
        ),
    },
    {
        "rule_id": "S12",
        "severity": LOW,
        "pattern": re.compile(r"#\s*(TODO|FIXME|HACK|XXX)\s*:?.*(auth|security|password|token|vuln|fix)",
                               re.IGNORECASE),
        "title": "Security-related TODO/FIXME comment",
        "description": (
            "A comment flags an unresolved security concern. These are often deferred "
            "indefinitely and become permanent vulnerabilities in production code."
        ),
        "remediation": (
            "Resolve the underlying issue before shipping. "
            "Track it in your issue tracker with a defined owner and deadline."
        ),
    },
]


def regex_scan(source: str, source_lines: list[str]) -> list[Finding]:
    findings = []
    for rule in REGEX_RULES:
        for match in rule["pattern"].finditer(source):
            lineno = source[:match.start()].count("\n") + 1
            findings.append(Finding(
                rule_id=rule["rule_id"],
                severity=rule["severity"],
                title=rule["title"],
                description=rule["description"],
                line=lineno,
                snippet=source_lines[lineno - 1].rstrip() if lineno <= len(source_lines) else "",
                remediation=rule["remediation"],
            ))
    return findings


# ── Main analysis entry point ─────────────────────────────────────────────────

def analyze_file(path: Path) -> tuple[list[Finding], Optional[str]]:
    """
    Parse and audit a single Python file.
    Returns (findings, parse_error_or_None).
    """
    try:
        source = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as e:
        return [], str(e)

    source_lines = source.splitlines()

    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as e:
        return [], f"SyntaxError at line {e.lineno}: {e.msg}"

    checker = ASTChecker(source_lines)
    checker.visit(tree)

    regex_findings = regex_scan(source, source_lines)

    all_findings = checker.findings + regex_findings
    all_findings.sort(key=lambda f: (f.severity_rank(), f.line))
    return all_findings, None


# ── Report rendering ──────────────────────────────────────────────────────────

def _c(key: str) -> str:
    """Return ANSI escape code."""
    return SEVERITY_COLORS.get(key, "")


def print_report(path: Path, findings: list[Finding], parse_error: Optional[str]):
    R = _c("RESET")
    B = _c("BOLD")
    D = _c("DIM")

    print(f"\n{B}{'─' * 70}{R}")
    print(f"{B}  FILE: {path}{R}")
    print(f"{B}{'─' * 70}{R}")

    if parse_error:
        print(f"  {_c(HIGH)}⚠  Could not parse file: {parse_error}{R}\n")
        return

    if not findings:
        print(f"  {_c('GREEN')}✔  No issues detected.{R}\n")
        return

    counts = {s: 0 for s in (CRITICAL, HIGH, MEDIUM, LOW, INFO)}
    for f in findings:
        counts[f.severity] = counts.get(f.severity, 0) + 1

    summary_parts = []
    for sev, count in counts.items():
        if count:
            summary_parts.append(f"{_c(sev)}{count} {sev}{R}")
    print(f"  Summary: {', '.join(summary_parts)}\n")

    for i, f in enumerate(findings, 1):
        sc = _c(f.severity)
        print(f"  {B}[{f.rule_id}] {sc}{f.severity}{R}  —  {B}{f.title}{R}")
        print(f"  {D}Line {f.line}, col {f.col}{R}")
        if f.snippet:
            print(f"  {D}  ❯  {f.snippet}{R}")
        print(f"  {f.description}")
        print(f"  {D}Remediation:{R} {f.remediation}")
        if i < len(findings):
            print(f"  {D}{'·' * 60}{R}")

    print()


def print_summary_table(results: dict[Path, list[Finding]]):
    R  = _c("RESET")
    B  = _c("BOLD")
    D  = _c("DIM")

    total_findings = sum(len(v) for v in results.values())
    total_files = len(results)
    files_clean = sum(1 for v in results.values() if not v)

    print(f"\n{B}{'═' * 70}{R}")
    print(f"{B}  AUDIT COMPLETE{R}")
    print(f"{B}{'═' * 70}{R}")
    print(f"  Files scanned : {total_files}")
    print(f"  Files clean   : {_c('GREEN')}{files_clean}{R}")
    print(f"  Total findings: {_c(CRITICAL) if total_findings else _c('GREEN')}{total_findings}{R}")

    if total_findings:
        all_f = [f for flist in results.values() for f in flist]
        for sev in (CRITICAL, HIGH, MEDIUM, LOW, INFO):
            count = sum(1 for f in all_f if f.severity == sev)
            if count:
                bar = "█" * min(count * 2, 40)
                print(f"  {_c(sev)}{sev:<10}{R}  {bar}  {count}")

    print(f"{B}{'═' * 70}{R}\n")


# ── CLI entry point ───────────────────────────────────────────────────────────

def main():
    targets = sys.argv[1:] if len(sys.argv) > 1 else ["."]

    paths: list[Path] = []
    for t in targets:
        p = Path(t)
        if p.is_dir():
            paths.extend(sorted(p.rglob("*.py")))
        elif p.suffix == ".py":
            paths.append(p)
        else:
            print(f"Skipping non-Python path: {t}")

    if not paths:
        print("No Python files found.")
        sys.exit(0)

    results: dict[Path, list[Finding]] = {}
    for path in paths:
        findings, error = analyze_file(path)
        results[path] = findings
        print_report(path, findings, error)

    print_summary_table(results)

    # Exit with non-zero code if any HIGH/CRITICAL found (useful in CI pipelines)
    critical_count = sum(
        1 for flist in results.values()
        for f in flist if f.severity in (CRITICAL, HIGH)
    )
    sys.exit(1 if critical_count else 0)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        pass
