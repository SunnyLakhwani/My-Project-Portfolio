# Secure Coding Review Tool

**CodeAlpha Cybersecurity Internship — Task 3**

A lightweight, dependency-free static analyzer for Python source code. It audits files for common security vulnerabilities using AST (Abstract Syntax Tree) traversal and regex pattern matching — no third-party audit libraries, so every check is fully readable and auditable.

---

## What It Detects

| Rule | Severity | Vulnerability |
|------|----------|---------------|
| S01  | CRITICAL | `eval()` / `exec()` — Remote Code Execution |
| S02  | HIGH     | `subprocess` with `shell=True` — Shell Injection |
| S03  | HIGH     | `pickle.loads()` — Insecure Deserialization |
| S04  | MEDIUM   | MD5 / SHA-1 — Broken Hash Algorithms |
| S05  | MEDIUM   | `random` module used for security tokens |
| S06  | HIGH     | `assert` used as a security gate |
| S07  | MEDIUM   | Insecure module imports (`telnetlib`, `ftplib`) |
| S08  | CRITICAL | Hardcoded secrets / API keys in source |
| S09  | HIGH     | SQL Injection via string concatenation |
| S10  | HIGH     | `verify=False` — SSL certificate check disabled |
| S11  | MEDIUM   | `debug=True` — Debug mode left on |
| S12  | LOW      | Unresolved security-related TODO/FIXME comments |

---

## Requirements

- Python 3.10+
- No external dependencies — uses only the standard library (`ast`, `re`, `pathlib`)

---

## Usage

```bash
# Audit a single file
python analyzer.py myapp.py

# Audit an entire directory (recursive)
python analyzer.py /path/to/project/

# Run the included demo
python analyzer.py sample_vulnerable.py
```

### CI Pipeline Integration

The tool exits with code `1` if any CRITICAL or HIGH findings are found, and `0` otherwise. This makes it easy to block builds on serious issues:

```bash
python analyzer.py src/ || echo "Security issues found — build blocked"
```

---

## How It Works

### 1. AST-Based Analysis
The file is parsed into an Abstract Syntax Tree using Python's built-in `ast` module. A custom `NodeVisitor` subclass walks every node looking for dangerous function calls, insecure assignments, and risky control flow patterns. This approach is precise — it understands code structure, not just text.

### 2. Regex-Based Analysis
Some patterns are easier to catch with regular expressions — particularly multi-line constructs like SQL queries and configuration flags. The regex scanner runs over the raw source in parallel.

### 3. Structured Findings
Every finding carries a rule ID, severity, description of the actual risk, the offending line with its source snippet, and a concrete remediation step. Findings are sorted by severity, then line number.

---

## Example Output

```
──────────────────────────────────────────────────────────────────────
  FILE: sample_vulnerable.py
──────────────────────────────────────────────────────────────────────
  Summary: 3 CRITICAL, 5 HIGH, 3 MEDIUM, 1 LOW

  [S08] CRITICAL  —  Hardcoded secret in variable 'api_key'
  Line 14, col 0
    ❯  api_key = "sk-9f2a1c8e3b7d4f6a0e5c2b1d9a8f3e7c"
  A secret value appears to be hardcoded directly in source...
  Remediation: Load secrets from environment variables (os.getenv)...
```

---

## Project Structure

```
secure_code_review/
├── analyzer.py            # Main tool — all logic lives here
├── sample_vulnerable.py   # Intentionally flawed demo file
└── README.md
```

---

## Limitations & Future Work

- **Scope**: Currently audits Python only. Support for JavaScript and Go could be added with language-specific AST parsers.
- **False positives**: Pattern matching on variable names (S08) may flag test fixtures with dummy values. A `# nosec` inline comment suppression mechanism would help.
- **Taint tracking**: The tool flags `eval(user_input)` but doesn't trace data flow — if user input passes through three helper functions before reaching `eval`, it won't be caught. Full taint analysis requires a more complex data-flow graph.
- **Config files**: Secrets in `.env`, YAML, or JSON config files are not scanned.

---

## References

- OWASP Top 10: https://owasp.org/www-project-top-ten/
- Python `ast` module docs: https://docs.python.org/3/library/ast.html
- CWE-78 (OS Command Injection), CWE-89 (SQL Injection), CWE-502 (Deserialization)
