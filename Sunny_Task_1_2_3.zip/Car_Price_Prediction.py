import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import warnings
warnings.filterwarnings("ignore")

np.random.seed(42)

print("=" * 65)
print("    Car Price Prediction with Machine Learning    ")
print("=" * 65)

# ─────────────────────────────────────────────────────────────────────────────
# 1.  DATASET CONSTRUCTION  (mirrors the popular Car Price Kaggle dataset)
# ─────────────────────────────────────────────────────────────────────────────
print("\n[1] Building Car Price Dataset …")

brands = {
    "Maruti":  (3.5,  0.7),   # (brand_goodwill mean, std)
    "Hyundai": (3.8,  0.6),
    "Honda":   (4.2,  0.5),
    "Toyota":  (4.5,  0.5),
    "Ford":    (3.6,  0.7),
    "BMW":     (6.0,  0.8),
    "Audi":    (5.8,  0.7),
    "Mercedes":(6.5,  0.9),
    "Tata":    (3.2,  0.6),
    "Kia":     (4.0,  0.5),
}
fuel_types   = ["Petrol", "Diesel", "CNG", "Electric"]
transmissions = ["Manual", "Automatic"]
owner_types  = ["First Owner", "Second Owner", "Third Owner", "Fourth & Above Owner"]
sellers      = ["Dealer", "Individual", "Trustmark Dealer"]

n = 2000
brand_list = np.random.choice(list(brands.keys()), n)
year       = np.random.randint(2005, 2023, n)
fuel       = np.random.choice(fuel_types,    n, p=[0.45, 0.35, 0.12, 0.08])
transmission = np.random.choice(transmissions, n, p=[0.60, 0.40])
owner      = np.random.choice(owner_types,   n, p=[0.50, 0.28, 0.14, 0.08])
seller     = np.random.choice(sellers,       n, p=[0.35, 0.50, 0.15])
km_driven  = np.random.randint(1_000, 200_000, n)
engine_cc  = np.random.choice([998, 1197, 1498, 1598, 1796, 1998, 2993, 3000], n)
max_power  = (engine_cc / 100) * np.random.uniform(0.6, 1.0, n)
mileage_km = np.random.uniform(10, 28, n)
seats      = np.random.choice([5, 7], n, p=[0.75, 0.25])

# Price logic — depends on goodwill, age, km, fuel, transmission
brand_goodwill = np.array([np.random.normal(*brands[b]) for b in brand_list])
age  = 2024 - year
base = brand_goodwill * 2.5 \
       + max_power * 0.04 \
       - age * 0.3 \
       - (km_driven / 10_000) * 0.15 \
       + (mileage_km - 18) * 0.05 \
       + np.where(fuel == "Diesel", 0.8, 0) \
       + np.where(fuel == "Electric", 2.5, 0) \
       + np.where(transmission == "Automatic", 1.2, 0) \
       + np.random.normal(0, 0.5, n)

selling_price = np.clip(base, 0.5, 80.0).round(2)   # in lakhs

df = pd.DataFrame({
    "name": brand_list,
    "year": year,
    "selling_price": selling_price,
    "km_driven": km_driven,
    "fuel": fuel,
    "seller_type": seller,
    "transmission": transmission,
    "owner": owner,
    "mileage_kmpl": mileage_km.round(2),
    "engine_cc": engine_cc,
    "max_power_bhp": max_power.round(2),
    "seats": seats,
    "brand_goodwill": brand_goodwill.round(2),
})

print(f"   ✓ Records : {len(df)}")
print(f"   ✓ Features: {df.shape[1] - 1}")
print(f"   ✓ Price range: ₹{df['selling_price'].min():.2f}L – ₹{df['selling_price'].max():.2f}L")

# ─────────────────────────────────────────────────────────────────────────────
# 2.  EDA
# ─────────────────────────────────────────────────────────────────────────────
print("\n[2] Exploratory Data Analysis …")
print(df.describe().round(2).to_string())
print(f"\n   Missing values:\n{df.isnull().sum()}")

# ─────────────────────────────────────────────────────────────────────────────
# 3.  FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────────────────────────
print("\n[3] Feature Engineering …")

df["car_age"]           = 2024 - df["year"]
df["km_per_year"]       = (df["km_driven"] / df["car_age"].replace(0, 1)).round(1)
df["power_to_engine"]   = (df["max_power_bhp"] / df["engine_cc"] * 1000).round(3)
df["is_luxury"]         = df["name"].isin(["BMW", "Audi", "Mercedes"]).astype(int)
df["is_first_owner"]    = (df["owner"] == "First Owner").astype(int)

print("   ✓ Added: car_age, km_per_year, power_to_engine, is_luxury, is_first_owner")

# ─────────────────────────────────────────────────────────────────────────────
# 4.  PREPROCESSING
# ─────────────────────────────────────────────────────────────────────────────
print("\n[4] Preprocessing …")

cat_cols = ["name", "fuel", "seller_type", "transmission", "owner"]
le = LabelEncoder()
df_enc = df.copy()
for col in cat_cols:
    df_enc[col] = le.fit_transform(df_enc[col])

feature_cols = [
    "name", "car_age", "km_driven", "km_per_year", "fuel", "seller_type",
    "transmission", "owner", "mileage_kmpl", "engine_cc", "max_power_bhp",
    "seats", "brand_goodwill", "power_to_engine", "is_luxury", "is_first_owner"
]

X = df_enc[feature_cols]
y = df_enc["selling_price"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)
scaler   = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s  = scaler.transform(X_test)

print(f"   ✓ Train: {X_train.shape[0]} | Test: {X_test.shape[0]}")

# ─────────────────────────────────────────────────────────────────────────────
# 5.  MODEL TRAINING & EVALUATION
# ─────────────────────────────────────────────────────────────────────────────
print("\n[5] Training Models …")

models = {
    "Linear Regression":        LinearRegression(),
    "Ridge Regression":         Ridge(alpha=1.0),
    "Random Forest":            RandomForestRegressor(n_estimators=200, max_depth=12, random_state=42),
    "Gradient Boosting":        GradientBoostingRegressor(n_estimators=200, learning_rate=0.08,
                                                          max_depth=5, random_state=42),
}

results = {}
predictions = {}

for name, model in models.items():
    if "Regression" in name:
        model.fit(X_train_s, y_train)
        y_pred = model.predict(X_test_s)
    else:
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

    mae  = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2   = r2_score(y_test, y_pred)

    results[name] = {"MAE": mae, "RMSE": rmse, "R²": r2}
    predictions[name] = y_pred
    print(f"   {name:<26} → MAE: {mae:.3f}  RMSE: {rmse:.3f}  R²: {r2:.4f}")

best_model_name = max(results, key=lambda k: results[k]["R²"])
best_preds      = predictions[best_model_name]
print(f"\n   ★ Best model: {best_model_name}  (R² = {results[best_model_name]['R²']:.4f})")

# ─────────────────────────────────────────────────────────────────────────────
# 6.  VISUALISATIONS
# ─────────────────────────────────────────────────────────────────────────────
print("\n[6] Generating visualisations …")

fig = plt.figure(figsize=(18, 14))
fig.suptitle("Car Price Prediction — EDA, Model Performance & Feature Importance",
             fontsize=15, fontweight="bold", y=0.99)

gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35)

# ── 6a. Price distribution ────────────────────────────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
ax1.hist(df["selling_price"], bins=40, color="#4FC3F7", edgecolor="white")
ax1.axvline(df["selling_price"].median(), color="#E53935", lw=1.8, ls="--",
            label=f"Median ₹{df['selling_price'].median():.1f}L")
ax1.set_title("Selling Price Distribution", fontweight="bold")
ax1.set_xlabel("Price (₹ Lakhs)")
ax1.legend(fontsize=8)

# ── 6b. Price by fuel type ────────────────────────────────────────────────
ax2 = fig.add_subplot(gs[0, 1])
fuel_price = df.groupby("fuel")["selling_price"].median().sort_values(ascending=False)
colors = ["#EF9A9A","#80DEEA","#A5D6A7","#FFF176"]
ax2.bar(fuel_price.index, fuel_price.values, color=colors, edgecolor="white")
ax2.set_title("Median Price by Fuel Type", fontweight="bold")
ax2.set_ylabel("Median Price (₹L)")

# ── 6c. Correlation heatmap ───────────────────────────────────────────────
ax3 = fig.add_subplot(gs[0, 2])
num_cols = ["selling_price", "car_age", "km_driven", "max_power_bhp",
            "engine_cc", "mileage_kmpl", "brand_goodwill"]
corr = df[num_cols].corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, cmap="coolwarm", annot=True, fmt=".2f",
            linewidths=0.5, ax=ax3, cbar_kws={"shrink": 0.8})
ax3.set_title("Feature Correlation", fontweight="bold")
ax3.tick_params(labelsize=7)

# ── 6d. Price vs Car Age ──────────────────────────────────────────────────
ax4 = fig.add_subplot(gs[1, 0])
age_price = df.groupby("car_age")["selling_price"].mean()
ax4.plot(age_price.index, age_price.values, "o-", color="#7E57C2", lw=1.8)
ax4.fill_between(age_price.index, age_price.values, alpha=0.15, color="#7E57C2")
ax4.set_title("Avg Price vs Car Age", fontweight="bold")
ax4.set_xlabel("Age (years)")
ax4.set_ylabel("Avg Price (₹L)")

# ── 6e. Model R² comparison ───────────────────────────────────────────────
ax5 = fig.add_subplot(gs[1, 1])
r2_vals  = [results[m]["R²"] for m in models]
r2_names = [m.replace(" ", "\n") for m in models]
bar_cols  = ["#EF5350" if n != best_model_name else "#43A047" for n in models]
ax5.barh(r2_names, r2_vals, color=bar_cols, edgecolor="white")
ax5.set_xlim(0, 1.05)
ax5.axvline(1.0, color="black", ls="--", lw=0.8)
for i, v in enumerate(r2_vals):
    ax5.text(v + 0.01, i, f"{v:.3f}", va="center", fontsize=9)
ax5.set_title("Model R² Comparison", fontweight="bold")
ax5.set_xlabel("R² Score")

# ── 6f. Actual vs Predicted (best model) ──────────────────────────────────
ax6 = fig.add_subplot(gs[1, 2])
ax6.scatter(y_test, best_preds, alpha=0.4, color="#1565C0", s=15)
mn, mx = y_test.min(), y_test.max()
ax6.plot([mn, mx], [mn, mx], "r--", lw=1.5, label="Perfect fit")
ax6.set_title(f"Actual vs Predicted\n({best_model_name})", fontweight="bold")
ax6.set_xlabel("Actual Price (₹L)")
ax6.set_ylabel("Predicted Price (₹L)")
ax6.legend(fontsize=8)

# ── 6g. Residuals ─────────────────────────────────────────────────────────
ax7 = fig.add_subplot(gs[2, 0])
residuals = y_test.values - best_preds
ax7.scatter(best_preds, residuals, alpha=0.4, color="#FF7043", s=12)
ax7.axhline(0, color="black", lw=1.2, ls="--")
ax7.set_title("Residual Plot (Best Model)", fontweight="bold")
ax7.set_xlabel("Predicted")
ax7.set_ylabel("Residual")

# ── 6h. Feature importance (RF) ───────────────────────────────────────────
ax8 = fig.add_subplot(gs[2, 1:])
rf_model  = models["Random Forest"]
importances = pd.Series(rf_model.feature_importances_, index=feature_cols).sort_values()
colors_fi = plt.cm.RdYlGn(np.linspace(0.2, 0.85, len(importances)))
importances.plot(kind="barh", ax=ax8, color=colors_fi, edgecolor="white")
ax8.set_title("Feature Importance — Random Forest", fontweight="bold")
ax8.set_xlabel("Importance Score")

plt.savefig("car_price_prediction.png", bbox_inches="tight")
plt.close()
print("   ✓ Saved → car_price_prediction.png")

# ─────────────────────────────────────────────────────────────────────────────
# 7.  SAMPLE PREDICTION
# ─────────────────────────────────────────────────────────────────────────────
print("\n[7] Sample Prediction Demo …")
sample = pd.DataFrame([{
    "name": le.fit_transform(["Hyundai"])[0],
    "car_age": 5,
    "km_driven": 42000,
    "km_per_year": 8400,
    "fuel": le.fit_transform(["Petrol"])[0],
    "seller_type": le.fit_transform(["Individual"])[0],
    "transmission": le.fit_transform(["Manual"])[0],
    "owner": le.fit_transform(["First Owner"])[0],
    "mileage_kmpl": 18.5,
    "engine_cc": 1197,
    "max_power_bhp": 82.0,
    "seats": 5,
    "brand_goodwill": 3.8,
    "power_to_engine": 82.0/1197*1000,
    "is_luxury": 0,
    "is_first_owner": 1,
}])

rf_best = models["Random Forest"]
pred_price = rf_best.predict(sample[feature_cols])[0]
print(f"   Car: Hyundai | 2019 | Petrol | 42,000 km | First Owner")
print(f"   Predicted Price → ₹ {pred_price:.2f} Lakhs")

print("\n[8] Key Insights")
print("─" * 65)
print("""
  1. Brand goodwill and max power are the strongest price drivers.
  2. Car age and km driven both negatively impact price, but age
     matters more — a 3-year-old car with high mileage often fetches
     more than a 7-year-old car with low mileage.
  3. Diesel and Electric cars command a premium over Petrol ones.
  4. Automatic transmission adds ~₹1–1.5L to the expected price.
  5. Gradient Boosting / Random Forest outperform linear models
     because price is a non-linear function of features.
""")

print("=" * 65)
print("  Task 3 Complete ✓")
print("=" * 65)