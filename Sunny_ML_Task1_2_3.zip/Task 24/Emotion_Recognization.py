import warnings
warnings.filterwarnings("ignore")
os_environ_set = __import__("os").environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")

import os, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, f1_score
)

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, callbacks, regularizers

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────────────────────────────────────

EMOTIONS   = ["neutral", "calm", "happy", "sad", "angry", "fearful", "disgust", "surprised"]
N_MFCC     = 40
SR         = 22050
DURATION   = 3          # seconds per sample (simulated)
N_SAMPLES  = 200        # samples per emotion class (1 600 total)
RANDOM_SEED = 42

np.random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)

PALETTE = {
    "bg":      "#0d1117",
    "panel":   "#161b22",
    "accent":  "#58a6ff",
    "green":   "#3fb950",
    "red":     "#f85149",
    "yellow":  "#d29922",
    "purple":  "#bc8cff",
    "text":    "#c9d1d9",
    "subtext": "#8b949e",
}
EMOTION_COLORS = [
    "#58a6ff","#3fb950","#f85149","#d29922",
    "#bc8cff","#ff7b72","#ffa657","#39d353"
]

# ─────────────────────────────────────────────────────────────────────────────
# 1. SYNTHETIC FEATURE EXTRACTION
#    Simulates librosa's feature extraction output without requiring audio files.
#    Each emotion has unique statistical fingerprints based on psychoacoustics.
# ─────────────────────────────────────────────────────────────────────────────

EMOTION_PROFILES = {
    #              mean_mfcc  std_mfcc  chroma_mean  zcr_mean   rmse_mean  tempo
    "neutral":    (0.0,       1.0,      0.50,        0.06,      0.05,      90),
    "calm":       (-0.3,      0.7,      0.45,        0.04,      0.03,      70),
    "happy":      (0.5,       1.3,      0.65,        0.10,      0.09,     120),
    "sad":        (-0.6,      0.8,      0.40,        0.03,      0.02,      60),
    "angry":      (0.8,       1.6,      0.55,        0.14,      0.14,     140),
    "fearful":    (0.2,       1.5,      0.48,        0.12,      0.07,     110),
    "disgust":    (-0.2,      1.1,      0.42,        0.08,      0.06,      85),
    "surprised":  (0.6,       1.4,      0.60,        0.11,      0.10,     130),
}

def simulate_audio_features(emotion: str, n_samples: int) -> np.ndarray:
    """
    Simulate librosa feature extraction for a given emotion.
    Returns array of shape (n_samples, feature_dim).

    Features:
      • 40 MFCCs (mean)       → 40 dims
      • 40 MFCCs (std)        → 40 dims
      • 12 Chroma (mean)      → 12 dims
      • 128 Mel-bands (mean)  → 128 dims (compressed to 32 via PCA-like projection)
      • ZCR                   →  1 dim
      • RMSE                  →  1 dim
      • Tempo                 →  1 dim
    Total: 127 features
    """
    p = EMOTION_PROFILES[emotion]
    mu, sig, chroma_mu, zcr_mu, rmse_mu, tempo = p

    mfcc_mean  = np.random.normal(mu,       sig,        (n_samples, N_MFCC))
    mfcc_std   = np.abs(np.random.normal(sig, sig*0.2,  (n_samples, N_MFCC)))
    chroma     = np.random.normal(chroma_mu, 0.08,       (n_samples, 12)).clip(0,1)
    mel_bands  = np.abs(np.random.normal(rmse_mu*10, 0.5,(n_samples, 32)))
    zcr        = np.abs(np.random.normal(zcr_mu,  0.01,  (n_samples, 1)))
    rmse       = np.abs(np.random.normal(rmse_mu, 0.01,  (n_samples, 1)))
    tempo_feat = np.random.normal(tempo, 8,               (n_samples, 1))

    # inter-emotion confusion noise (real-world effect)
    noise_scale = 0.15
    mfcc_mean += np.random.normal(0, noise_scale, mfcc_mean.shape)

    features = np.hstack([mfcc_mean, mfcc_std, chroma, mel_bands, zcr, rmse, tempo_feat])
    return features.astype(np.float32)

def build_dataset():
    print("  Simulating RAVDESS-style feature extraction …")
    X_list, y_list = [], []
    for emo in EMOTIONS:
        feats = simulate_audio_features(emo, N_SAMPLES)
        X_list.append(feats)
        y_list.extend([emo] * N_SAMPLES)
    X = np.vstack(X_list)
    y = np.array(y_list)
    print(f"  Dataset shape: {X.shape} | Classes: {len(EMOTIONS)}")
    return X, y

FEATURE_DIM = N_MFCC*2 + 12 + 32 + 3   # = 127


# ─────────────────────────────────────────────────────────────────────────────
# 2. PREPROCESSING
# ─────────────────────────────────────────────────────────────────────────────

def preprocess(X, y):
    le = LabelEncoder()
    y_enc = le.fit_transform(y)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    X_tr, X_te, y_tr, y_te = train_test_split(
        X_scaled, y_enc, test_size=0.20, stratify=y_enc, random_state=RANDOM_SEED
    )
    X_val_tr, X_val, y_val_tr, y_val = train_test_split(
        X_tr, y_tr, test_size=0.15, stratify=y_tr, random_state=RANDOM_SEED
    )
    return X_tr, X_val_tr, X_val, X_te, y_tr, y_val_tr, y_val, y_te, le, scaler


# ─────────────────────────────────────────────────────────────────────────────
# 3. MODELS
# ─────────────────────────────────────────────────────────────────────────────

def build_cnn_model(input_dim, n_classes):
    """
    1-D CNN treating the feature vector as a sequence of channels.
    Conv1D → BN → Dropout → GlobalAvgPool → Dense
    """
    inp = keras.Input(shape=(input_dim, 1), name="features")

    x = layers.Conv1D(64, 5, padding="same", activation="relu",
                      kernel_regularizer=regularizers.l2(1e-4))(inp)
    x = layers.BatchNormalization()(x)
    x = layers.Conv1D(128, 3, padding="same", activation="relu",
                      kernel_regularizer=regularizers.l2(1e-4))(x)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling1D(2)(x)
    x = layers.Dropout(0.3)(x)

    x = layers.Conv1D(256, 3, padding="same", activation="relu",
                      kernel_regularizer=regularizers.l2(1e-4))(x)
    x = layers.BatchNormalization()(x)
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dropout(0.4)(x)

    x = layers.Dense(128, activation="relu")(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(n_classes, activation="softmax", name="emotion")(x)

    model = keras.Model(inp, out, name="EmotionCNN")
    model.compile(
        optimizer=keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


def build_lstm_model(input_dim, n_classes):
    """
    Bidirectional LSTM over feature sequence.
    """
    inp = keras.Input(shape=(input_dim, 1), name="features")
    x = layers.Bidirectional(layers.LSTM(128, return_sequences=True))(inp)
    x = layers.Dropout(0.3)(x)
    x = layers.Bidirectional(layers.LSTM(64))(x)
    x = layers.Dropout(0.3)(x)
    x = layers.Dense(64, activation="relu")(x)
    out = layers.Dense(n_classes, activation="softmax", name="emotion")(x)
    model = keras.Model(inp, out, name="EmotionLSTM")
    model.compile(
        optimizer=keras.optimizers.Adam(8e-4),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


# ─────────────────────────────────────────────────────────────────────────────
# 4. TRAINING
# ─────────────────────────────────────────────────────────────────────────────

def train_dl_model(model, X_tr, y_tr, X_val, y_val, epochs=60, batch=64):
    cb = [
        callbacks.EarlyStopping(monitor="val_accuracy", patience=12,
                                restore_best_weights=True, verbose=0),
        callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                                    patience=5, min_lr=1e-6, verbose=0),
    ]
    history = model.fit(
        X_tr[..., np.newaxis], y_tr,
        validation_data=(X_val[..., np.newaxis], y_val),
        epochs=epochs, batch_size=batch,
        callbacks=cb, verbose=1
    )
    return history

def train_ml_models(X_tr, y_tr):
    svm = SVC(kernel="rbf", C=5, gamma="scale", probability=True, random_state=RANDOM_SEED)
    svm.fit(X_tr, y_tr)
    rf  = RandomForestClassifier(n_estimators=300, max_depth=12,
                                  class_weight="balanced", random_state=RANDOM_SEED, n_jobs=-1)
    rf.fit(X_tr, y_tr)
    return {"SVM": svm, "Random Forest": rf}


# ─────────────────────────────────────────────────────────────────────────────
# 5. VISUALISATIONS
# ─────────────────────────────────────────────────────────────────────────────

def style_ax(ax, title=""):
    ax.set_facecolor(PALETTE["panel"])
    ax.tick_params(colors=PALETTE["subtext"], labelsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor("#30363d")
    if title:
        ax.set_title(title, color=PALETTE["text"], fontsize=10, fontweight="bold", pad=8)

def plot_training(history_cnn, history_lstm, X_te, y_te,
                  cnn_model, lstm_model, ml_models, le, out_dir):

    fig = plt.figure(figsize=(22, 18), facecolor=PALETTE["bg"])
    fig.suptitle("Emotion Recognition from Speech — Dashboard",
                 color=PALETTE["text"], fontsize=18, fontweight="bold", y=0.98)
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.5, wspace=0.4)

    # Training curves — accuracy
    ax1 = fig.add_subplot(gs[0, :2])
    style_ax(ax1, "Training / Validation Accuracy")
    ax1.plot(history_cnn.history["accuracy"],     color=PALETTE["accent"],  lw=2, label="CNN train")
    ax1.plot(history_cnn.history["val_accuracy"], color=PALETTE["accent"],  lw=2, ls="--", label="CNN val")
    ax1.plot(history_lstm.history["accuracy"],    color=PALETTE["green"],   lw=2, label="LSTM train")
    ax1.plot(history_lstm.history["val_accuracy"],color=PALETTE["green"],   lw=2, ls="--", label="LSTM val")
    ax1.set_xlabel("Epoch", color=PALETTE["subtext"], fontsize=9)
    ax1.set_ylabel("Accuracy", color=PALETTE["subtext"], fontsize=9)
    ax1.legend(fontsize=8, framealpha=0.3, labelcolor=PALETTE["text"])
    ax1.set_ylim(0, 1)

    # Training curves — loss
    ax2 = fig.add_subplot(gs[0, 2:])
    style_ax(ax2, "Training / Validation Loss")
    ax2.plot(history_cnn.history["loss"],     color=PALETTE["accent"], lw=2, label="CNN train")
    ax2.plot(history_cnn.history["val_loss"], color=PALETTE["accent"], lw=2, ls="--", label="CNN val")
    ax2.plot(history_lstm.history["loss"],    color=PALETTE["green"],  lw=2, label="LSTM train")
    ax2.plot(history_lstm.history["val_loss"],color=PALETTE["green"],  lw=2, ls="--", label="LSTM val")
    ax2.set_xlabel("Epoch", color=PALETTE["subtext"], fontsize=9)
    ax2.set_ylabel("Loss",  color=PALETTE["subtext"], fontsize=9)
    ax2.legend(fontsize=8, framealpha=0.3, labelcolor=PALETTE["text"])

    # Confusion matrix — CNN (best DL model)
    y_pred_cnn = np.argmax(cnn_model.predict(X_te[..., np.newaxis], verbose=0), axis=1)
    cm = confusion_matrix(y_te, y_pred_cnn)
    ax3 = fig.add_subplot(gs[1, :2])
    style_ax(ax3, "Confusion Matrix — CNN")
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax3, cbar=False,
                xticklabels=le.classes_, yticklabels=le.classes_,
                annot_kws={"size": 7})
    ax3.tick_params(axis="x", rotation=30, colors=PALETTE["subtext"], labelsize=7)
    ax3.tick_params(axis="y", rotation=0,  colors=PALETTE["subtext"], labelsize=7)

    # Confusion matrix — LSTM
    y_pred_lstm = np.argmax(lstm_model.predict(X_te[..., np.newaxis], verbose=0), axis=1)
    cm_lstm = confusion_matrix(y_te, y_pred_lstm)
    ax4 = fig.add_subplot(gs[1, 2:])
    style_ax(ax4, "Confusion Matrix — LSTM")
    sns.heatmap(cm_lstm, annot=True, fmt="d", cmap="Greens", ax=ax4, cbar=False,
                xticklabels=le.classes_, yticklabels=le.classes_,
                annot_kws={"size": 7})
    ax4.tick_params(axis="x", rotation=30, colors=PALETTE["subtext"], labelsize=7)
    ax4.tick_params(axis="y", rotation=0,  colors=PALETTE["subtext"], labelsize=7)

    # Model accuracy comparison bar
    ax5 = fig.add_subplot(gs[2, :2])
    style_ax(ax5, "Model Accuracy Comparison")
    model_names, accs, f1s = [], [], []
    for mname, mobj in {**ml_models, "CNN": cnn_model, "LSTM": lstm_model}.items():
        if mname in ("CNN", "LSTM"):
            yp = np.argmax(mobj.predict(X_te[..., np.newaxis], verbose=0), axis=1)
        else:
            yp = mobj.predict(X_te)
        model_names.append(mname)
        accs.append(accuracy_score(y_te, yp))
        f1s.append(f1_score(y_te, yp, average="macro", zero_division=0))
    x = np.arange(len(model_names))
    ax5.bar(x - 0.2, accs, 0.4, label="Accuracy", color=PALETTE["accent"],  alpha=0.85)
    ax5.bar(x + 0.2, f1s,  0.4, label="F1-Macro", color=PALETTE["yellow"],  alpha=0.85)
    ax5.set_xticks(x)
    ax5.set_xticklabels(model_names, color=PALETTE["subtext"], fontsize=9)
    ax5.set_ylim(0, 1.15)
    ax5.legend(fontsize=9, framealpha=0.3, labelcolor=PALETTE["text"])
    ax5.set_ylabel("Score", color=PALETTE["subtext"], fontsize=9)

    # Feature heatmap — mean MFCC per emotion
    ax6 = fig.add_subplot(gs[2, 2:])
    style_ax(ax6, "Mean MFCC Features per Emotion")
    mfcc_matrix = np.array([
        EMOTION_PROFILES[e][0] * np.ones(20) +
        np.random.normal(0, 0.1, 20) * EMOTION_PROFILES[e][1]
        for e in EMOTIONS
    ])
    sns.heatmap(mfcc_matrix, ax=ax6, cmap="coolwarm", cbar_kws={"shrink": 0.8},
                xticklabels=[f"M{i+1}" for i in range(20)],
                yticklabels=EMOTIONS)
    ax6.tick_params(axis="x", colors=PALETTE["subtext"], labelsize=7)
    ax6.tick_params(axis="y", colors=PALETTE["subtext"], labelsize=7, rotation=0)

    plt.savefig(os.path.join(out_dir, "emotion_recognition_dashboard.png"),
                dpi=150, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close()
    print("  ✓ Dashboard saved → emotion_recognition_dashboard.png")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    out_dir = os.path.dirname(os.path.abspath(__file__))

    print("\n" + "="*60)
    print("  TASK 2 — EMOTION RECOGNITION FROM SPEECH")
    print("="*60)

    # — Build dataset —
    print("\n[1/5] Building feature dataset (RAVDESS-style) …")
    X, y = build_dataset()

    # — Preprocess —
    print("\n[2/5] Preprocessing & splitting …")
    X_tr, X_vtr, X_val, X_te, y_tr, y_vtr, y_val, y_te, le, scaler = preprocess(X, y)
    n_classes = len(EMOTIONS)

    # — Traditional ML —
    print("\n[3/5] Training ML baselines (SVM, Random Forest) …")
    ml_models = train_ml_models(X_tr, y_tr)
    for mname, mobj in ml_models.items():
        yp  = mobj.predict(X_te)
        acc = accuracy_score(y_te, yp)
        f1  = f1_score(y_te, yp, average="macro", zero_division=0)
        print(f"  {mname:<16}: Accuracy={acc:.4f}  F1-Macro={f1:.4f}")
        print(classification_report(y_te, yp, target_names=le.classes_, zero_division=0))

    # — Deep Learning —
    print("\n[4/5] Training CNN …")
    cnn  = build_cnn_model(FEATURE_DIM, n_classes)
    print(cnn.summary())
    history_cnn = train_dl_model(cnn, X_vtr, y_vtr, X_val, y_val)

    print("\n  Training LSTM …")
    lstm = build_lstm_model(FEATURE_DIM, n_classes)
    history_lstm = train_dl_model(lstm, X_vtr, y_vtr, X_val, y_val)

    # — Evaluate —
    print("\n── Deep Learning Evaluation ──")
    for mname, mobj in {"CNN": cnn, "LSTM": lstm}.items():
        yp  = np.argmax(mobj.predict(X_te[..., np.newaxis], verbose=0), axis=1)
        acc = accuracy_score(y_te, yp)
        f1  = f1_score(y_te, yp, average="macro", zero_division=0)
        print(f"\n  {mname}: Accuracy={acc:.4f}  F1-Macro={f1:.4f}")
        print(classification_report(y_te, yp, target_names=le.classes_, zero_division=0))

    # — Save models —
    cnn.save(os.path.join(out_dir,  "emotion_cnn.keras"))
    lstm.save(os.path.join(out_dir, "emotion_lstm.keras"))
    print("  ✓ Models saved")

    # — Plots —
    print("\n[5/5] Generating visualisations …")
    plot_training(history_cnn, history_lstm, X_te, y_te,
                  cnn, lstm, ml_models, le, out_dir)

    # — Demo prediction —
    print("\n── Demo: Predict emotion for a new audio sample ──")
    sample = simulate_audio_features("happy", 1)
    sample_scaled = scaler.transform(sample)
    pred_idx = np.argmax(cnn.predict(sample_scaled[..., np.newaxis], verbose=0), axis=1)[0]
    probs    = cnn.predict(sample_scaled[..., np.newaxis], verbose=0)[0]
    print(f"  True emotion   : happy")
    print(f"  Predicted      : {le.classes_[pred_idx]}")
    print(f"  Top-3 probs    :")
    for idx in np.argsort(probs)[::-1][:3]:
        print(f"    {le.classes_[idx]:<12}: {probs[idx]:.3f}")

    print("\n✅ Task 2 complete!\n")

if __name__ == "__main__":
    main()