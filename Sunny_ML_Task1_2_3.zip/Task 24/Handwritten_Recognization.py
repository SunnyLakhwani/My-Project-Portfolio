import warnings
warnings.filterwarnings("ignore")
import os; os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
import seaborn as sns

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, callbacks, regularizers
from tensorflow.keras.datasets import mnist
from tensorflow.keras.preprocessing.image import ImageDataGenerator

from sklearn.metrics import (
    classification_report, confusion_matrix,
    accuracy_score, f1_score
)

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)

PALETTE = {
    "bg":      "#0d1117",
    "panel":   "#161b22",
    "accent":  "#58a6ff",
    "green":   "#3fb950",
    "red":     "#f85149",
    "yellow":  "#d29922",
    "purple":  "#bc8cff",
    "text":    "#c9d1d9",
    "subtext": "#8b949e",
}


# ─────────────────────────────────────────────────────────────────────────────
# 1. DATA LOADING & AUGMENTATION
# ─────────────────────────────────────────────────────────────────────────────

def load_mnist():
    """Load MNIST, normalise, reshape, one-hot encode."""
    (X_train, y_train), (X_test, y_test) = mnist.load_data()
    X_train = X_train.astype("float32") / 255.0
    X_test  = X_test.astype("float32")  / 255.0
    # add channel dim
    X_train = X_train[..., np.newaxis]
    X_test  = X_test[..., np.newaxis]
    print(f"  Train: {X_train.shape}  Test: {X_test.shape}")
    return X_train, X_test, y_train, y_test


def get_augmentor():
    """Realistic handwriting-specific augmentations."""
    return ImageDataGenerator(
        rotation_range=12,
        width_shift_range=0.12,
        height_shift_range=0.12,
        zoom_range=0.10,
        shear_range=0.10,
        fill_mode="nearest",
        validation_split=0.10,
    )


# ─────────────────────────────────────────────────────────────────────────────
# 2. MODEL — DEEP CNN WITH RESIDUAL-STYLE BLOCK
# ─────────────────────────────────────────────────────────────────────────────

def residual_block(x, filters, kernel=3):
    """A lightweight residual block with skip connection."""
    shortcut = x
    x = layers.Conv2D(filters, kernel, padding="same",
                      kernel_regularizer=regularizers.l2(1e-4))(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation("relu")(x)
    x = layers.Conv2D(filters, kernel, padding="same",
                      kernel_regularizer=regularizers.l2(1e-4))(x)
    x = layers.BatchNormalization()(x)
    # project shortcut if channels differ
    if shortcut.shape[-1] != filters:
        shortcut = layers.Conv2D(filters, 1, padding="same")(shortcut)
    x = layers.Add()([x, shortcut])
    x = layers.Activation("relu")(x)
    return x


def build_cnn(input_shape=(28, 28, 1), n_classes=10):
    """
    Architecture:
      Conv(32) → ResBlock(64) → MaxPool → Dropout
              → ResBlock(128) → MaxPool → Dropout
              → ResBlock(256) → GlobalAvgPool
              → Dense(256) → Dense(n_classes)
    ~1.2M parameters — strong but not overweight for MNIST.
    """
    inp = keras.Input(shape=input_shape, name="image")

    x = layers.Conv2D(32, 3, padding="same", activation="relu",
                      kernel_regularizer=regularizers.l2(1e-4))(inp)
    x = layers.BatchNormalization()(x)

    x = residual_block(x, 64)
    x = layers.MaxPooling2D(2)(x)
    x = layers.Dropout(0.25)(x)

    x = residual_block(x, 128)
    x = layers.MaxPooling2D(2)(x)
    x = layers.Dropout(0.30)(x)

    x = residual_block(x, 256)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.40)(x)

    x = layers.Dense(256, activation="relu",
                     kernel_regularizer=regularizers.l2(1e-4))(x)
    x = layers.Dropout(0.30)(x)
    out = layers.Dense(n_classes, activation="softmax", name="digit")(x)

    model = keras.Model(inp, out, name="HandwrittenCNN")
    model.compile(
        optimizer=keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


# ─────────────────────────────────────────────────────────────────────────────
# 3. TRAINING
# ─────────────────────────────────────────────────────────────────────────────

def train(model, X_train, y_train, out_dir, epochs=30, batch=128):
    aug = get_augmentor()
    train_gen = aug.flow(X_train, y_train, batch_size=batch,
                         subset="training", seed=RANDOM_SEED)
    val_gen   = aug.flow(X_train, y_train, batch_size=batch,
                         subset="validation", seed=RANDOM_SEED)

    ckpt_path = os.path.join(out_dir, "best_model.keras")
    cb = [
        callbacks.EarlyStopping(monitor="val_accuracy", patience=10,
                                restore_best_weights=True, verbose=1),
        callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5,
                                    patience=4, min_lr=1e-6, verbose=1),
        callbacks.ModelCheckpoint(ckpt_path, monitor="val_accuracy",
                                  save_best_only=True, verbose=0),
    ]
    history = model.fit(
        train_gen,
        validation_data=val_gen,
        epochs=epochs,
        steps_per_epoch=len(X_train) * 0.9 // batch,
        validation_steps=len(X_train) * 0.1 // batch,
        callbacks=cb,
        verbose=1,
    )
    return history, ckpt_path


# ─────────────────────────────────────────────────────────────────────────────
# 4. GRAD-CAM (saliency)
# ─────────────────────────────────────────────────────────────────────────────

def grad_cam(model, image, class_idx, last_conv_layer="conv2d_2"):
    """Compute Grad-CAM heatmap for given image & class."""
    grad_model = keras.Model(
        inputs=model.inputs,
        outputs=[model.get_layer(last_conv_layer).output, model.output]
    )
    image_batch = image[np.newaxis, ...]
    with tf.GradientTape() as tape:
        conv_outputs, preds = grad_model(image_batch, training=False)
        loss = preds[:, class_idx]
    grads       = tape.gradient(loss, conv_outputs)[0]
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1))
    conv_out    = conv_outputs[0]
    heatmap     = conv_out @ pooled_grads[..., tf.newaxis]
    heatmap     = tf.squeeze(heatmap).numpy()
    heatmap     = np.maximum(heatmap, 0)
    if heatmap.max() > 0:
        heatmap /= heatmap.max()
    return heatmap


# ─────────────────────────────────────────────────────────────────────────────
# 5. VISUALISATIONS
# ─────────────────────────────────────────────────────────────────────────────

def style_ax(ax, title=""):
    ax.set_facecolor(PALETTE["panel"])
    ax.tick_params(colors=PALETTE["subtext"], labelsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor("#30363d")
    if title:
        ax.set_title(title, color=PALETTE["text"], fontsize=10, fontweight="bold", pad=8)

def plot_results(history, model, X_test, y_test, y_pred, out_dir):
    class_names = [str(i) for i in range(10)]

    fig = plt.figure(figsize=(22, 18), facecolor=PALETTE["bg"])
    fig.suptitle("Handwritten Character Recognition — CNN Dashboard",
                 color=PALETTE["text"], fontsize=18, fontweight="bold", y=0.98)
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.5, wspace=0.4)

    # ── Training curves ───────────────────────────────────────────────────
    ax1 = fig.add_subplot(gs[0, :2])
    style_ax(ax1, "Accuracy over Epochs")
    ax1.plot(history.history["accuracy"],     color=PALETTE["accent"], lw=2, label="Train")
    ax1.plot(history.history["val_accuracy"], color=PALETTE["green"],  lw=2, ls="--", label="Val")
    ax1.set_xlabel("Epoch", color=PALETTE["subtext"], fontsize=9)
    ax1.set_ylabel("Accuracy", color=PALETTE["subtext"], fontsize=9)
    ax1.legend(fontsize=9, framealpha=0.3, labelcolor=PALETTE["text"])
    ax1.set_ylim(0.8, 1.01)

    ax2 = fig.add_subplot(gs[0, 2:])
    style_ax(ax2, "Loss over Epochs")
    ax2.plot(history.history["loss"],     color=PALETTE["accent"], lw=2, label="Train")
    ax2.plot(history.history["val_loss"], color=PALETTE["green"],  lw=2, ls="--", label="Val")
    ax2.set_xlabel("Epoch", color=PALETTE["subtext"], fontsize=9)
    ax2.set_ylabel("Loss",  color=PALETTE["subtext"], fontsize=9)
    ax2.legend(fontsize=9, framealpha=0.3, labelcolor=PALETTE["text"])

    # ── Confusion matrix ──────────────────────────────────────────────────
    ax3 = fig.add_subplot(gs[1, :2])
    style_ax(ax3, "Confusion Matrix (Test Set)")
    cm = confusion_matrix(y_test, y_pred)
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True)
    sns.heatmap(cm_norm, annot=cm, fmt="d", cmap="Blues", ax=ax3, cbar=False,
                xticklabels=class_names, yticklabels=class_names,
                annot_kws={"size": 8})
    ax3.set_xlabel("Predicted", color=PALETTE["subtext"], fontsize=9)
    ax3.set_ylabel("True",      color=PALETTE["subtext"], fontsize=9)
    ax3.tick_params(colors=PALETTE["subtext"])

    # ── Per-class F1 ──────────────────────────────────────────────────────
    ax4 = fig.add_subplot(gs[1, 2:])
    style_ax(ax4, "Per-Class F1 Score")
    f1_per = f1_score(y_test, y_pred, average=None, zero_division=0)
    colors = [PALETTE["green"] if v >= 0.99 else
              PALETTE["yellow"] if v >= 0.97 else
              PALETTE["red"] for v in f1_per]
    ax4.bar(class_names, f1_per, color=colors, alpha=0.9)
    ax4.set_xlabel("Digit", color=PALETTE["subtext"], fontsize=9)
    ax4.set_ylabel("F1 Score", color=PALETTE["subtext"], fontsize=9)
    ax4.set_ylim(0.9, 1.01)
    for i, v in enumerate(f1_per):
        ax4.text(i, v + 0.001, f"{v:.3f}", ha="center",
                 color=PALETTE["text"], fontsize=7)

    # ── Sample predictions ────────────────────────────────────────────────
    ax5 = fig.add_subplot(gs[2, :2])
    ax5.set_facecolor(PALETTE["panel"])
    ax5.set_title("Sample Predictions (green=correct, red=wrong)",
                  color=PALETTE["text"], fontsize=10, fontweight="bold", pad=8)
    ax5.axis("off")

    # pick a mix of correct and wrong
    wrong_idx   = np.where(y_pred != y_test)[0][:8]
    correct_idx = np.where(y_pred == y_test)[0][:8]
    sample_idx  = np.concatenate([correct_idx[:8], wrong_idx[:8]])

    inner = gridspec.GridSpecFromSubplotSpec(2, 16, subplot_spec=gs[2, :2],
                                             hspace=0.05, wspace=0.05)
    for i, idx in enumerate(sample_idx[:16]):
        sub_ax = fig.add_subplot(inner[i // 8, i % 8])
        sub_ax.imshow(X_test[idx, :, :, 0], cmap="gray")
        correct = y_pred[idx] == y_test[idx]
        col = PALETTE["green"] if correct else PALETTE["red"]
        sub_ax.set_title(f"P:{y_pred[idx]}\nT:{y_test[idx]}",
                         color=col, fontsize=6, pad=1)
        sub_ax.axis("off")
        sub_ax.set_facecolor(PALETTE["panel"])

    # ── Grad-CAM saliency ────────────────────────────────────────────────
    # find last conv layer name
    conv_names = [l.name for l in model.layers if "conv2d" in l.name]
    last_conv  = conv_names[-1] if conv_names else None

    ax6 = fig.add_subplot(gs[2, 2:])
    ax6.set_facecolor(PALETTE["panel"])
    ax6.set_title("Grad-CAM Saliency — What the CNN focuses on",
                  color=PALETTE["text"], fontsize=10, fontweight="bold", pad=8)
    ax6.axis("off")

    if last_conv:
        inner2 = gridspec.GridSpecFromSubplotSpec(2, 5, subplot_spec=gs[2, 2:],
                                                   hspace=0.1, wspace=0.1)
        # pick one sample per digit 0-9
        for digit in range(10):
            digit_idx = np.where(y_test == digit)[0][0]
            img = X_test[digit_idx]
            try:
                heatmap = grad_cam(model, img, digit, last_conv)
                heatmap_resized = np.array(
                    tf.image.resize(heatmap[..., np.newaxis], (28, 28))
                ).squeeze()
                overlay = img[:, :, 0] * 0.5 + heatmap_resized * 0.5
            except Exception:
                overlay = img[:, :, 0]
            sub_ax = fig.add_subplot(inner2[digit // 5, digit % 5])
            sub_ax.imshow(overlay, cmap="hot")
            sub_ax.set_title(f"Digit {digit}", color=PALETTE["text"], fontsize=7, pad=1)
            sub_ax.axis("off")
            sub_ax.set_facecolor(PALETTE["panel"])

    plt.savefig(os.path.join(out_dir, "handwriting_recognition_dashboard.png"),
                dpi=150, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close()
    print("  ✓ Dashboard saved → handwriting_recognition_dashboard.png")


# ─────────────────────────────────────────────────────────────────────────────
# 6. EXTENDED — SYNTHETIC LETTERS (A-Z simulation)
# ─────────────────────────────────────────────────────────────────────────────

def demo_letter_recognition_note():
    """
    Note on extension to full EMNIST (letters A-Z):
    The EMNIST dataset follows the exact same API as MNIST.
    To extend this model to letters, replace:

        from tensorflow.keras.datasets import mnist
        (X_train, y_train), (X_test, y_test) = mnist.load_data()

    with:
        import tensorflow_datasets as tfds
        ds = tfds.load('emnist/letters', split=['train','test'], as_supervised=True)

    The CNN architecture is unchanged — just set n_classes=26.
    For full word/sentence recognition, combine this CNN encoder
    with a CTC-based CRNN (Connectionist Temporal Classification):
        CNN (feature extractor) → Reshape → Bidirectional LSTM → CTC loss
    """
    print("\n  ℹ Extension note: EMNIST letters or CRNN for words")
    print("    → Load EMNIST dataset, set n_classes=26")
    print("    → For word recognition: CNN + BiLSTM + CTC loss (CRNN)")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    out_dir = os.path.dirname(os.path.abspath(__file__))

    print("\n" + "="*60)
    print("  TASK 3 — HANDWRITTEN CHARACTER RECOGNITION")
    print("="*60)

    # — Data —
    print("\n[1/4] Loading MNIST …")
    X_train, X_test, y_train, y_test = load_mnist()

    # — Model —
    print("\n[2/4] Building CNN model …")
    model = build_cnn(input_shape=(28, 28, 1), n_classes=10)
    model.summary()

    # — Train —
    print("\n[3/4] Training with augmentation …")
    history, ckpt_path = train(model, X_train, y_train, out_dir, epochs=30, batch=128)

    # load best checkpoint
    model = keras.models.load_model(ckpt_path)

    # — Evaluate —
    print("\n── Test Set Evaluation ──")
    y_proba = model.predict(X_test, verbose=0)
    y_pred  = np.argmax(y_proba, axis=1)

    acc = accuracy_score(y_test, y_pred)
    f1  = f1_score(y_test, y_pred, average="macro", zero_division=0)
    print(f"\n  Test Accuracy : {acc:.4f}")
    print(f"  F1-Macro      : {f1:.4f}")
    print("\n" + classification_report(y_test, y_pred,
          target_names=[str(i) for i in range(10)], zero_division=0))

    # — Plot —
    print("\n[4/4] Generating visualisations …")
    plot_results(history, model, X_test, y_test, y_pred, out_dir)

    # — Demo —
    print("\n── Demo: Predict a random test sample ──")
    i   = np.random.randint(0, len(X_test))
    p   = np.argmax(model.predict(X_test[i:i+1], verbose=0))
    print(f"  True digit     : {y_test[i]}")
    print(f"  Predicted      : {p}")
    print(f"  Correct        : {'✅' if p == y_test[i] else '❌'}")

    # — Extension note —
    demo_letter_recognition_note()

    print("\n✅ Task 3 complete!\n")


if __name__ == "__main__":
    main()