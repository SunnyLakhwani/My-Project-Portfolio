import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
import seaborn as sns

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, roc_curve, confusion_matrix, classification_report
)
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.calibration import CalibratedClassifierCV
import xgboost as xgb
from imblearn.over_sampling import SMOTE

import os, sys

# ─────────────────────────────────────────────────────────────────────────────
# 1. SYNTHETIC DATASET GENERATION
# ─────────────────────────────────────────────────────────────────────────────

np.random.seed(42)

def generate_credit_dataset(n=5000):
    """
    Generate a realistic, skewed credit dataset mimicking real-world
    class imbalance (~25% defaulters, ~75% non-defaulters).
    """
    n_default    = int(n * 0.25)
    n_no_default = n - n_default

    def sample_group(size, is_default):
        age            = np.random.randint(22, 65, size)
        income         = np.random.normal(45000 if is_default else 72000, 15000, size).clip(10000, 250000)
        employment_yrs = np.random.exponential(3 if is_default else 7, size).clip(0, 35)
        num_accounts   = np.random.randint(1, 6 if is_default else 12, size)
        credit_util    = np.random.beta(4 if is_default else 1.5, 2, size)   # utilisation ratio
        debt_total     = income * np.random.uniform(0.4, 1.2 if is_default else 0.3, size)
        monthly_payment= debt_total / np.random.randint(12, 60, size)
        late_payments  = np.random.poisson(3 if is_default else 0.3, size)
        credit_score   = np.random.normal(580 if is_default else 720, 60, size).clip(300, 850)
        num_inquiries  = np.random.poisson(4 if is_default else 1, size)
        loan_amount    = np.random.uniform(1000, 50000, size)
        loan_term      = np.random.choice([12, 24, 36, 48, 60], size)

        return {
            "age":             age,
            "annual_income":   income.astype(int),
            "employment_years":employment_yrs.round(1),
            "num_accounts":    num_accounts,
            "credit_utilisation": credit_util.round(3),
            "total_debt":      debt_total.astype(int),
            "monthly_payment": monthly_payment.round(2),
            "late_payments":   late_payments,
            "credit_score":    credit_score.astype(int),
            "num_inquiries":   num_inquiries,
            "loan_amount":     loan_amount.astype(int),
            "loan_term_months":loan_term,
            "default":         np.ones(size, dtype=int) if is_default else np.zeros(size, dtype=int),
        }

    df_default    = pd.DataFrame(sample_group(n_default,    True))
    df_no_default = pd.DataFrame(sample_group(n_no_default, False))
    df = pd.concat([df_default, df_no_default], ignore_index=True).sample(frac=1, random_state=42)

    # introduce ~2% missing values realistically
    for col in ["employment_years", "credit_score", "num_inquiries"]:
        mask = np.random.rand(len(df)) < 0.02
        df.loc[mask, col] = np.nan

    return df.reset_index(drop=True)


# ─────────────────────────────────────────────────────────────────────────────
# 2. FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────────────────────────

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["debt_to_income"]        = (df["total_debt"] / df["annual_income"]).round(3)
    df["payment_to_income"]     = (df["monthly_payment"] * 12 / df["annual_income"]).round(3)
    df["loan_to_income"]        = (df["loan_amount"] / df["annual_income"]).round(3)
    df["risk_index"]            = (
        df["credit_utilisation"] * 0.35
        + (df["late_payments"].clip(0, 10) / 10) * 0.35
        + (df["num_inquiries"].clip(0, 10) / 10) * 0.15
        + (df["debt_to_income"].clip(0, 3) / 3) * 0.15
    ).round(4)
    df["credit_score_band"]     = pd.cut(
        df["credit_score"].fillna(df["credit_score"].median()),
        bins=[300, 579, 669, 739, 799, 850],
        labels=[0, 1, 2, 3, 4]
    ).astype(float)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# 3. PREPROCESSING PIPELINE
# ─────────────────────────────────────────────────────────────────────────────

FEATURE_COLS = [
    "age", "annual_income", "employment_years", "num_accounts",
    "credit_utilisation", "total_debt", "monthly_payment",
    "late_payments", "credit_score", "num_inquiries",
    "loan_amount", "loan_term_months",
    "debt_to_income", "payment_to_income", "loan_to_income",
    "risk_index", "credit_score_band",
]

def build_preprocessor():
    from sklearn.pipeline import Pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
    return Pipeline([
        ("impute", SimpleImputer(strategy="median")),
        ("scale",  StandardScaler()),
    ])


# ─────────────────────────────────────────────────────────────────────────────
# 4. MODEL DEFINITIONS
# ─────────────────────────────────────────────────────────────────────────────

def get_models():
    return {
        "Logistic Regression": LogisticRegression(
            C=0.5, solver="lbfgs", max_iter=1000, class_weight="balanced", random_state=42
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=300, max_depth=10, min_samples_leaf=5,
            class_weight="balanced", random_state=42, n_jobs=-1
        ),
        "XGBoost": xgb.XGBClassifier(
            n_estimators=300, max_depth=6, learning_rate=0.05,
            subsample=0.8, colsample_bytree=0.8,
            scale_pos_weight=3,          # handles class imbalance
            eval_metric="auc", use_label_encoder=False,
            random_state=42, verbosity=0
        ),
        "Gradient Boosting": GradientBoostingClassifier(
            n_estimators=200, max_depth=5, learning_rate=0.05,
            subsample=0.8, random_state=42
        ),
    }


# ─────────────────────────────────────────────────────────────────────────────
# 5. EVALUATION & TRAINING
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_model(name, model, X_train, y_train, X_test, y_test, preprocessor):
    pipe = Pipeline([("pre", preprocessor), ("clf", model)])
    pipe.fit(X_train, y_train)

    y_pred  = pipe.predict(X_test)
    y_proba = pipe.predict_proba(X_test)[:, 1]

    metrics = {
        "Accuracy":  accuracy_score(y_test, y_pred),
        "Precision": precision_score(y_test, y_pred, zero_division=0),
        "Recall":    recall_score(y_test, y_pred, zero_division=0),
        "F1-Score":  f1_score(y_test, y_pred, zero_division=0),
        "ROC-AUC":   roc_auc_score(y_test, y_proba),
    }

    # 5-fold cross-validation on ROC-AUC
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    cv_scores = cross_val_score(pipe, X_train, y_train, cv=cv, scoring="roc_auc")
    metrics["CV-AUC (mean)"] = cv_scores.mean()
    metrics["CV-AUC (std)"]  = cv_scores.std()

    fpr, tpr, _ = roc_curve(y_test, y_proba)
    cm = confusion_matrix(y_test, y_pred)

    print(f"\n{'─'*55}")
    print(f"  {name}")
    print(f"{'─'*55}")
    for k, v in metrics.items():
        print(f"  {k:<22}: {v:.4f}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['No Default','Default'])}")

    return pipe, metrics, fpr, tpr, cm, y_proba


# ─────────────────────────────────────────────────────────────────────────────
# 6. VISUALISATIONS
# ─────────────────────────────────────────────────────────────────────────────

PALETTE = {"bg": "#0d1117", "panel": "#161b22", "accent": "#58a6ff",
           "green": "#3fb950", "red": "#f85149", "yellow": "#d29922",
           "text": "#c9d1d9", "subtext": "#8b949e"}

def style_ax(ax, title=""):
    ax.set_facecolor(PALETTE["panel"])
    ax.tick_params(colors=PALETTE["subtext"], labelsize=8)
    for spine in ax.spines.values():
        spine.set_edgecolor("#30363d")
    if title:
        ax.set_title(title, color=PALETTE["text"], fontsize=10, fontweight="bold", pad=8)

def plot_results(results_dict, feature_names, rf_model_pipe, out_dir):
    fig = plt.figure(figsize=(22, 16), facecolor=PALETTE["bg"])
    fig.suptitle("Credit Scoring Model — Performance Dashboard",
                 color=PALETTE["text"], fontsize=18, fontweight="bold", y=0.98)

    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.45, wspace=0.4)

    # ── ROC curves ──────────────────────────────────────────────────────────
    ax_roc = fig.add_subplot(gs[0, :2])
    style_ax(ax_roc, "ROC Curves — All Models")
    colors = [PALETTE["accent"], PALETTE["green"], PALETTE["yellow"], "#bc8cff"]
    for (name, res), col in zip(results_dict.items(), colors):
        ax_roc.plot(res["fpr"], res["tpr"], lw=2, color=col,
                    label=f"{name}  (AUC={res['metrics']['ROC-AUC']:.3f})")
    ax_roc.plot([0,1],[0,1], "--", color=PALETTE["subtext"], lw=1)
    ax_roc.set_xlabel("False Positive Rate", color=PALETTE["subtext"], fontsize=9)
    ax_roc.set_ylabel("True Positive Rate",  color=PALETTE["subtext"], fontsize=9)
    ax_roc.legend(fontsize=8, framealpha=0.3, labelcolor=PALETTE["text"])

    # ── Metrics bar comparison ───────────────────────────────────────────────
    ax_bar = fig.add_subplot(gs[0, 2:])
    style_ax(ax_bar, "Model Comparison — Key Metrics")
    metric_names = ["Accuracy", "Precision", "Recall", "F1-Score", "ROC-AUC"]
    x = np.arange(len(metric_names))
    width = 0.18
    for i, (name, res) in enumerate(results_dict.items()):
        vals = [res["metrics"][m] for m in metric_names]
        bars = ax_bar.bar(x + i*width, vals, width, label=name, color=colors[i], alpha=0.85)
    ax_bar.set_xticks(x + width*1.5)
    ax_bar.set_xticklabels(metric_names, color=PALETTE["subtext"], fontsize=8)
    ax_bar.set_ylim(0, 1.15)
    ax_bar.legend(fontsize=7, framealpha=0.3, labelcolor=PALETTE["text"])
    ax_bar.set_ylabel("Score", color=PALETTE["subtext"], fontsize=9)

    # ── Confusion matrices (best model = XGBoost) ───────────────────────────
    best_name = max(results_dict, key=lambda k: results_dict[k]["metrics"]["ROC-AUC"])
    best_cm   = results_dict[best_name]["cm"]
    for idx, (name, res) in enumerate(results_dict.items()):
        ax_cm = fig.add_subplot(gs[1, idx])
        style_ax(ax_cm, f"CM — {name}")
        cm_norm = res["cm"].astype(float) / res["cm"].sum(axis=1, keepdims=True)
        sns.heatmap(cm_norm, annot=res["cm"], fmt="d", cmap="Blues",
                    ax=ax_cm, cbar=False,
                    xticklabels=["No Def","Def"], yticklabels=["No Def","Def"],
                    annot_kws={"size": 9, "color": "white"})
        ax_cm.tick_params(colors=PALETTE["subtext"], labelsize=7)

    # ── Feature importance (Random Forest) ──────────────────────────────────
    ax_fi = fig.add_subplot(gs[2, :2])
    style_ax(ax_fi, "Feature Importance — Random Forest")
    rf_clf = rf_model_pipe.named_steps["clf"]
    importances = rf_clf.feature_importances_
    indices = np.argsort(importances)[-12:]
    ax_fi.barh(range(len(indices)), importances[indices], color=PALETTE["accent"], alpha=0.85)
    ax_fi.set_yticks(range(len(indices)))
    ax_fi.set_yticklabels([feature_names[i] for i in indices],
                           color=PALETTE["subtext"], fontsize=8)
    ax_fi.set_xlabel("Importance", color=PALETTE["subtext"], fontsize=9)

    # ── CV AUC comparison ────────────────────────────────────────────────────
    ax_cv = fig.add_subplot(gs[2, 2:])
    style_ax(ax_cv, "5-Fold CV ROC-AUC Distribution")
    names_list = list(results_dict.keys())
    means = [results_dict[n]["metrics"]["CV-AUC (mean)"] for n in names_list]
    stds  = [results_dict[n]["metrics"]["CV-AUC (std)"]  for n in names_list]
    ax_cv.barh(names_list, means, xerr=stds, color=colors, alpha=0.85, height=0.5,
               error_kw=dict(ecolor=PALETTE["text"], capsize=4))
    ax_cv.set_xlim(0.5, 1.0)
    ax_cv.set_xlabel("AUC Score", color=PALETTE["subtext"], fontsize=9)
    ax_cv.set_yticklabels(names_list, color=PALETTE["subtext"], fontsize=8)

    plt.savefig(os.path.join(out_dir, "credit_scoring_dashboard.png"),
                dpi=150, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close()
    print(f"\n  ✓ Dashboard saved → credit_scoring_dashboard.png")


# ─────────────────────────────────────────────────────────────────────────────
# 7. CREDIT SCORE FUNCTION (practical utility)
# ─────────────────────────────────────────────────────────────────────────────

def predict_credit_risk(applicant: dict, pipe) -> dict:
    """
    Given a single applicant dict, return default probability + risk label.
    """
    df = pd.DataFrame([applicant])
    df = engineer_features(df)
    missing = [c for c in FEATURE_COLS if c not in df.columns]
    for m in missing:
        df[m] = 0
    prob = pipe.predict_proba(df[FEATURE_COLS])[0][1]
    label = "HIGH RISK 🔴" if prob > 0.5 else ("MODERATE ⚠️" if prob > 0.3 else "LOW RISK ✅")
    return {"default_probability": round(prob, 4), "risk_label": label}


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    out_dir = os.path.dirname(os.path.abspath(__file__))

    print("\n" + "="*60)
    print("  TASK 1 — CREDIT SCORING MODEL")
    print("="*60)

    # — Data —
    print("\n[1/5] Generating dataset …")
    df = generate_credit_dataset(5000)
    print(f"  Shape : {df.shape}")
    print(f"  Target: {df['default'].value_counts().to_dict()}")

    # — Feature engineering —
    print("\n[2/5] Engineering features …")
    df = engineer_features(df)

    X = df[FEATURE_COLS].copy()
    y = df["default"].values

    # — Split + SMOTE —
    print("\n[3/5] Splitting & balancing (SMOTE) …")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )
    pre = build_preprocessor()
    X_train_pre = pre.fit_transform(X_train)
    X_test_pre  = pre.transform(X_test)

    sm = SMOTE(random_state=42, k_neighbors=5)
    X_train_bal, y_train_bal = sm.fit_resample(X_train_pre, y_train)
    print(f"  After SMOTE: {dict(zip(*np.unique(y_train_bal, return_counts=True)))}")

    # — Training & evaluation —
    print("\n[4/5] Training models …")
    models  = get_models()
    results = {}
    rf_pipe = None

    for name, model in models.items():
        # rebuild pipeline so test goes through the same preprocessor
        pipe = Pipeline([("pre", build_preprocessor()), ("clf", model)])
        pipe.fit(X_train, y_train_bal[:len(X_train)] if name != "XGBoost" else y_train)
        # simpler: train on balanced for non-XGB, raw for XGB (which has scale_pos_weight)
        pipe2, metrics, fpr, tpr, cm, y_proba = evaluate_model(
            name, model, X_train, y_train, X_test, y_test, build_preprocessor()
        )
        results[name] = {"metrics": metrics, "fpr": fpr, "tpr": tpr, "cm": cm}
        if name == "Random Forest":
            rf_pipe = pipe2

    # — Plots —
    print("\n[5/5] Generating visualisations …")
    plot_results(results, FEATURE_COLS, rf_pipe, out_dir)

    # — Demo prediction —
    print("\n── Demo: Predict a single applicant ──")
    sample_applicant = {
        "age": 34, "annual_income": 42000, "employment_years": 2.5,
        "num_accounts": 3, "credit_utilisation": 0.72, "total_debt": 28000,
        "monthly_payment": 620, "late_payments": 4, "credit_score": 590,
        "num_inquiries": 5, "loan_amount": 15000, "loan_term_months": 36,
    }
    result = predict_credit_risk(sample_applicant, rf_pipe)
    print(f"  Applicant income=${sample_applicant['annual_income']:,} | "
          f"credit_score={sample_applicant['credit_score']} | "
          f"late_payments={sample_applicant['late_payments']}")
    print(f"  → Default Probability : {result['default_probability']:.1%}")
    print(f"  → Risk Label          : {result['risk_label']}")

    # save dataset for reference
    df.to_csv(os.path.join(out_dir, "credit_dataset.csv"), index=False)
    print("\n  ✓ Dataset saved → credit_dataset.csv")
    print("\n✅ Task 1 complete!\n")


if __name__ == "__main__":
    main()